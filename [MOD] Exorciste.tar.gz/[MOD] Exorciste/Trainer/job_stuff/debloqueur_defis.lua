-- ============================================================
-- Exorciste - Module Debloqueur Defis
--
-- Debloque en un clic :
--   - Defi quotidien de la planque
--   - Boulot quotidien / hebdomadaire / mensuel
--   - Mission d'evenement
--   - Mission speciale gage
--   - Defi l'Heritage d'Aldstone
--
-- Expose le namespace global Debloqueur.
-- ============================================================

if Debloqueur and Debloqueur._loaded then return end
Debloqueur = Debloqueur or {}
Debloqueur._loaded = true

Debloqueur.settings = Debloqueur.settings or {
    auto_unlock_on_load = false,
}
Debloqueur.save_path = (SavePath or "") .. "exorciste_debloqueur.json"

local function dbg_log(msg)
    log("[Exorciste/Debloqueur] " .. tostring(msg))
end
Debloqueur.Log = function(_, msg) dbg_log(msg) end

function Debloqueur:LoadSettings()
    local f = io.open(self.save_path, "r")
    if not f then return end
    local raw = f:read("*all")
    f:close()
    local ok, data = pcall(json.decode, raw)
    if ok and type(data) == "table" then
        for k, v in pairs(data) do
            self.settings[k] = v
        end
    end
end

function Debloqueur:SaveSettings()
    local f = io.open(self.save_path, "w")
    if not f then return end
    pcall(function() f:write(json.encode(self.settings)) end)
    f:close()
end

function Debloqueur:ToggleAutoUnlock()
    self.settings.auto_unlock_on_load = not self.settings.auto_unlock_on_load
    self:SaveSettings()
    self:Notify("Auto-deblocage au lancement : "
        .. (self.settings.auto_unlock_on_load and "ACTIVE" or "DESACTIVE"))
end

function Debloqueur:Notify(text)
    dbg_log(text)
    if managers and managers.notification and managers.notification.add_notification then
        pcall(function()
            managers.notification:add_notification({
                id         = "exo_debloqueur_" .. tostring(math.random(1, 99999)),
                shelf_life = 5,
                title      = "[Exorciste]",
                text       = tostring(text),
            })
        end)
    end
end

local function safe(name, fn)
    local ok, err = pcall(fn)
    if not ok then dbg_log("Erreur " .. tostring(name) .. " : " .. tostring(err)) end
end

-- Marque un objectif/sous-objectif comme termine recursivement
local function complete_objective(obj)
    if type(obj) ~= "table" then return end
    obj.completed = true
    if obj.max_progress then obj.progress = obj.max_progress
    elseif obj.progress then obj.progress = obj.progress end
    if obj.amount and obj.amount > 0 then obj.current_amount = obj.amount end
    if type(obj.objectives) == "table" then
        for _, sub in pairs(obj.objectives) do complete_objective(sub) end
    end
end

-- Marque un defi complet (objectifs + flags + sous-defis + recompenses ouvertes)
local function complete_challenge(ch)
    if type(ch) ~= "table" then return false end
    if type(ch.objectives) == "table" then
        for _, obj in pairs(ch.objectives) do complete_objective(obj) end
    end
    ch.completed   = true
    ch.completed_t = ch.completed_t or 1
    if ch.progress and ch.max_progress then ch.progress = ch.max_progress end
    if ch.rewarded == nil then ch.rewarded = false end
    -- recompenses imbriquees (cas custom_safehouse / event_jobs)
    if type(ch.rewards) == "table" then
        for _, r in pairs(ch.rewards) do
            if type(r) == "table" and r.rewarded == nil then r.rewarded = false end
        end
    end
    -- sous-defis (event_jobs imbrique souvent les sous-objectifs)
    if type(ch.challenges) == "table" then
        for _, sub in pairs(ch.challenges) do complete_challenge(sub) end
    end
    return true
end

-- Recupere TOUTES les sources de defis d'un manager (couvre toutes les API rencontrees)
local function fetch_challenges(mgr)
    if not mgr then return {} end
    local merged = {}
    local function ingest(src)
        if type(src) ~= "table" then return end
        for k, v in pairs(src) do merged[k] = v end
    end

    if mgr.get_all_active_challenges then
        local ok, list = pcall(mgr.get_all_active_challenges, mgr)
        if ok then ingest(list) end
    end
    if mgr.get_challenges then
        local ok, list = pcall(mgr.get_challenges, mgr)
        if ok then ingest(list) end
    end
    if mgr._global then
        ingest(mgr._global.challenges)
        ingest(mgr._global.active_challenges)
        ingest(mgr._global.completed_challenges)
        ingest(mgr._global.daily_challenges)
        ingest(mgr._global.weekly_challenges)
        ingest(mgr._global.monthly_challenges)
        ingest(mgr._global.event_challenges)
        ingest(mgr._global.special_event_jobs)
        ingest(mgr._global.trophies)
        ingest(mgr._global.completed_trophies)
        ingest(mgr._global.raids)
    end
    ingest(mgr._active_challenges)
    ingest(mgr._challenges)
    ingest(mgr._tango_challenges)
    return merged
end

-- Tente toutes les fonctions de finalisation connues sur un manager
local function trigger_complete(mgr, id, ch)
    if not mgr then return end
    if mgr.on_challenge_completed then pcall(mgr.on_challenge_completed, mgr, id) end
    if mgr.complete_challenge      then pcall(mgr.complete_challenge,      mgr, id) end
    if mgr.activate_challenge      then pcall(mgr.activate_challenge,      mgr, id) end
    if mgr.award                   then pcall(mgr.award,                   mgr, id) end
    if mgr.award_progress          then pcall(mgr.award_progress,          mgr, id) end
    -- recompenses : on les marque dispo, le joueur les reclamera au stash
    if type(ch) == "table" and type(ch.rewards) == "table" then
        for ridx, _ in pairs(ch.rewards) do
            if mgr.claim_reward then pcall(mgr.claim_reward, mgr, id, ridx) end
        end
    end
end

-- 1. Defi quotidien de la planque -----------------------------
function Debloqueur:UnlockSafehouseDaily()
    safe("UnlockSafehouseDaily", function()
        local cs = managers.custom_safehouse
        if not cs then self:Notify("Manager safehouse indisponible") return end

        local daily
        if cs.get_daily_challenge then daily = cs:get_daily_challenge()
        elseif cs._global and cs._global.daily then daily = cs._global.daily end

        local handled = false
        if daily and not daily.completed then
            complete_challenge(daily)
            if cs.complete_daily and daily.id then pcall(cs.complete_daily, cs, daily.id) end
            if cs.set_active_daily and daily.id then pcall(cs.set_active_daily, cs, daily.id) end
            handled = true
        end

        -- Trophees + raids + defis annexes de la planque
        local extra = 0
        for id, ch in pairs(fetch_challenges(cs)) do
            if type(ch) == "table" and not ch.completed and ch ~= daily then
                complete_challenge(ch)
                trigger_complete(cs, id, ch)
                extra = extra + 1
            end
        end

        if handled or extra > 0 then
            self:Notify("Planque : daily" .. (extra > 0 and (" + " .. extra .. " trophees/defis") or "") .. " debloques")
        else
            self:Notify("Aucun defi de planque a debloquer")
        end
    end)
end

-- 2. Boulots cotes par categorie ------------------------------
function Debloqueur:UnlockSideJobsByCategory(categories, label)
    safe("UnlockSideJobs:" .. (label or "?"), function()
        local cm = managers.challenge
        if not cm then self:Notify("Manager challenge indisponible") return end

        local catset, wildcard = {}, false
        for _, c in ipairs(categories) do
            if c == "*" then wildcard = true else catset[c] = true end
        end

        local count = 0
        for id, ch in pairs(fetch_challenges(cm)) do
            if type(ch) == "table" and not ch.completed then
                local cat = ch.category or ch.type or ""
                if wildcard or catset[cat] then
                    complete_challenge(ch)
                    trigger_complete(cm, id, ch)
                    count = count + 1
                end
            end
        end

        if count > 0 then self:Notify(count .. " defi(s) " .. (label or "") .. " debloque(s)")
        else self:Notify("Aucun defi " .. (label or "") .. " a debloquer") end
    end)
end

function Debloqueur:UnlockDailyJob()    self:UnlockSideJobsByCategory({"daily"},  "quotidien")    end
function Debloqueur:UnlockWeeklyJob()   self:UnlockSideJobsByCategory({"weekly"}, "hebdomadaire") end
function Debloqueur:UnlockMonthlyJob()  self:UnlockSideJobsByCategory({"monthly"},"mensuel")      end

function Debloqueur:UnlockEventMission()
    self:UnlockSideJobsByCategory(
        {"event","events","challenge_event","event_jobs","seasonal"},
        "evenement")
end

function Debloqueur:UnlockSpecialWager()
    self:UnlockSideJobsByCategory(
        {"special_event_jobs","wager","gage","special","gage_assignment"},
        "special gage")
end

-- 3. Heritage d'Aldstone --------------------------------------
local function matches_aldstone(id, cat)
    local s = string.lower(tostring(id) .. " " .. tostring(cat or ""))
    return string.find(s, "aldstone",  1, true)
        or string.find(s, "heritage",  1, true)
        or string.find(s, "heritag",   1, true)
        or string.find(s, "ald_",      1, true)
end

function Debloqueur:UnlockAldstoneHeritage()
    safe("UnlockAldstoneHeritage", function()
        local total = 0
        local mgrs  = { managers.challenge, managers.event_jobs }

        for _, mgr in ipairs(mgrs) do
            if mgr then
                for id, ch in pairs(fetch_challenges(mgr)) do
                    if type(ch) == "table" and not ch.completed
                       and matches_aldstone(id, ch.category or ch.type) then
                        complete_challenge(ch)
                        trigger_complete(mgr, id, ch)
                        total = total + 1
                    end
                end
            end
        end

        if total > 0 then self:Notify(total .. " defi(s) Heritage d'Aldstone debloque(s)")
        else self:Notify("Aucun defi Heritage d'Aldstone actif") end
    end)
end

-- 4. SWEEP brute-force : passe sur TOUS les managers connus
--    Termine TOUT defi/trophee/event non complete, sans filtre.
-- ============================================================
function Debloqueur:UnlockEverythingSweep()
    safe("UnlockEverythingSweep", function()
        local total   = 0
        local sources = {
            { name = "challenge",        mgr = managers.challenge        },
            { name = "event_jobs",       mgr = managers.event_jobs       },
            { name = "custom_safehouse", mgr = managers.custom_safehouse },
            { name = "tango",            mgr = managers.tango            },
            { name = "crime_spree",      mgr = managers.crime_spree      },
            { name = "skirmish",         mgr = managers.skirmish         },
            { name = "gage_assignment",  mgr = managers.gage_assignment  },
            { name = "story",            mgr = managers.story            },
            { name = "raid_jobs",        mgr = managers.raid_jobs        },
        }

        for _, s in ipairs(sources) do
            if s.mgr then
                local n = 0
                for id, ch in pairs(fetch_challenges(s.mgr)) do
                    if type(ch) == "table" and not ch.completed then
                        complete_challenge(ch)
                        trigger_complete(s.mgr, id, ch)
                        n     = n + 1
                        total = total + 1
                    end
                end
                if n > 0 then dbg_log("  sweep " .. s.name .. " : " .. n) end
            end
        end

        self:Notify("Sweep : " .. total .. " defi(s) supplementaire(s) debloque(s)")
    end)
end

-- TOUT -------------------------------------------------------
function Debloqueur:UnlockAll()
    self:UnlockSafehouseDaily()
    self:UnlockDailyJob()
    self:UnlockWeeklyJob()
    self:UnlockMonthlyJob()
    self:UnlockEventMission()
    self:UnlockSpecialWager()
    self:UnlockAldstoneHeritage()
    -- Filet de securite : ramasse TOUT ce qui restait
    self:UnlockEverythingSweep()
    self:Notify("=== Deblocage complet termine ===")
end

-- Auto-deblocage au lancement ---------------------------------
Debloqueur:LoadSettings()

if not Debloqueur._auto_scheduled then
    Debloqueur._auto_scheduled = true
    local elapsed = 0
    local key     = "ExorcisteDebloqueurAutoTimer"
    if Hooks and Hooks.Add then
        Hooks:Add("MenuUpdate", key, function(_, dt)
            if not Debloqueur.settings.auto_unlock_on_load then
                Hooks:Remove(key); return
            end
            elapsed = elapsed + (dt or 0)
            if elapsed >= 5 then
                if managers and managers.challenge then
                    Debloqueur:UnlockAll()
                    Debloqueur._auto_unlock_done = true
                    Hooks:Remove(key)
                elseif elapsed > 60 then
                    Hooks:Remove(key)
                end
            end
        end)
    end
end

return Debloqueur
