-- ============================================================
-- Exorciste - Module Reclamateur de Recompenses
--
-- Reclame en un clic TOUTES les recompenses en attente :
--   - Defis quotidiens / hebdomadaires / mensuels deja completes
--   - Trophees de la planque non reclames
--   - Recompenses imbriquees (event_jobs, raids, custom_safehouse)
--   - Caches Tango / Crime Spree / Skirmish / Gage / Story
--
-- Complement direct du module Debloqueur :
--   Debloqueur termine les defis, Reclamateur recupere les
--   recompenses qu'ils laissent en attente.
--
-- Expose le namespace global Reclamateur.
-- ============================================================

if Reclamateur and Reclamateur._loaded then return end
Reclamateur = Reclamateur or {}
Reclamateur._loaded = true

Reclamateur.settings = Reclamateur.settings or {
    auto_claim_on_load = false,
}
Reclamateur.save_path = (SavePath or "") .. "exorciste_reclamateur.json"

local function dbg_log(msg)
    log("[Exorciste/Reclamateur] " .. tostring(msg))
end
Reclamateur.Log = function(_, msg) dbg_log(msg) end

function Reclamateur:LoadSettings()
    local f = io.open(self.save_path, "r")
    if not f then return end
    local raw = f:read("*all")
    f:close()
    local ok, data = pcall(json.decode, raw)
    if ok and type(data) == "table" then
        for k, v in pairs(data) do
            self.settings[k] = v
        end
    end
end

function Reclamateur:SaveSettings()
    local f = io.open(self.save_path, "w")
    if not f then return end
    pcall(function() f:write(json.encode(self.settings)) end)
    f:close()
end

function Reclamateur:ToggleAutoClaim()
    self.settings.auto_claim_on_load = not self.settings.auto_claim_on_load
    self:SaveSettings()
    self:Notify("Auto-reclamation au lancement : "
        .. (self.settings.auto_claim_on_load and "ACTIVE" or "DESACTIVE"))
end

function Reclamateur:Notify(text)
    dbg_log(text)
    if managers and managers.notification and managers.notification.add_notification then
        pcall(function()
            managers.notification:add_notification({
                id         = "exo_reclamateur_" .. tostring(math.random(1, 99999)),
                shelf_life = 5,
                title      = "[Exorciste]",
                text       = tostring(text),
            })
        end)
    end
end

local function safe(name, fn)
    local ok, err = pcall(fn)
    if not ok then dbg_log("Erreur " .. tostring(name) .. " : " .. tostring(err)) end
end

-- Recupere TOUTES les sources de defis d'un manager
local function fetch_challenges(mgr)
    if not mgr then return {} end
    local merged = {}
    local function ingest(src)
        if type(src) ~= "table" then return end
        for k, v in pairs(src) do merged[k] = v end
    end

    if mgr.get_all_active_challenges then
        local ok, list = pcall(mgr.get_all_active_challenges, mgr)
        if ok then ingest(list) end
    end
    if mgr.get_challenges then
        local ok, list = pcall(mgr.get_challenges, mgr)
        if ok then ingest(list) end
    end
    if mgr._global then
        ingest(mgr._global.challenges)
        ingest(mgr._global.active_challenges)
        ingest(mgr._global.completed_challenges)
        ingest(mgr._global.daily_challenges)
        ingest(mgr._global.weekly_challenges)
        ingest(mgr._global.monthly_challenges)
        ingest(mgr._global.event_challenges)
        ingest(mgr._global.special_event_jobs)
        ingest(mgr._global.trophies)
        ingest(mgr._global.completed_trophies)
        ingest(mgr._global.raids)
    end
    ingest(mgr._active_challenges)
    ingest(mgr._challenges)
    ingest(mgr._tango_challenges)
    return merged
end

-- Tente de marquer une recompense comme "a recuperer au stash"
-- (au lieu de la marquer deja reclamee, on la rend disponible).
local function expose_reward(reward)
    if type(reward) ~= "table" then return end
    if reward.rewarded == true then reward.rewarded = false end
    if reward.claimed == true then reward.claimed = false end
end

-- Force la finalisation d'un defi deja termine pour debloquer
-- son acces au stash, sans toucher aux defis non termines.
local function flush_completed(mgr, id, ch)
    if type(ch) ~= "table" then return false end
    if not ch.completed then return false end

    local touched = false

    -- expose les recompenses imbriquees
    if type(ch.rewards) == "table" then
        for _, r in pairs(ch.rewards) do expose_reward(r) end
        touched = true
    end
    if type(ch.reward) == "table" then
        expose_reward(ch.reward)
        touched = true
    end

    -- declenche les hooks de reclamation
    if mgr.claim_reward then
        if type(ch.rewards) == "table" then
            for ridx, _ in pairs(ch.rewards) do
                pcall(mgr.claim_reward, mgr, id, ridx)
                touched = true
            end
        else
            pcall(mgr.claim_reward, mgr, id)
            touched = true
        end
    end
    if mgr.on_challenge_completed then
        pcall(mgr.on_challenge_completed, mgr, id); touched = true
    end
    if mgr.give_reward then
        pcall(mgr.give_reward, mgr, id); touched = true
    end
    if mgr.award then
        pcall(mgr.award, mgr, id); touched = true
    end

    -- sous-defis (event_jobs imbrique)
    if type(ch.challenges) == "table" then
        for sid, sub in pairs(ch.challenges) do
            if flush_completed(mgr, sid, sub) then touched = true end
        end
    end

    return touched
end

-- 1. Reclame les daily / trophies / raids de la planque ------
function Reclamateur:ClaimSafehouse()
    safe("ClaimSafehouse", function()
        local cs = managers.custom_safehouse
        if not cs then self:Notify("Manager safehouse indisponible") return end

        local count = 0

        -- Trophees + raids + defis annexes deja termines
        for id, ch in pairs(fetch_challenges(cs)) do
            if flush_completed(cs, id, ch) then count = count + 1 end
        end

        -- Daily de la planque
        local daily
        if cs.get_daily_challenge then daily = cs:get_daily_challenge()
        elseif cs._global and cs._global.daily then daily = cs._global.daily end
        if daily and daily.completed then
            if flush_completed(cs, daily.id or "daily", daily) then count = count + 1 end
            if cs.complete_daily and daily.id then pcall(cs.complete_daily, cs, daily.id) end
        end

        if count > 0 then self:Notify("Planque : " .. count .. " recompense(s) liberee(s)")
        else self:Notify("Aucune recompense de planque a reclamer") end
    end)
end

-- 2. Reclame les boulots cotes (daily / weekly / monthly...) -
function Reclamateur:ClaimSideJobs()
    safe("ClaimSideJobs", function()
        local cm = managers.challenge
        if not cm then self:Notify("Manager challenge indisponible") return end

        local count = 0
        for id, ch in pairs(fetch_challenges(cm)) do
            if flush_completed(cm, id, ch) then count = count + 1 end
        end

        if count > 0 then self:Notify("Boulots cotes : " .. count .. " recompense(s) liberee(s)")
        else self:Notify("Aucun boulot cote a reclamer") end
    end)
end

-- 2bis. ONE-CLICK : recupere d'un coup TOUTES les recompenses de
-- petits boulots completes via l'API native ChallengeManager.
-- Utile pour eviter de cliquer chaque case individuellement.
function Reclamateur:ClaimAllSideJobRewardsOneClick()
    safe("ClaimAllSideJobRewardsOneClick", function()
        local cm = managers.challenge
        if not cm then self:Notify("Manager challenge indisponible") return end

        local rewards_given = 0
        local jobs_touched  = 0

        local function process_one(id, category, ch)
            if type(ch) ~= "table" then return end
            if not ch.completed then return end
            local touched_here = false

            -- API native PD2 : on_give_reward(id, category, reward_index)
            if type(ch.rewards) == "table" then
                for ridx, reward in pairs(ch.rewards) do
                    local already = (type(reward) == "table") and (reward.rewarded == true)
                    if not already then
                        local ok = pcall(function()
                            if cm.on_give_reward then
                                cm:on_give_reward(id, category, ridx)
                            end
                        end)
                        if ok then
                            if type(reward) == "table" then reward.rewarded = true end
                            rewards_given = rewards_given + 1
                            touched_here  = true
                        end
                    end
                end
            elseif type(ch.reward) == "table" then
                local already = ch.reward.rewarded == true
                if not already then
                    local ok = pcall(function()
                        if cm.on_give_reward then
                            cm:on_give_reward(id, category, 1)
                        end
                    end)
                    if ok then
                        ch.reward.rewarded = true
                        rewards_given = rewards_given + 1
                        touched_here  = true
                    end
                end
            end

            -- Fallback : signaler le challenge comme complete + claim_reward
            pcall(function()
                if cm.on_challenge_completed then
                    cm:on_challenge_completed(id, category)
                end
            end)
            pcall(function()
                if cm.claim_reward then
                    cm:claim_reward(category, id)
                end
            end)

            if touched_here then jobs_touched = jobs_touched + 1 end
        end

        -- Source 1 : challenges actifs groupes par categorie
        if cm.get_all_active_challenges then
            local ok, list = pcall(cm.get_all_active_challenges, cm)
            if ok and type(list) == "table" then
                for _, ch in pairs(list) do
                    if type(ch) == "table" and ch.id then
                        process_one(ch.id, ch.category or "daily", ch)
                    end
                end
            end
        end

        -- Source 2 : tables internes _global.<categorie>
        if cm._global then
            local cats = { "daily", "weekly", "monthly", "event_challenges" }
            for _, cat in ipairs(cats) do
                local list = cm._global[cat]
                if type(list) == "table" then
                    for id, ch in pairs(list) do
                        process_one(ch.id or id, cat, ch)
                    end
                end
            end
        end

        if rewards_given > 0 then
            self:Notify(string.format(
                "Petits boulots : %d recompense(s) recuperee(s) sur %d boulot(s)",
                rewards_given, jobs_touched))
        else
            self:Notify("Aucune recompense de petit boulot a recuperer")
        end
    end)
end

-- 3. Reclame les missions d'evenement -------------------------
function Reclamateur:ClaimEventJobs()
    safe("ClaimEventJobs", function()
        local em = managers.event_jobs
        if not em then self:Notify("Manager event_jobs indisponible") return end

        local count = 0
        for id, ch in pairs(fetch_challenges(em)) do
            if flush_completed(em, id, ch) then count = count + 1 end
        end

        if count > 0 then self:Notify("Evenements : " .. count .. " recompense(s) liberee(s)")
        else self:Notify("Aucune mission d'evenement a reclamer") end
    end)
end

-- 4. Reclame les caches Tango / Skirmish / Crime Spree / Gage
function Reclamateur:ClaimMiscRewards()
    safe("ClaimMiscRewards", function()
        local total   = 0
        local sources = {
            { name = "tango",           mgr = managers.tango           },
            { name = "skirmish",        mgr = managers.skirmish        },
            { name = "crime_spree",     mgr = managers.crime_spree     },
            { name = "gage_assignment", mgr = managers.gage_assignment },
            { name = "story",           mgr = managers.story           },
            { name = "raid_jobs",       mgr = managers.raid_jobs       },
            { name = "achievment",      mgr = managers.achievment      },
        }

        for _, s in ipairs(sources) do
            if s.mgr then
                local n = 0
                for id, ch in pairs(fetch_challenges(s.mgr)) do
                    if flush_completed(s.mgr, id, ch) then n = n + 1 end
                end
                if n > 0 then dbg_log("  reclame " .. s.name .. " : " .. n) end
                total = total + n
            end
        end

        if total > 0 then self:Notify("Divers : " .. total .. " recompense(s) liberee(s)")
        else self:Notify("Aucune recompense diverse a reclamer") end
    end)
end

-- TOUT -------------------------------------------------------
function Reclamateur:ClaimAll()
    self:ClaimSafehouse()
    self:ClaimSideJobs()
    self:ClaimEventJobs()
    self:ClaimMiscRewards()
    self:Notify("=== Reclamation complete terminee ===")
end

-- Auto-reclamation au lancement -------------------------------
Reclamateur:LoadSettings()

if not Reclamateur._auto_scheduled then
    Reclamateur._auto_scheduled = true
    local elapsed = 0
    local key     = "ExorcisteReclamateurAutoTimer"
    if Hooks and Hooks.Add then
        Hooks:Add("MenuUpdate", key, function(_, dt)
            if not Reclamateur.settings.auto_claim_on_load then
                Hooks:Remove(key); return
            end
            elapsed = elapsed + (dt or 0)
            if elapsed >= 7 then
                if managers and managers.challenge then
                    Reclamateur:ClaimAll()
                    Reclamateur._auto_claim_done = true
                    Hooks:Remove(key)
                elseif elapsed > 60 then
                    Hooks:Remove(key)
                end
            end
        end)
    end
end

return Reclamateur
