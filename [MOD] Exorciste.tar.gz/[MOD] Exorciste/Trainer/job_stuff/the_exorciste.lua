-- ============================================================
-- THE EXORCISTE - Moteur central des effets thematiques
-- Auteur : Exorciste (v1.0)
--
-- Ce module installe UN SEUL hook sur les classes concernees
-- (CopDamage.die, CopSound.say, WeaponLaser.init) et expose
-- _G._ExoState avec des drapeaux togglables. Les 4 plugins
-- (head_180, levitation, voice_latin, laser_apocalypse)
-- se contentent de basculer leur drapeau dans MAIN/UNLOAD.
-- Avantage : pas de conflit de backup multiple sur la meme
-- methode.
-- ============================================================

if _G._ExoState and _G._ExoState._installed then
    return
end

_G._ExoState = _G._ExoState or {
    head_180     = false,
    levitation   = false,
    voice_latin  = false,
    laser        = false,
    _installed   = false,
}

local State = _G._ExoState

local pcall = pcall
local alive = alive
local Vector3 = Vector3
local Idstring = Idstring
local Rotation = Rotation
local math_random = math.random

-- ---- Effet 1 : tete a 180 degres -----------------------------
local _HEAD_KEY
pcall(function() _HEAD_KEY = Idstring("Head") end)

local function _spin_head(unit)
    if not alive(unit) then return end
    local head
    pcall(function()
        if _HEAD_KEY then head = unit:get_object(_HEAD_KEY) end
        if not head then head = unit:orientation_object() end
    end)
    if not head then return end
    local ok, rot = pcall(head.local_rotation, head)
    if not ok or not rot then return end
    local new_rot
    pcall(function()
        new_rot = Rotation(rot:yaw() + 180, rot:pitch(), -rot:roll())
    end)
    if new_rot then
        pcall(head.set_local_rotation, head, new_rot)
    end
end

-- ---- Effet 2 : levitation du cadavre ------------------------
local function _levitate(unit)
    if not alive(unit) then return end
    local force = Vector3(math_random(-150, 150), math_random(-150, 150), 1500)
    pcall(unit.push, unit, 80, force)
end

-- ---- Helper d'execution differee ----------------------------
local function _later(delay, ident, fn, arg)
    local ok = pcall(executewithdelay, { func = fn, params = { arg } }, delay, ident)
    if not ok then
        -- Fallback synchrone si executewithdelay indisponible
        pcall(fn, arg)
    end
end

-- ---- Hook 1 : CopDamage.die ---------------------------------
local function _install_die_hook()
    if State._die_installed or not _G.CopDamage then return end
    State._die_installed = true

    local ok, _ = pcall(function()
        backuper:hijack("CopDamage.die", function(o, self, ...)
            local r = o(self, ...)
            local unit = self and self._unit
            if unit and alive(unit) then
                local key = tostring(unit:key())
                if State.head_180 then
                    _later(0.15, "exo_h180_" .. key, _spin_head, unit)
                end
                if State.levitation then
                    _later(0.05, "exo_lev_"  .. key, _levitate,  unit)
                    -- Petit second push pour l'effet "tordu"
                    _later(0.40, "exo_lev2_" .. key, _levitate,  unit)
                end
            end
            return r
        end)
    end)

    if not ok then
        State._die_installed = false
    end
end

-- ---- Hook 2 : CopSound.say (silence des flics) --------------
local function _install_voice_hook()
    if State._voice_installed or not _G.CopSound then return end
    State._voice_installed = true

    pcall(function()
        backuper:hijack("CopSound.say", function(o, self, ...)
            if State.voice_latin then
                return  -- Silence sacre
            end
            return o(self, ...)
        end)
    end)
end

-- ---- Hook 3 : WeaponLaser.init (laser apocalypse) -----------
local APOC_RED = Color(1.0, 0.55, 0.02, 0.02)  -- rouge sang sature
local APOC_ENTRY = {
    light = APOC_RED * 10,
    glow  = APOC_RED,
    brush = APOC_RED:with_alpha(0.06),
}

local function _apply_apoc(laser)
    if not laser or not laser._themes then return end
    pcall(function()
        laser._themes.exo_apocalypse = APOC_ENTRY
        laser:set_color_by_theme("exo_apocalypse")
    end)
end

local function _install_laser_hook()
    if State._laser_installed or not _G.WeaponLaser then return end
    State._laser_installed = true

    pcall(function()
        backuper:hijack("WeaponLaser.init", function(o, self, ...)
            local r = o(self, ...)
            if State.laser then _apply_apoc(self) end
            return r
        end)
    end)

    -- Re-applique aussi sur les lasers deja crees (joueur en cours)
    State._laser_repaint = function(on)
        local pm = managers and managers.player
        if not pm then return end
        local plr = pm.player_unit and pm:player_unit()
        if not plr then return end
        local inv = plr:inventory()
        if not inv or not inv._available_selections then return end
        for _, sel in pairs(inv._available_selections) do
            local w = sel.unit
            if alive(w) then
                local base = w:base()
                local laser = base and base._laser
                if laser then
                    if on then
                        _apply_apoc(laser)
                    elseif laser.set_color_by_theme then
                        pcall(laser.set_color_by_theme, laser, "standard")
                    end
                end
            end
        end
    end
end

-- ---- API publique -------------------------------------------
function State.enable(name)
    State[name] = true
    if name == "head_180" or name == "levitation" then
        _install_die_hook()
    elseif name == "voice_latin" then
        _install_voice_hook()
    elseif name == "laser" then
        _install_laser_hook()
        if State._laser_repaint then pcall(State._laser_repaint, true) end
    end
end

function State.disable(name)
    State[name] = false
    if name == "laser" and State._laser_repaint then
        pcall(State._laser_repaint, false)
    end
end

State._installed = true

-- ---- Pre-installation au lancement (lazy si classe absente) -
pcall(_install_die_hook)
pcall(_install_voice_hook)
pcall(_install_laser_hook)

-- Filet : si une classe n'etait pas encore chargee, on retente
-- une fois en menu (CopDamage / CopSound / WeaponLaser arrivent
-- au plus tard a l'entree d'un raid).
if Hooks and Hooks.Add then
    local elapsed, done = 0, false
    Hooks:Add("MenuUpdate", "ExoStateLazyInstall", function(_, dt)
        if done then return end
        elapsed = elapsed + (dt or 0)
        if elapsed < 2 then return end
        elapsed = 0
        pcall(_install_die_hook)
        pcall(_install_voice_hook)
        pcall(_install_laser_hook)
        if State._die_installed and State._voice_installed and State._laser_installed then
            done = true
        end
    end)
end
