-- ============================================================
-- Exorciste - Module FOV persistant
-- Auteur : Exorciste
--
-- Charge/sauvegarde la valeur de FOV preferee de l'utilisateur
-- et la reapplique automatiquement a chaque spawn du joueur.
--
-- TECHNIQUE : on hooke PlayerCamera.set_FOV pour multiplier
-- par le ratio (USER_FOV / 75). Cela preserve le zoom du
-- viseur (ADS) et tous les effets dynamiques de FOV de PD2,
-- car le multiplicateur s'applique a TOUTES les valeurs que
-- le jeu pousse a la camera.
--
-- Sauvegarde dans : (SavePath)/exorciste_fov.txt
-- ============================================================

if _G._ExoFOV and _G._ExoFOV._installed then
    return
end

_G._ExoFOV = _G._ExoFOV or {}
local ExoFOV = _G._ExoFOV

ExoFOV.save_path = (SavePath or "") .. "exorciste_fov.txt"
ExoFOV.value     = nil  -- nil = aucune preference enregistree
ExoFOV.MIN_FOV   = 30
ExoFOV.MAX_FOV   = 160
ExoFOV.BASE_FOV  = 75   -- FOV par defaut de PAYDAY 2

local function _clamp(v)
    v = tonumber(v) or 0
    if v < ExoFOV.MIN_FOV then v = ExoFOV.MIN_FOV end
    if v > ExoFOV.MAX_FOV then v = ExoFOV.MAX_FOV end
    return v
end

function ExoFOV.load()
    local ok, val = pcall(function()
        local f = io.open(ExoFOV.save_path, "r")
        if not f then return nil end
        local s = f:read("*a") or ""
        f:close()
        return tonumber((s:gsub("%s+", "")))
    end)
    if ok and val then
        ExoFOV.value = _clamp(val)
        return ExoFOV.value
    end
    return nil
end

function ExoFOV.save(value)
    value = _clamp(value)
    ExoFOV.value = value
    local ok, err = pcall(function()
        local f = io.open(ExoFOV.save_path, "w")
        if not f then error("io.open w failed for " .. tostring(ExoFOV.save_path)) end
        f:write(tostring(value))
        f:close()
    end)
    return ok, err
end

-- Calcule le FOV final pour une valeur de FOV "naturelle" du jeu
-- (ex: PD2 demande 75 → on renvoie user_fov ;
--      PD2 demande 37.5 (ADS) → on renvoie user_fov * 0.5)
local function _scale(natural_fov)
    if not ExoFOV.value or ExoFOV.value <= 0 then return natural_fov end
    local n = tonumber(natural_fov)
    if not n or n <= 0 then return natural_fov end
    return n * (ExoFOV.value / ExoFOV.BASE_FOV)
end

ExoFOV._scale = _scale

-- Hook le setter de la camera pour appliquer notre ratio a
-- toutes les valeurs poussees par le jeu (default + ADS).
ExoFOV._hook_installed = false
local function _install_camera_hook()
    if ExoFOV._hook_installed then return end
    if not _G.PlayerCamera or not _G.backuper then return end

    local ok = pcall(function()
        backuper:hijack("PlayerCamera.set_FOV", function(o, self, fov, ...)
            return o(self, _scale(fov), ...)
        end)
    end)
    if ok then
        ExoFOV._hook_installed = true
    end
end

-- Force un rafraichissement immediat du FOV en jeu
function ExoFOV.refresh()
    pcall(function()
        local pm = managers and managers.player
        if not pm then return end
        local plr = pm.player_unit and pm:player_unit()
        if not plr then return end
        local cam = plr:camera()
        if not cam or not cam._camera_object then return end
        -- Recale en repassant la valeur naturelle actuelle
        -- (le hook l'ajustera).
        local cur = cam._camera_object:fov()
        cam:set_FOV(cur / (ExoFOV.value and (ExoFOV.value / ExoFOV.BASE_FOV) or 1))
    end)
end

-- Setter principal : sauve sur disque + applique en jeu + notif
function ExoFOV.set(value)
    value = _clamp(value)
    local ok, err = ExoFOV.save(value)
    _install_camera_hook()
    ExoFOV.refresh()
    pcall(function()
        if _G.show_mid_text then
            if ok then
                show_mid_text("FOV = " .. tostring(value) .. "  (sauvegarde)",
                              "[ Exorciste ]", 3)
            else
                show_mid_text("FOV = " .. tostring(value) ..
                              "  (sauvegarde ECHEC : " .. tostring(err) .. ")",
                              "[ Exorciste ]", 5)
            end
        end
    end)
    return ok
end

-- Chargement initial depuis disque
ExoFOV.load()

-- Tente d'installer le hook tout de suite si PlayerCamera deja
-- charge ; sinon on retentera via MenuUpdate.
_install_camera_hook()

if Hooks and Hooks.Add then
    local elapsed = 0
    Hooks:Add("MenuUpdate", "ExoFOVHookInstall", function(_, dt)
        if not ExoFOV._hook_installed then
            elapsed = elapsed + (dt or 0)
            if elapsed >= 1 then
                elapsed = 0
                _install_camera_hook()
            end
        end
        -- Suivi temps-reel du curseur du menu (sans sauvegarder)
        if _G.togg_vars then
            local v = togg_vars.exo_set_fov
            if v and v ~= ExoFOV._last_live then
                ExoFOV._last_live = v
                ExoFOV.value = _clamp(v)
                ExoFOV.refresh()
            end
        end
    end)

    -- Filet : a chaque update en jeu, si la camera existe et le
    -- hook n'est pas pose, on pose. Et on suit aussi le curseur
    -- en jeu (le menu Job/Infiltration s'ouvre par-dessus la
    -- partie, donc togg_vars bouge en GameSetupUpdate).
    Hooks:Add("GameSetupUpdate", "ExoFOVGameInstall", function(_, dt)
        if not ExoFOV._hook_installed then
            _install_camera_hook()
        end
        if _G.togg_vars then
            local v = togg_vars.exo_set_fov
            if v and v ~= ExoFOV._last_live then
                ExoFOV._last_live = v
                ExoFOV.value = _clamp(v)
                ExoFOV.refresh()
            end
        end
    end)
end

ExoFOV._installed = true
