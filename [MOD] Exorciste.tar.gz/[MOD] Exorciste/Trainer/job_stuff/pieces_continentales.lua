-- ============================================================
-- Exorciste - Module Pieces Continentales
--
-- Gere rapidement les Continental Coins (la monnaie de la
-- planque, normalement tres lente a farmer) :
--   - Affiche le total actuel
--   - Ajout +100 / +1000 / +10000
--   - Mise a max (9999)
--   - Reset a 0
--   - Auto-keep : maintient un seuil minimum a chaque ouverture du menu
--
-- Utilise la meme API que set_continental_coins du main_menu :
--   Global.custom_safehouse_manager.total = Application:digest_value(v, true)
--
-- Expose le namespace global PiecesContinentales.
-- ============================================================

if PiecesContinentales and PiecesContinentales._loaded then return end
PiecesContinentales = PiecesContinentales or {}
PiecesContinentales._loaded = true

PiecesContinentales.MAX = 9999

PiecesContinentales.settings = PiecesContinentales.settings or {
    auto_keep_min = false,    -- maintient automatiquement le total >= min_threshold
    min_threshold = 1000,     -- seuil minimum si auto_keep_min = true
}
PiecesContinentales.save_path = (SavePath or "") .. "exorciste_pieces_continentales.json"

local function dbg_log(msg)
    log("[Exorciste/PiecesContinentales] " .. tostring(msg))
end
PiecesContinentales.Log = function(_, msg) dbg_log(msg) end

function PiecesContinentales:LoadSettings()
    local f = io.open(self.save_path, "r")
    if not f then return end
    local raw = f:read("*all")
    f:close()
    local ok, data = pcall(json.decode, raw)
    if ok and type(data) == "table" then
        for k, v in pairs(data) do
            self.settings[k] = v
        end
    end
end

function PiecesContinentales:SaveSettings()
    local f = io.open(self.save_path, "w")
    if not f then return end
    pcall(function() f:write(json.encode(self.settings)) end)
    f:close()
end

function PiecesContinentales:ToggleAutoKeep()
    self.settings.auto_keep_min = not self.settings.auto_keep_min
    self:SaveSettings()
    self:Notify("Maintien auto >= " .. self.settings.min_threshold .. " : "
        .. (self.settings.auto_keep_min and "ACTIVE" or "DESACTIVE"))
end

function PiecesContinentales:Notify(text)
    dbg_log(text)
    if managers and managers.notification and managers.notification.add_notification then
        pcall(function()
            managers.notification:add_notification({
                id         = "exo_pieces_" .. tostring(math.random(1, 99999)),
                shelf_life = 5,
                title      = "[Exorciste]",
                text       = tostring(text),
            })
        end)
    end
end

local function safe(name, fn)
    local ok, err = pcall(fn)
    if not ok then dbg_log("Erreur " .. tostring(name) .. " : " .. tostring(err)) end
end

-- Lecture / ecriture securisees du total (digest_value est obligatoire) --
local function read_total()
    local g = Global and Global.custom_safehouse_manager
    if not g or g.total == nil then return nil end
    if Application and Application.digest_value then
        local ok, v = pcall(Application.digest_value, Application, g.total, false)
        if ok and type(v) == "number" then return v end
    end
    return nil
end

local function write_total(value)
    local g = Global and Global.custom_safehouse_manager
    if not g then return false end
    value = math.floor(tonumber(value) or 0)
    if value < 0 then value = 0 end
    if value > PiecesContinentales.MAX then value = PiecesContinentales.MAX end
    if Application and Application.digest_value then
        local ok = pcall(function()
            g.total = Application:digest_value(value, true)
        end)
        return ok
    end
    return false
end

function PiecesContinentales:GetTotal()
    return read_total()
end

function PiecesContinentales:Add(amount)
    safe("Add(" .. tostring(amount) .. ")", function()
        local cur = read_total()
        if cur == nil then self:Notify("Manager safehouse indisponible") return end
        local new = cur + (tonumber(amount) or 0)
        if write_total(new) then
            local final = read_total() or new
            self:Notify("Pieces Continentales : " .. cur .. " -> " .. final)
        end
    end)
end

function PiecesContinentales:SetMax()
    safe("SetMax", function()
        if write_total(self.MAX) then
            self:Notify("Pieces Continentales mises au max (" .. self.MAX .. ")")
        else
            self:Notify("Manager safehouse indisponible")
        end
    end)
end

function PiecesContinentales:Reset()
    safe("Reset", function()
        if write_total(0) then
            self:Notify("Pieces Continentales remises a 0")
        else
            self:Notify("Manager safehouse indisponible")
        end
    end)
end

function PiecesContinentales:KeepAtLeastMin()
    safe("KeepAtLeastMin", function()
        local cur = read_total()
        if cur == nil then return end
        local min = self.settings.min_threshold or 0
        if cur < min then
            write_total(min)
            self:Notify("Pieces Continentales remontees a " .. min)
        end
    end)
end

-- Tick d'auto-maintien : verifie toutes les ~5 secondes, sans saturer
PiecesContinentales:LoadSettings()

if not PiecesContinentales._auto_scheduled then
    PiecesContinentales._auto_scheduled = true
    local elapsed = 0
    local key     = "ExorcistePiecesAutoKeepTimer"
    if Hooks and Hooks.Add then
        Hooks:Add("MenuUpdate", key, function(_, dt)
            if not PiecesContinentales.settings.auto_keep_min then return end
            elapsed = elapsed + (dt or 0)
            if elapsed >= 5 then
                elapsed = 0
                if Global and Global.custom_safehouse_manager then
                    PiecesContinentales:KeepAtLeastMin()
                end
            end
        end)
    end
end

return PiecesContinentales
