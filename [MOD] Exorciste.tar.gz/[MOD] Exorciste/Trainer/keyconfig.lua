--[[
==============================================================
  EXORCISTE   |   Touches Pavé Numérique
==============================================================

TOUCHES DISPONIBLES :
  Clavier : a-z, 0-9, left shift, right shift, left ctrl, right ctrl,
            space, f1-f14, insert, delete, home, end, page up, page down,
            num 0-9, num +, num -, num ., num *, num enter, num lock, num /
  Souris  : left_button, right_button, middle_button,
            x_button_1, x_button_2, x_button_3, x_button_4, x_button_5,
            wheel_up, wheel_down

OPTIONS DE TABLE :
  ig_chat = true/false   -- Si true : s'execute meme en chat
  no_stuck = true/false  -- Si true : ne se repete pas en maintenant la touche

SCHEMA DU PAVE NUMERIQUE :
  [Num Lock] = Normalizer     [num 2] = Job/Infiltration  [num 7] = Troll     [num -] = Outils
  [F1]       = Aide           [num 8] = Configuration     [num 9] = Mission
  [num 4]    = Interactions   [num 5] = Inventaire        [num 6] = Equipement [num +] = Musique
  [num 1]    = Personnage     [F2] = Modes             [num 3] = Spawn
  [F4]    = Carrystacker   [num .] = Script utilisateur                     [num enter] = Victoire !

TOUCHES SUPPLEMENTAIRES (gardees) :
  [X]             = Vision Rayons X
  [Z]             = Ravitaillement (sante + munitions)
  [5]             = Placer equipement (menu)
  [Bouton souris 4] = Ralenti
  [Molette clic]  = Teleportation
==============================================================
]]

--Format retour : table Keyconfig, version de config
return {
    -- ============================================================
    -- MENUS PRINCIPAUX (Marche dans le menu ET en jeu)
    -- ============================================================
    ['num lock']    = { handled_callback = 'Trainer/addons/normalizer.lua',               ig_chat = false, no_stuck = true  }, -- Normalizer / Reinitialiser
    ['num 2']       = { handled_callback = 'Trainer/menu/jobmenu-stealthmenu.lua',        ig_chat = false, no_stuck = true  }, -- Menu Job / Infiltration
    ['num 7']       = { handled_callback = 'Trainer/menu/spoof_name-troll_menu.lua',      ig_chat = false, no_stuck = true  }, -- Menu Troll
    ['num +']       = { handled_callback = 'Trainer/menu/ingame/tools.lua',               ig_chat = false, no_stuck = true  }, -- Menu Outils

    ['f1']          = { handled_callback = 'Trainer/menu/help.lua',                       ig_chat = false, no_stuck = true  }, -- Menu Aide
    ['num 8']       = { handled_callback = 'Trainer/menu/config_menu.lua',                ig_chat = false, no_stuck = true  }, -- Menu Configuration
    ['num 9']       = { handled_callback = 'Trainer/menu/ingame/missionmenu.lua',         ig_chat = false, no_stuck = true  }, -- Menu Mission

    ['num -']       = { handled_callback = 'Trainer/keybinded/music_menu.lua',            ig_chat = false, no_stuck = true  }, -- Menu Musique

    -- ============================================================
    -- MENUS EN JEU UNIQUEMENT
    -- ============================================================
    ['num 4']       = { handled_callback = 'Trainer/menu/ingame/interactions.lua',        ig_chat = false, no_stuck = true  }, -- Menu Interactions
    ['num 5']       = { handled_callback = 'Trainer/menu/ingame/inventory_menu.lua',      ig_chat = false, no_stuck = true  }, -- Menu Inventaire
    ['num 6']       = { handled_callback = 'Trainer/menu/ingame/equipment_menu.lua',      ig_chat = false, no_stuck = true  }, -- Menu Equipement

    ['num 1']       = { handled_callback = 'Trainer/menu/main_menu-charmenu.lua',         ig_chat = false, no_stuck = true  }, -- Menu Principal / Personnage
    ['f2']       = { handled_callback = 'Trainer/menu/ingame/mod_menu.lua',            ig_chat = false, no_stuck = true  }, -- Menu Modes
    ['num 3']       = { handled_callback = 'Trainer/menu/ingame/spawn_menu.lua',          ig_chat = false, no_stuck = true  }, -- Menu Spawn

    ['f4']       = { script           = 'Trainer/addons/carrystacker.lua',             ig_chat = false, no_stuck = false }, -- Carrystacker (Empileur de sacs)
    ['f6']          = { handled_callback = 'Trainer/menu/changelog.lua',                    ig_chat = false, no_stuck = true  }, -- Mises a jour recentes
    ['num /']       = { script           = 'Trainer/user_script.lua',                     ig_chat = false, no_stuck = false }, -- Script Utilisateur
    ['end']   = { handled_callback = 'Trainer/keybinded/instant_win.lua',           ig_chat = false, no_stuck = true  }, -- Victoire Instantanee

    -- ============================================================
    -- TOUCHES SUPPLEMENTAIRES
    -- ============================================================
    ['x']           = { handled_callback = 'Trainer/keybinded/xray.lua',                  ig_chat = false, no_stuck = false }, -- Vision Rayons X
    ['z']           = { handled_callback = 'Trainer/keybinded/replenish.lua',              ig_chat = false, no_stuck = false }, -- Ravitaillement
    ['5']           = { handled_callback = 'Trainer/equipment_stuff/place_equipment.lua',  ig_chat = false, no_stuck = false }, -- Placer Equipement
    ['x_button_1']  = { handled_callback = 'Trainer/keybinded/slowmotion.lua',             ig_chat = false, no_stuck = false }, -- Ralenti (Bouton souris 4)
    ['middle_button']= { handled_callback = 'Trainer/keybinded/teleport.lua',              ig_chat = false, no_stuck = false }, -- Teleportation (Molette clic)
    --['c']          = { handled_callback = 'Trainer/addons/spawngagepackage.lua',          ig_chat = false, no_stuck = false }, -- Spawn Colis Gage (CRASH sur Green Bridge)
}