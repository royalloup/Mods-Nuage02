-- Exorciste Main Configuration File.
-- To turn options ON write true after '=' , to turn options OFF write false.
-- Config frequently being updated through versions, don't forget to update it.

return {
-- Exorciste Trainer related Options
 -- Keybinds
        DisableBindings = false,                                                -- Mettre a true pour desactiver tous les raccourcis (utile si vous utilisez seulement DLCUnlocker et cheats furtivite)
        keyconfig = 'Trainer/keyconfig.lua',            -- Fichier de configuration des touches. Utilisez "keyconfig" (ou false) pour le fichier par defaut.

 -- Updates & Annoucements
        check_for_updates = true,                                               -- Verifie les nouvelles versions dExorciste et vous notifie si disponible.
        announcements = true,                                                   -- Affiche les annonces Exorciste sur les evenements communautaires (DESACTIVE - serveur hors ligne)
        announcements_interval = 60,                                    -- Intervalle entre verifications en minutes

 -- HUD Texts
        HUD = true,                                                                                     -- Mettre a false pour desactiver TOUS les elements HUD dExorciste
        HUD_VersionText = true,                                                 -- Affiche la version actuelle du mod dans le menu principal
        HUD_MovingText = true,                                                  -- Displays moving text in main menu and in game.
        RSSFeed = true,                                                                 -- Displays PiratePerfection.com RSS Feed in Main-Menu

 -- Logging Option
        LogErrorsToFile = true,                                                 -- Affiche les erreurs dans la console ET les ecrit dans errlog.log

 -- Secert
        no_liberty_hook = false,                                                -- Option reservee aux anciens developpeurs.

-- General Options
 -- Language & Config Options
        Language = 'french',                                                    -- Langue actuelle. Langues dispo : English, German, Portuguese, Turkish, Russian, Italian, Spanish, Schinese, Tchinese. false = automatique.
        check_language_updates = true,                          -- false = verification automatique des mises a jour de traduction
        DefaultConfig = 'default_config',                       -- Fichier de configuration par defaut charge automatiquement.

 -- Misc
        NoStatsSynced = true,                                                   -- Empeche la publication des stats sur Steam. Desactivez si vous avez des problemes avec les succes, just make sure to set your profile from Public to other visibillity.
        AllPerks = false,                                                                       -- Bonus de tous les perks. Peut causer un crash lors du changement darmure.
        Extend_Inventory_Slots = false,                         -- Etend les emplacements dinventaire

 -- Unlocker Options
        DLCUnlocker = false,                                                            -- Deverrouille tous les DLC. A utiliser avec prudence.
        AllWeaponSkins = false,                                                 -- Donne tous les skins darmes
        NoSkinMods = false,                                                             -- Empeche les skins dajouter leurs propres modifications automatiquement.
        AllArmorSkins = false,                                                  -- Donne tous les skins darmure
        unlocked_hoxton = false,                                                -- Deverrouille lancien Hoxton sans completer le braquage ni rejoindre le groupe officiel.
        unlocked_arbiter = false,                                               -- Deverrouille le lance-grenades Arbiter sans collecter les valises Gage.
        unlocked_aldstone_items = false,                                -- Deverrouille tous les objets Aldstone.
        CrewUnlocker = false,                                                   -- Deverrouille toutes les capacites et boosts dequipe.

 -- Lobby Options
        StraightToMainMenu = false,                                     -- 
        DisableAutoKick = true,                                                 -- Desactive le kick automatique des tricheurs
        NoDropinPause = false,                                                  -- Desactive la pause lors dune connexion entrante (client et hote).
        HostMatters = true,                                                             -- Lhote force son plan de preplanification en ignorant les votes.
        FreeBlackMarket = false,                                                -- Acheter tout gratuitement.
        FreeAssets = false,                                                             -- Acheter les ressources gratuitement.
        FreePreplanning = false,                                                -- Elements de preplanification gratuits, sans consommer de faveurs.
        FreeCrimeSpree = false,                                                 -- Crime Spree gratuit (demarrage, continuation et randomisation).

 -- Spoof Options       
        NameSpoof = false,              -- Votre nouveau pseudo en jeu. false = utiliser le pseudo Steam. Mettez le nom entre guillemets.
        ReduceDetectionLevel = false,                                   -- Reduit le niveau de detection

 -- Exceptions Options
        ExceptionsEnabled = true,                                               -- Permet de depasser certaines limites avec avertissement (equipement uniquement)
        ExceptionsCrashDetect = false,                          -- Detecte si lapplication a plante. (Necessite ExceptionsEnabled = true)
                                                                                                                        -- Was planned to make process of locating latestcrash easier for cabin boys and it was success, but cabin boys experienced really weird problems with that.

 -- Anticheat related Options
        DisableAnticheat = true,                                                -- Desactive certains controles anti-triche et les verifications de possession DLC.
        PreventEquipDetecting = false,                          -- Methode experimentale pour eviter detre detecte comme tricheur (grenades/equipements).
        Hide_All_Mods = false,                                                  -- Empeche les autres joueurs de voir tous vos mods.
        Hide_Pirate_Perfection = false,                         -- Cache Exorciste aux autres joueurs.
        non_modded_lobby = false,                                               -- Affiche votre lobby comme non-moddifie.

 -- Equipment placement Options
        far_placements = true,                                                  -- Permet de poser des equipements a nimporte quelle distance (glitch visuel possible).
        equipment_place_key = '4',                                              -- Touche de placement des equipements depuis le menu

 -- Main Options
        NoCivilianPenality = true,                                              -- Pas de penalites pour tuer des civils
        NoInvisibleWalls = false,                                               -- Supprime les murs invisibles (hote uniquement)
        RestartProMissions = true,                                              -- Autoriser le redemarrage des missions pro
        RestartJobs = true,                                                             -- Restaure le bouton "Redemarrer" quand vous etes hote
        NoEscapeTimer = false,                                                  -- Supprime le timer descape (hote uniquement)
        ControlCheats = 1,                                                              -- ( false - always off, 1 - Turns on control, when you're client on someone's server, 2 - Always on).
                                                                                                                        -- Limite les placements dequipements et lancers de grenades pour eviter detre marque comme tricheur.
                                                                                                                        -- Empeche aussi le changement aleatoire darme.
        Crosshair = true,                                                                       -- Active le viseur sur toutes les armes                                                                                        
        LaserColorR = 125,                                                              -- Couleur rouge du laser de votre arme.
        LaserColorG = 75,                                                                       -- Format couleur RVB. Exemple : 0, 128, 0 = vert fonce.
        LaserColorB = 205,                                                              -- Mettre a false pour desactiver la couleur laser.
        DontFreezeRagdolls = false,                                     -- Ne jamais figer les cadavres. Peut causer des baisses de FPS !
        DontDisposeRagdolls = false,                                    -- Les cadavres ne disparaissent jamais. Peut causer des baisses de FPS !
        SecureAll = false,                                                              -- Securiser nimporte quel sac sur nimporte quelle carte.

 -- Script Options
        FreeFlightTeleport = false,                                     -- Desactiver le vol libre vous teleporte a la position de la camera de vol.
        NoClipSpeed = 1,                                                                        -- Vitesse de deplacement en mode NoClip (defaut : 1).

 -- Kill all script Options
        KillAllIgnoreTied = true,                                               -- Kill all script will ignore hostaged units.
        KillAllIgnoreCivilians = true,                          -- Kill all script will ignore civilians
        KillAllIgnoreEnemies = false,                                   -- Kill all script will ignore enemies.
        KillAllTouchCameras = true,                                     -- Kill all scripts will kill all cameras aswell.

 -- Character menu Options
        JumpHeightMultiplier = 5,                                               -- Multiplier for player's jump height. Set to false for default value (5).
        RunSpeed = 115,                                                                 -- Maximum run speed. Set to false for default value (115).

 -- Job menu Options
        jobmenu_def_difficulty = 'overkill_145',        -- Default difficulty choosed, when you host game from menu. Available difficulties ("easy","normal","hard","overkill","overkill_145","easy_wish","overkil_290","sm_wish")
        jobmenu_singleplayer = false,                                   -- Job menu will host singleplayer games by default (Can be toggled on/off in jobmenu manually)

 -- Game Fix Options
        DisableBulletFix = false,                                               -- Disables fix on delayed bullet effect play.
        DisableInvFix = false,                                                  -- Disables fix on ctd, when other player changes weapon.
        EnableJobFix = true,                                                            -- Replaces job_class values to 10, so other players will see lobbies with jobs these game thinks "too hard for them". You also can see these jobs now when search.

 -- Spawn menu Options
        SpawnUnitsAmount = 1,                                                   -- Amount of units being spawned, when you select some unit to spawn
        SpawnPos = 'ray',                                                                       -- Spawn position ( "ray", "spawn_point", "random_spawn_point" )
        SpawnCivsAnim = 'cm_sp_stand_idle',                     -- Default animation set for civilians, when you spawn them
        SpawnEnemyAnim = 'idle',                                                -- Default animation set for enemies, when you spawn them
        SpawnUnitKey = "7",                                                             -- Spawn unit button

 -- Inventory menu Options
        rain_bags_amount = 100,                                                 -- Default amount of rained bags
        SpawnBagsAmount = 1,                                                            -- Default amount of spawned bags on single select.
        SpawnBagKey = "8",                                                              -- Spawn bag button

 -- Slowmotion Options
        SmSpeed = 20,                                                                           -- Slow motion speed
        SmSlowPlayer = true,                                                            -- Affects slow motion on player
        slowmo_protect = true,                                                  -- Prevents client from being slowed by forced code
        slowmo_reverse = true,                                                  -- Sends the effect back to the sender

 -- xray Options                                                                                -- Format couleur RVB. Exemple : 0, 128, 0 = vert fonce.
        xray_Cams = true,                                                                       -- xray will highlight cameras
        xray_CamsColR = 255,                                                            -- Camera's highlight color (Orange)
        xray_CamsColG = 50,
        xray_CamsColB = 0,

        xray_Civ = true,                                                                        -- xray will highlight civilians
        xray_CivColR = 0,                                                                       -- Civilian's highlight color (Blue)
        xray_CivColG = 0,
        xray_CivColB = 255,

        xray_CivKeyColR = 255,                                                  -- Civilian with keycard's highlight color
        xray_CivKeyColG = 255,
        xray_CivKeyColB = 0,

        xray_Cops = true,                                                                       -- xray will highlight enemies
        xray_CopsColR = 255,                                                            -- Cop's highlight color
        xray_CopsColG = 0,
        xray_CopsColB = 0,

        xray_CopsKeyColR = 255,                                                 -- Cop with keycard's highlight color
        xray_CopsKeyColG = 100,
        xray_CopsKeyColB = 0,

        xray_SpecialColR = 150,                                                 -- Special's highlight color
        xray_SpecialColG = 50,
        xray_SpecialColB = 205,

        xray_SniperColR = 0,                                                            -- Sniper's highlight color (Green)
        xray_SniperColG = 125,
        xray_SniperColB = 0,

        xray_FriendlyR = 50,                                                            -- Converted enemies color
        xray_FriendlyG = 205,
        xray_FriendlyB = 255,

        xray_Items = true,                                                              -- Highlight some important to objective items (Highlights Framing Frame 3 objects and key cards).

 -- Teleporter Option
        TeleportPenetrate = true,                                               -- Set to true if you want to penetrate through walls and props, when teleporting.

 -- Troll menu Options
--      TrollAmountBags = 5,                                                            -- Amount of bags spawned on victims.(Pro & V.I.P. Only)

 -- AimBot Options
        ShootThroughWalls = false,                                              -- Allow AimBot shoot through walls.
        MaxAimDist = 8000,                                                              -- AimBot max. detection range.
        AimbotInfAmmo = false,                                                  -- Enable infinite ammo for AimBot.
        AimbotDamageMul = 2,                                                            -- Damage multiplier, set to false to use default weapon damage.
        AimMode = 2,                                                                            -- AimBot mode (1 - Only auto shoot, 2 - Only aim, 3 - Auto aim and shoot).
        RightClick = true,                                                              -- Only let the AimBot work if the right mouse button is held.

 -- Lego Options
        LegoFile = 'default',                                                   -- Default lego file.
        LegoDeleteKey = 'h',                                                            -- Delete props button.
        LegoSpawnKey = '6',                                                             -- Spawn props button.
        LegoPrevKey = '7',                                                              -- Quick-switch to previous prop from the list.
        LegoNextKey = '8',                                                              -- Quick-switch to next prop from the list.

 -- Loot Card Spoofer Option
        SpoofCards = true,                                                              -- Fake your loot drops (solo ET multi) to always drop a random safe or drill.

 -- Debug HUD Options
        DebugDramaDraw = false,                                                 -- Enable drama HUD.
        DebugStateDraw = false,                                                 -- Enable displaying state on unit.
        DebugConsole = false,                                                   -- Enable debug console.
        DebugNavDraw = false,                                                   -- Enable displaying debug navigation fields.
        DebugAdditionalEsp = false,                                     -- Enable additional esp on units.
        DebugMissionElements = false,                                   -- Enable drawing mission elements.
        DebugElementsAdditional = false,                                -- Enable drawing additional mission elements.
        EnableDebug = false,                                                            -- Enables debug menu, this also enables freeflight.
        LegacyMenu = false,                                                             -- Utilise les noms de fichiers de config dans le menu de configuration.

-- Fixes - Doing Overkills Job
        CrashFixer = false,                                                             --
        LoopFireSounds = false,                                                 --
        SentryIgnoresShields = false,                                   --
        CheckGhostBonus = false,                                                -- Check if accumulated_ghost_bonus is not nil.
        CheckLobbyHandler = false,                                              --
        CheckMeleeAttack = false,                                               --
        CheckMissionDoorDevicePlaced = false,           --

-- Tweaks - For Advanced Users only!                    -- Toggle here the Tweaks you want to enable.
        armor_tweaks = false,                                                   -- Edit the Values in the .lua files for fine tunning.
        vehicle_tweaks = false,                                                 -- Navigate to Trainer/addons/tweaks for this.
        iceaxe_tweaks = false,                                                  --
        CAR4_tweaks = false,                                                            --
        M79_tweaks = false,                                                             --
        Bernetti9mm_tweaks = false,                                     --
        ChinaPuff_tweaks = false,                                               --
        Glock18c_tweaks = false,                                                --
        Ace_tweaks = false,                                                             --
    Frag_Grenade_tweaks = false,                                        --
        Bipod_Freelook = false,                                                 --
        Bipod_Standing = false,                                                 --
        Bullet_Penetration = false,                                     --
        Drum_Magazine_Mod = false,                                              --
        Gadget_Always_On = false,                                               --
        Improved_Tripmine = false,                                              --
        Increased_Pickup_Ammo = false,                          --
        LMG_Scopes = false,                                                             --
        projectiles_Tweaks = false,                                     --
        Rocket_Jump = false,                                                            --
        Sentry_Gun_Tweaks = false,                                              --
        Shotgun_Physics = false,                                                --
        Weapon_Parts_Tweaks = false,                                    --
        Weapon_Tweaks = false,                                                  --

 -- Custom Safehouse
        SafeHouseDoors = true,                                                  -- Makes doors actually doors in the Safe House.
        SafeHouseInvest = false,                                                -- Put your offshore money on the line to increase or decrease your funds.
        SafeHouseInvestAmt = 500,                                               -- Amount of money to give to put on Safe House Investment.
        SafeHouseLego = false,                                                  -- Automatically loads a file named 'custom_safehouse' upon entering the Safe House.

-- Enables Sub Menus for PPR Setup Menu         -- No need to Change something, this is just to prevent some errors getting logged in the console to reduce the lag caused by this.
        announce_sub = nil,                                                             -- 
        HUD_sub = nil,                                                                          -- 
        general_sub = nil,                                                              -- 
        anticheat_sub = nil,                                                            -- 
        equipment_sub = nil,                                                            --
        misc_sub = nil,                                                                 --
        flying_sub = nil,                                                                       --
        KillAll_sub = nil,                                                              --
        character_sub = nil,                                                            --
        job_sub = nil,                                                                          --
        Spawn_sub = nil,                                                                        --
        inventory_sub = nil,                                                            --
        slow_sub = nil,                                                                 --
        xray_sub = nil,                                                                 --
        aimbot_sub = nil,                                                                       --
        Lego_sub = nil,                                                                 --
        SpoofCards_sub = nil,                                                   --
        Lasercolor = nil,                                                                       --
        xray_CamsCol = nil,                                                             --
        xray_CivCol = nil,                                                              --
        xray_CopsCol = nil,                                                             --
        xray_SpecialCol = nil,                                                  --
        xray_SniperCol = nil,                                                   --
        xray_Friendly = nil,                                                            --
}