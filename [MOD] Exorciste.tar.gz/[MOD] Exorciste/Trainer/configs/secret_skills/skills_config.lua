-- Configuration des competences secretes
-- Fichier vide par defaut - utilise par le menu des competences secretes
return {}
