-- Stealth V2 - Prevention de detection d'equipement
-- Note : cette fonction est experimentale et peut causer des instabilites
-- Activez-la dans config.lua avec : PreventEquipDetecting = true

if show_hint then
    show_hint("(Prevention detection equipement - Experimental)")
end
