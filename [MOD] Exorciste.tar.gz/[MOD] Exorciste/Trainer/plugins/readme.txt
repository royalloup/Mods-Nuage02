Placez vos plugins Lua pour Exorciste dans ce dossier.
Vous pouvez y acceder depuis le menu dedie dans le jeu.
