-- ============================================================
-- THE EXORCISTE - Menu (touche F6)
-- Auteur : Exorciste (v1.0)
-- ============================================================

local ppr_require = ppr_require

ppr_require 'Trainer/tools/new_menu/menu'
-- S'assure que le moteur est charge avant d'ouvrir le menu
ppr_require 'Trainer/job_stuff/the_exorciste'

local Menu = Menu
local Menu_open = Menu.open

local path = "Trainer/addons/the_exorciste/"

local main = function()
    Menu_open(Menu, {
        title = "[ The Exorciste ]",
        description =
            "Effets thematiques d'exorcisme appliques aux ennemis.\n" ..
            "Active/desactive a la volee. Touche F6 pour rouvrir.",
        button_list = {
            { text = "Visage qui se retourne (180 deg)",
              plugin = 'head_180',         switch_back = true },
            { text = "Levitation des cadavres",
              plugin = 'levitation',       switch_back = true },
            { text = "Priere en Latin (silence sacre)",
              plugin = 'voice_latin',      switch_back = true },
            { text = "Laser de l'Apocalypse (rouge sang)",
              plugin = 'laser_apocalypse', switch_back = true },
        },
        plugin_path = path,
        w_mul = 2.4,
        h_mul = 2.4,
    })
end

return main
