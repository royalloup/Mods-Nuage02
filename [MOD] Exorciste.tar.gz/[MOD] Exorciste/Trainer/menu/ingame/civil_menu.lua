-- Purpose: Menu Civil pour Exorciste (Payday 2 / SuperBLT)
-- Author : Exorciste
-- Contenu :
--   - Téléporter tous les civils à moi          (option #4)
--   - Civils complices (caméras / pagers)       (option #20)
--   - Compteur civils live (HUD)                (option #24)
--   - Sous-menu : Spawn Civil (un bouton par civil dispo, en français)

if (not GameSetup) then
    return
end

local ppr_require = ppr_require
ppr_require('Trainer/tools/new_menu/menu')
ppr_require('Trainer/other/all_units')

local Menu      = Menu
local Menu_open = Menu.open

local pairs   = pairs
local ipairs  = ipairs
local insert  = table.insert
local concat  = table.concat
local find    = string.find
local lower   = string.lower
local gmatch  = string.gmatch
local tonum   = tonumber

local managers   = managers
local M_groupAI  = managers.groupai
local M_player   = managers.player
local M_enemy    = managers.enemy
local World      = World
local Idstring   = Idstring
local W_spawn_unit = World.spawn_unit
local mrotation  = mrotation
local mrot_turn  = mrotation.turn
local all_units  = all_units
local unit_on_map = unit_on_map
local ppr_config = ppr_config
local ray_pos    = ray_pos
local tweak_data = tweak_data
local alive      = alive

local path = "Trainer/addons/civilmenu/"

------------------------------------------------------------
-- Dictionnaire EN -> FR pour parser les noms d'unités civiles
------------------------------------------------------------
local FR_DICT = {
    civ          = "Civil",
    female       = "(F)",
    male         = "(H)",
    bank         = "Banque",
    manager      = "Directeur",
    assistant    = "Assistante",
    bikini       = "Bikini",
    casual       = "Décontracté",
    crackwhore   = "Junkie",
    curator      = "Conservateur",
    hostess      = "Hôtesse",
    apron        = "Tablier",
    jacket       = "Veste",
    shirt        = "Chemise",
    party        = "Soirée",
    waitress     = "Serveuse",
    wife         = "Épouse",
    trophy       = "Trophée",
    bartender    = "Barman",
    business     = "Costume",
    dj           = "DJ",
    dog          = "Chien",
    abuser       = "Maltraitant",
    italian      = "Italien",
    robe         = "Robe",
    janitor      = "Concierge",
    meth         = "Meth",
    cook         = "Cuisinier",
    miami        = "Miami",
    store        = "Magasin",
    clerk        = "Vendeur",
    pilot        = "Pilote",
    scientist    = "Scientifique",
    taxman       = "Inspecteur Impôts",
    trucker      = "Camionneur",
    worker       = "Ouvrier",
    docks        = "Docks",
    firefighter  = "Pompier",
    paramedic    = "Ambulancier",
    fastfood     = "Fast-food",
    alesso       = "Alesso",
    booth        = "Cabine",
    helper       = "Assistant",
    casino       = "Casino",
    pitboss      = "Chef de Table",
    impersonator = "Imitateur",
    butcher      = "Boucher",
    hobo         = "Sans-Abri",
    homeless     = "Sans-Abri",
    punk         = "Punk",
    thug         = "Voyou",
    hipster      = "Hipster",
    cleaner      = "Nettoyeur",
    mascot       = "Mascotte",
    beach        = "Plage",
    driver       = "Chauffeur",
    pilot_1      = "Pilote",
    scientist_1  = "Scientifique",
    chavez       = "Chavez",
    locke        = "Locke",
    bain         = "Bain",
    vlad         = "Vlad",
    elephant     = "Éléphant",
    dentist      = "Dentiste",
    butler       = "Majordome",
    nun          = "Nonne",
    priest       = "Prêtre",
    dancer       = "Danseuse",
    stripper     = "Strip-teaseuse",
    mailman      = "Postier",
    delivery     = "Livreur",
    nurse        = "Infirmière",
    doctor       = "Docteur",
    waiter       = "Serveur",
    chef         = "Chef",
    accountant   = "Comptable",
    secretary    = "Secrétaire",
    receptionist = "Réceptionniste",
}

local function parse_civ_name_fr(unit_path)
    -- garde la dernière portion après '/'
    local _, _, name = find(unit_path, "([^/]+)$")
    name = name or unit_path

    local out = {}
    for token in gmatch(name, "[^_]+") do
        local ltok = lower(token)
        if FR_DICT[ltok] then
            insert(out, FR_DICT[ltok])
        elseif tonum(token) then
            insert(out, "#" .. token)
        else
            insert(out, token)
        end
    end
    return concat(out, " ")
end

------------------------------------------------------------
-- Spawn d'un civil
------------------------------------------------------------
local function set_team_safe(unit, team)
    pcall(function()
        local AIState = M_groupAI:state()
        if not AIState then return end
        local team_id = tweak_data.levels:get_default_team_ID(team)
        unit:movement():set_team(AIState:team_data(team_id))
    end)
end

local function set_anim_safe(unit)
    pcall(function()
        local variant = (ppr_config and ppr_config.SpawnCivsAnim) or "cm_sp_stand_idle"
        local action_data = { type = "act", body_part = 1, variant = variant, align_sync = true }
        unit:brain():action_request(action_data)
    end)
end

local function spawn_civilian(unit_name)
    local ply = M_player:player_unit()
    if not alive(ply) then return end

    local rotation = mrot_turn(ply:camera():rotation())
    local position = ray_pos()
    local amount   = (ppr_config and ppr_config.SpawnUnitsAmount) or 1

    for _ = 1, amount do
        local unit = W_spawn_unit(World, Idstring(unit_name), position, rotation)
        if unit then
            set_anim_safe(unit)
            set_team_safe(unit, "non_combatant")
            local brain = unit:brain()
            if brain then brain:set_spawn_ai({ init_state = "idle" }) end
        end
    end
end

------------------------------------------------------------
-- Sous-menu : Spawn Civil
------------------------------------------------------------
local civil_menu_main, spawn_civil_menu

spawn_civil_menu = function()
    local data = {}

    if all_units and all_units.all_civs then
        for _, unit_name in pairs(all_units.all_civs) do
            if unit_on_map(unit_name) then
                insert(data, {
                    text     = parse_civ_name_fr(unit_name),
                    callback = spawn_civilian,
                    data     = unit_name,
                })
            end
        end
    end

    if #data == 0 then
        insert(data, {
            text     = "Aucun civil disponible sur cette carte",
            callback = function() end,
        })
    end

    Menu_open(Menu, {
        title       = "Spawn Civil",
        description = "Cliquez sur un civil pour le faire apparaître au viseur.",
        button_list = data,
        back        = civil_menu_main,
    })
end

------------------------------------------------------------
-- Menu Civil principal
------------------------------------------------------------
civil_menu_main = function()
    local data = {
        { text = "Téléporter tous les civils à moi",
          callback = ppr_require(path .. 'teleport_civs_to_me'),
          host_only = true },

        { text = "Civils complices (marquer caméras / pagers)",
          plugin = 'civil_complices',
          switch_back = true },

        { text = "Compteur civils live (HUD)",
          plugin = 'civil_hud_counter',
          switch_back = true },

        {},

        { text = "Spawn Civil",
          callback = spawn_civil_menu,
          menu = true,
          host_only = true },
    }

    Menu_open(Menu, {
        title       = "Menu Civil",
        description = "Outils dédiés aux civils.",
        button_list = data,
        plugin_path = path,
    })
end

return civil_menu_main
