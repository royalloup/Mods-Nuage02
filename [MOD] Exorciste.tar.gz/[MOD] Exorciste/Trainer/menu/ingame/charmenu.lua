-- ============================================================
-- EXORCISTE - MENU IN-GAME (CHARMENU) AMELIORE v2.0
-- Organisé en sous-menus clairs, pcall sur chaque action sensible
-- ============================================================

local ppr_require = ppr_require
ppr_require 'Trainer/tools/new_menu/menu'
local civil_menu = ppr_require("Trainer/menu/ingame/civil_menu")

local ppr_dofile = ppr_dofile
local insert      = table.insert
local pcall       = pcall

local in_custody  = in_custody
local alive       = alive
local managers    = managers

local M_player        = managers.player
local M_statistics    = managers.statistics
local M_loot          = managers.loot
local M_network       = managers.network
local M_game_info     = managers.gameinfo

local get_my_carry_data       = M_player.get_my_carry_data
local request_player_spawn    = IngameWaitingForRespawnState.request_player_spawn
local on_local_player_dead    = IngameFatalState.on_local_player_dead

local tr = Localization.translate
local path = "Trainer/addons/charmenu/"

local Menu = Menu
local Menu_open = Menu.open

-- ============================================================
-- Fonctions utilitaires (toutes sécurisées avec pcall)
-- ============================================================

local function safe(fn, ...)
    local ok, err = pcall(fn, ...)
    if not ok then
        m_log_error("[Exorciste] Erreur menu: " .. tostring(err))
    end
end

-- Sécuriser le loot porté
local function secure_carry()
    safe(function()
        local carry_data = get_my_carry_data(M_player)
        if carry_data then
            M_loot:secure(carry_data.carry_id, carry_data.multiplier, true)
            M_player:clear_carry()
        end
    end)
end

-- Sortir de prison
local function outta_jail()
    safe(request_player_spawn)
end

-- Aller en prison (avec effet)
local game_state_machine = game_state_machine
local function going_to_jail()
    safe(function()
        local player = M_player:local_player()
        M_player:force_drop_carry()
        M_statistics:downed({ death = true })
        on_local_player_dead()
        game_state_machine:change_state_by_name("ingame_waiting_for_respawn")
        local char_damage = player:character_damage()
        char_damage:set_invulnerable(true)
        char_damage:set_health(0)
        local ply_base = player:base()
        ply_base:_unregister()
        ply_base:set_slot(player, 0)
    end)
end

local function _going_to_jail()
    safe(function()
        M_player:set_player_state('arrested')
        executewithdelay(going_to_jail, 1.5)
    end)
end

-- Téléporter au sol (utile si coincé)
local function teleport_to_ground()
    safe(function()
        local player = M_player:local_player()
        if player then
            local pos = player:position()
            pos.z = pos.z - 50
            player:set_position(pos)
        end
    end)
end

-- Supprimer tous les ennemis proches
local function kill_all_enemies()
    safe(function()
        local units = World:find_units_quick("all")
        for _, unit in ipairs(units) do
            if unit:name() == Idstring("enemy") then
                local dmg = unit:character_damage()
                if dmg and dmg.kill then
                    pcall(dmg.kill, dmg, unit)
                end
            end
        end
    end)
end

-- Donner des munitions au joueur
local function replenish_ammo()
    safe(function()
        local player = M_player:local_player()
        if player then
            local inv = player:inventory()
            if inv then
                local weap = inv:equipped_unit()
                if weap and weap:base() then
                    weap:base():replenish_ammo()
                end
            end
        end
    end)
end

-- Recharger la santé
local function heal_player()
    safe(function()
        local player = M_player:local_player()
        if player then
            local dmg = player:character_damage()
            if dmg then
                dmg:set_health(dmg:max_health())
                dmg:set_armor(dmg:max_armor())
            end
        end
    end)
end

-- ============================================================
-- Sous-menus
-- ============================================================

local main_menu,
      defense_menu,
      weapon_menu,
      melee_menu,
      utility_menu,
      enemies_menu,
      spawn_menu

-- --- Menu Défense --------------------------------------------
defense_menu = function()
    local data = {
        { text = tr.togg_godmode,          plugin = 'god_mode',           switch_back = true },
        { text = tr.buddha_mode,           plugin = 'buddha_mode',        switch_back = true },
        { text = tr.less_damage,           plugin = 'less_damage',        switch_back = true },
        { text = tr.togg_no_hit,           plugin = 'no_hit',             switch_back = true },
        { text = tr.togg_no_fall_damage,   plugin = 'no_fall_damage',     switch_back = true },
        { text = tr.togg_no_flash_bangs,   plugin = 'no_flash_bangs',     switch_back = true },
        { text = tr.togg_infinite_stamina, plugin = 'infinite_stamina',   switch_back = true },
        { text = tr.no_headbob,            plugin = 'no_headbob',         switch_back = true },
        { text = "Mode Invisible (IA)",    plugin = 'invisible_mode',     switch_back = true },
        {},
        { text = ">> Soigner le joueur",   callback = heal_player,        switch_back = true },
    }
    Menu_open(Menu, { title = "[ Defense ]", button_list = data, plugin_path = path, back = main_menu })
end

-- --- Menu Armes -----------------------------------------------
weapon_menu = function()
    local data = {
        { text = tr.togg_ammo,               plugin = 'infinite_ammo',       switch_back = true },
        { text = tr.inf_ammo_reload,          plugin = 'inf_ammo_reload',     switch_back = true },
        { text = tr.togg_recoil,              plugin = 'no_recoil',           switch_back = true },
        { text = tr.togg_accurate,            plugin = 'max_accurate',        switch_back = true },
        { text = tr.togg_bullets,             plugin = 'explosive_bullets',   switch_back = true },
        { text = tr.grenade_bullets,          plugin = 'grenade_weapon',      switch_back = true },
        { text = tr.togg_shoot_through_walls, plugin = 'shoot_through_walls', switch_back = true },
        { text = tr.togg_crazyness,           plugin = 'extreme_firerate',    switch_back = true },
        { text = tr.togg_kill_in_one_hit,     plugin = 'kill_in_one_hit',     switch_back = true },
        {},
        { text = ">> Recharger les munitions", callback = replenish_ammo, switch_back = true },
    }
    Menu_open(Menu, { title = "[ Armes ]", button_list = data, plugin_path = path, back = main_menu })
end

-- --- Menu Corps a corps ----------------------------------------
melee_menu = function()
    local data = {
        { text = tr.togg_increase_melee_dmg, plugin = 'increase_melee_dmg', switch_back = true },
        { text = tr.togg_melee_range,        plugin = 'long_melee_range',   switch_back = true },
        { text = tr.togg_melee_charge,       plugin = 'instant_melee',      switch_back = true },
        { text = tr.togg_melee_no_delay,     plugin = 'no_delay_melee',     switch_back = true },
    }
    Menu_open(Menu, { title = "[ Corps a Corps ]", button_list = data, plugin_path = path, back = main_menu })
end

-- --- Menu Mouvements / Utilitaires ----------------------------
utility_menu = function()
    local data = {
        { text = tr.togg_jumping,              plugin = 'high_jump',              switch_back = true },
        { text = "Bunny Hop (sauts enchaines)", plugin = 'bunny_hop',             switch_back = true },
        { text = tr.togg_speed,                plugin = 'increase_speed',         switch_back = true },
        { text = tr.increase_standard_speed,   plugin = 'increase_standard_speed',switch_back = true },
        { text = tr.togg_no_bag_cooldown,      plugin = 'no_bag_cooldown',        switch_back = true },
        { text = tr.annoyer_mode,              plugin = 'nodelaytalk',            switch_back = true },
        {},
        { text = ">> Teleporter au sol",       callback = teleport_to_ground,     switch_back = true },
        { text = ">> Eliminer ennemis proches",callback = kill_all_enemies,       switch_back = true },
    }
    Menu_open(Menu, { title = "[ Utilitaires ]", button_list = data, plugin_path = path, back = main_menu })
end

-- --- Menu Ennemis (vide, a remplir) ---------------------------
enemies_menu = function()
    local data = {
    }
    Menu_open(Menu, { title = "[ Ennemis ]", button_list = data, plugin_path = path, back = main_menu })
end

-- ============================================================
-- Menu Principal In-Game
-- ============================================================

main_menu = function()
    local data = {
        -- Sous-menus
        { text = "[ Defense ]",            callback = defense_menu,  menu = true },
        { text = "[ Armes ]",              callback = weapon_menu,   menu = true },
        { text = "[ Corps a Corps ]",      callback = melee_menu,    menu = true },
        { text = "[ Utilitaires ]",        callback = utility_menu,  menu = true },
        { text = "[ Ennemis ]",            callback = enemies_menu,  menu = true },
        { text = "[ Civil ]",              callback = civil_menu,    menu = true },
        {},
        -- Actions rapides
        { text = tr.hacked_maskoff,        callback = ppr_dofile,    data = path .. 'hacked_maskoff' },
        {},
    }

    -- Loot porté -> Sécuriser
    if get_my_carry_data(M_player) then
        insert(data, { text = tr.secure_carry, callback = secure_carry })
    end

    -- Statut prison
    if in_custody() then
        insert(data, { text = tr.outta_jail,   callback = outta_jail })
    else
        insert(data, { text = tr.going_to_jail, callback = _going_to_jail })
    end

    Menu_open(Menu, { title = tr.char_menu or "[ Exorciste ]", button_list = data, plugin_path = path })
end

return main_menu
