--Purpose: Welcome popup shown at EVERY launch of PAYDAY 2.
--
-- Implementation : on utilise Hooks:Add("MenuManagerInitialize", ...)
-- qui est le hook OFFICIEL SuperBLT pour "le menu principal est
-- entierement charge". Tous les mods PAYDAY 2 utilisent ce pattern
-- pour afficher des dialogues au lancement, c'est garanti
-- fonctionnel.
--
-- Le popup est affiche via managers.system_menu (le systeme de
-- dialogue natif du jeu), qui est garanti disponible dans ce hook.

local tr = (Localization and Localization.translate) or {}

local title       = tr.welcome_title   or "Bienvenue a vous !"
local description = tr.welcome_message or "Bienvenue dans le Mod Exorciste !"
local discord_txt = tr.welcome_discord or "Rejoindre le Discord"
local close_txt   = tr.btn_close       or "Fermer"

local function open_discord()
        if Steam and Steam.overlay_activate then
                pcall(function()
                        Steam:overlay_activate("url", "https://discord.gg/Gy6SFgsK")
                end)
        end
end

local function show_welcome_popup()
        if not (managers and managers.system_menu and managers.system_menu.show) then
                return
        end
        local data = {
                title = title,
                text = description,
                id = "exorciste_welcome_" .. tostring(math.random(0, 0xFFFFFFFF)),
                button_list = {
                        { text = discord_txt, callback_func = open_discord },
                        { text = close_txt,   cancel_button = true },
                },
        }
        pcall(function() managers.system_menu:show(data) end)
end

-- Trace dans le journal SuperBLT pour confirmer que le fichier est
-- bien charge (visible dans IPHLPAPI.log).
if log then
        pcall(function() log("[Exorciste] firstlaunch.lua loaded - welcome will show on menu init") end)
end

-- 1) METHODE PRINCIPALE : hook officiel SuperBLT.
--    MenuManagerInitialize se declenche quand le MenuManager du jeu
--    est entierement initialise, donc apres que le menu principal
--    soit affiche. Tous les managers (system_menu, gui_data, etc)
--    sont garantis disponibles.
if Hooks and Hooks.Add then
        Hooks:Add("MenuManagerInitialize", "ExorcisteWelcomeMessage", function(menu_manager)
                show_welcome_popup()
        end)
end

-- 2) METHODE DE SECOURS : si jamais MenuManagerInitialize est deja
--    passe (cas tres rare), on utilise un poll qui attend que
--    managers.system_menu soit dispo, puis affiche apres 2s.
local already_shown = false
local _show_once = function()
        if already_shown then return end
        already_shown = true
        show_welcome_popup()
end

-- Un seul show_welcome_popup() au lieu de deux : on remplace
-- show_welcome_popup pour qu'il ne s'execute qu'une fois.
do
        local original = show_welcome_popup
        show_welcome_popup = function()
                if already_shown then return end
                already_shown = true
                original()
        end
end

if query_execution_testfunc then
        query_execution_testfunc(
                function()
                        return managers
                                and managers.system_menu
                                and managers.system_menu.show
                                and managers.menu
                                and true
                                or false
                end,
                {
                        f = function()
                                if executewithdelay then
                                        executewithdelay(
                                                { func = show_welcome_popup, params = {} },
                                                3.0,
                                                'exorciste_welcome_fallback'
                                        )
                                else
                                        show_welcome_popup()
                                end
                        end,
                }
        )
end

-- 3) RE-AFFICHAGE a chaque retour au menu principal (apres une
--    mission par exemple). On reset le flag puis on re-affiche.
if backuper and backuper.add_clbk then
        backuper:add_clbk('MenuMainState.at_enter', function()
                already_shown = false
                if executewithdelay then
                        executewithdelay(
                                { func = show_welcome_popup, params = {} },
                                1.5,
                                'exorciste_welcome_reenter'
                        )
                else
                        show_welcome_popup()
                end
        end, 'exorciste_welcome', 2)
end
