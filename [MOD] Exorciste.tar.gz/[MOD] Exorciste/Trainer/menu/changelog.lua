-- ============================================================
-- EXORCISTE - MENU MISES A JOUR (touche F6)
-- Construit sur le meme moule que Trainer/menu/help.lua
-- ============================================================

local ppr_require = ppr_require

ppr_require 'Trainer/tools/new_menu/menu'

local Steam = Steam
local overlay_activate = Steam.overlay_activate

local open_menu
do
    local Menu = Menu
    local open = Menu.open
    open_menu = function(...)
        return open(Menu, ...)
    end
end

local L = "\n"

local main, page_v2_7

-- ============================================================
-- Page principale - sommaire
-- ============================================================
main = function()
    open_menu({
        title = "Exorciste - Mises a jour recentes",
        description =
            "============================================" ..L..
            "    JOURNAL DES MISES A JOUR" ..L..
            "============================================" ..L..
            L..
            "Selectionnez une version pour en lire le detail." ..L..
            L..
            "  v2.8.0  -  Interface + notifications + sons (NEW)" ..L..
            "  v2.7.0  -  Nouveaux Skins" ..L..
            L..
            "Touche F6 pour rouvrir ce menu." ..L..
            "============================================",
        button_list = {
            { text = "v2.8.0  -  Interface + notifications + sons  (NOUVEAU)" },
            {},
            { text = "v2.7.0  -  Nouveaux Skins",
              callback = function() page_v2_7() end },
            {},
            { text = "GitHub Exorciste",
              callback = overlay_activate,
              data = { Steam, "url", "https://github.com/royalloup/-MOD-Exorciste" } },
        },
        w_mul = 2.4,
        h_mul = 3.0,
    })
end

-- ============================================================
-- v2.7.0  -  Nouveaux Skins (NOUVEAU)
-- ============================================================
page_v2_7 = function()
    local desc =
        "============================================" ..L..
        "  v2.7.0  -  Nouveaux Skins" ..L..
        "============================================" ..L..
        L..
        "NOUVEAU - Nouveaux skins Payday ajoutes" ..L..
        "  De nouveaux skins Payday sont desormais" ..L..
        "  disponibles dans le mod." ..L..
        L..
        "AJOUT - Nouveaux skins de sac" ..L..
        "  Ajout de nouveaux skins pour les sacs" ..L..
        "  utilisables en mission." ..L..
        L..
        "AJOUT - Skin Medic Bag" ..L..
        "  Ajout d'un nouveau skin pour le sac" ..L..
        "  de soins (Medic Bag)." ..L..
        L..
        "AJOUT - Skin Sac de Munitions" ..L..
        "  Ajout d'un nouveau skin pour le sac" ..L..
        "  de munitions (Ammo Bag)." ..L..
        "============================================"

    open_menu({
        title       = "v2.7.0  -  Nouveaux Skins",
        description = desc,
        button_list = {
            { text = "Retour au sommaire",   callback = main },
        },
        w_mul = 2.4,
        h_mul = 4.0,
    })
end

return main
