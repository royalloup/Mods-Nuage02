-- ============================================================
-- EXORCISTE - MENU MISES A JOUR (touche F6)
-- Construit sur le meme moule que Trainer/menu/help.lua
-- ============================================================

local ppr_require = ppr_require

ppr_require 'Trainer/tools/new_menu/menu'

local Steam = Steam
local overlay_activate = Steam.overlay_activate

local open_menu
do
    local Menu = Menu
    local open = Menu.open
    open_menu = function(...)
        return open(Menu, ...)
    end
end

local L = "\n"

local main, page_v2_6

-- ============================================================
-- Page principale - sommaire
-- ============================================================
main = function()
    open_menu({
        title = "Exorciste - Mises a jour recentes",
        description =
            "============================================" ..L..
            "    JOURNAL DES MISES A JOUR" ..L..
            "============================================" ..L..
            L..
            "Selectionnez une version pour en lire le detail." ..L..
            L..
            "  v2.6.0  -  Menu Civil (NEW)" ..L..
            L..
            "Touche F6 pour rouvrir ce menu." ..L..
            "============================================",
        button_list = {
            { text = "v2.6.0  -  Menu Civil  (NOUVEAU)",
              callback = function() page_v2_6() end },
            {},
            { text = "GitHub Exorciste",
              callback = overlay_activate,
              data = { Steam, "url", "https://github.com/royalloup/-MOD-Exorciste" } },
        },
        w_mul = 2.4,
        h_mul = 3.0,
    })
end

-- ============================================================
-- v2.6.0  -  Menu Civil (NOUVEAU)
-- ============================================================
page_v2_6 = function()
    local desc =
        "============================================" ..L..
        "  v2.6.0  -  Menu Civil" ..L..
        "============================================" ..L..
        L..
        "NOUVEAU - Menu Civil" ..L..
        "  Une nouvelle entree \"Menu Civil\" apparait" ..L..
        "  tout en haut du Menu Mission (touche Num 9)." ..L..
        "  Elle regroupe tous les outils dedies aux" ..L..
        "  civils." ..L..
        L..
        "AJOUT - Teleporter tous les civils a moi" ..L..
        "  Action one-shot : tous les civils vivants" ..L..
        "  de la map sont teleportes sur ta position" ..L..
        "  actuelle (utile pour rusher l'attache, ou" ..L..
        "  pour faire un \"meeting\" de civils)." ..L..
        L..
        "AJOUT - Civils complices (cameras / pagers)" ..L..
        "  Toggle. Pose en permanence un waypoint sur" ..L..
        "  toutes les cameras de surveillance de la" ..L..
        "  map (jaune) et sur tous les pagers actifs" ..L..
        "  a desactiver (blanc). Comme si les civils" ..L..
        "  t'aidaient a reperer les obstacles." ..L..
        L..
        "AJOUT - Compteur civils live (HUD)" ..L..
        "  Toggle. Affiche en permanence en haut a" ..L..
        "  gauche de l'ecran :" ..L..
        "      - Vivants" ..L..
        "      - Attaches" ..L..
        "      - Otages" ..L..
        "      - Tues (cette session)" ..L..
        L..
        "AJOUT - Sous-menu Spawn Civil" ..L..
        "  Liste UN bouton par civil disponible sur" ..L..
        "  la carte courante (filtre dynamique avec" ..L..
        "  unit_on_map). Les noms sont traduits en" ..L..
        "  francais : \"Civil (H) Banque Directeur #1\"," ..L..
        "  \"Civil (F) Serveuse #2\", etc." ..L..
        "  La quantite par clic suit le reglage" ..L..
        "  ppr_config.SpawnUnitsAmount." ..L..
        L..
        "Fichiers ajoutes :" ..L..
        "  - Trainer/menu/ingame/civil_menu.lua" ..L..
        "  - Trainer/addons/civilmenu/" ..L..
        "      teleport_civs_to_me.lua" ..L..
        "      civil_complices.lua" ..L..
        "      civil_hud_counter.lua" ..L..
        "============================================"

    open_menu({
        title       = "v2.6.0  -  Menu Civil",
        description = desc,
        button_list = {
            { text = "Retour au sommaire",   callback = main },
        },
        w_mul = 2.4,
        h_mul = 6.4,
    })
end

return main
