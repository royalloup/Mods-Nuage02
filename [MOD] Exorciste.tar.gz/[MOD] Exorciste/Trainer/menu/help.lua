-- ============================================================
-- EXORCISTE - MENU AIDE v2.0
-- Touches corrigees selon keyconfig.lua
-- ============================================================

local ppr_require = ppr_require

ppr_require 'Trainer/tools/new_menu/menu'

local tr = Localization.translate
local Steam = Steam
local overlay_activate = Steam.overlay_activate

local open_menu
do
    local Menu = Menu
    local open = Menu.open
    open_menu = function(...)
        return open(Menu, ...)
    end
end

local main, credits, keybinds, cheatertag

-- ============================================================
-- Page principale
-- ============================================================
main = function()
    open_menu({
        title = tr.help_title or "Exorciste - Aide",
        description =
            tr['help_desc'] or "" ..
            "\nNum 7 = Aide   Num 8 = Config   Num 1 = Menu Principal",
        button_list = {
            { text = tr.help_keybinds   or "Touches",      callback = keybinds   },
            { text = tr.help_cheatertag or "Cheater Tag",  callback = cheatertag },
            { text = tr.help_credits    or "Credits",      callback = credits    },
            { text = "GitHub Exorciste",
              callback = overlay_activate,
              data = { Steam, "url", "https://github.com/royalloup/-MOD-Exorciste" } },
        },
        w_mul = 2.3,
        h_mul = 3.4
    })
end

-- ============================================================
-- Page Touches - liste complete selon keyconfig.lua
-- ============================================================
keybinds = function()
    local L = "\n"
    local desc =
        "============================================" ..L..
        "    EXORCISTE  -  LISTE DES TOUCHES" ..L..
        "============================================" ..L..
        L..
        "--- Fonctionnent en MENU et en JEU ---" ..L..
        "  [Num Lock]    = Normalizer (reinitialiser)" ..L..
        "  [Num /]       = Menu Job / Infiltration" ..L..
        "  [Num *]       = Menu Troll" ..L..
        "  [Num -]       = Menu Outils" ..L..
        L..
        "  [Num 7]       = Menu Aide  (cette page)" ..L..
        "  [Num 8]       = Menu Configuration" ..L..
        "  [Num 9]       = Menu Mission" ..L..
        L..
        "  [Num +]       = Menu Musique" ..L..
        L..
        "--- Fonctionnent EN JEU uniquement ---" ..L..
        "  [Num 4]       = Menu Interactions" ..L..
        "  [Num 5]       = Menu Inventaire" ..L..
        "  [Num 6]       = Menu Equipement" ..L..
        L..
        "  [Num 1]       = Menu Principal / Personnage" ..L..
        "  [Num 2]       = Menu Modes" ..L..
        "  [Num 3]       = Menu Spawn" ..L..
        L..
        "  [Num 0]       = Carrystacker (empiler sacs)" ..L..
        "  [Num .]       = Script Utilisateur" ..L..
        "  [Num Entree]  = Victoire Instantanee" ..L..
        L..
        "--- Touches supplementaires ---" ..L..
        "  [X]               = Vision Rayons X" ..L..
        "  [Z]               = Ravitaillement (HP + munitions)" ..L..
        "  [5]               = Placer Equipement (menu)" ..L..
        "  [Bouton Souris 4] = Ralenti" ..L..
        "  [Clic Molette]    = Teleportation" ..L..
        L..
        "============================================"

    open_menu({
        title       = tr.help_keybinds or "Touches",
        description = desc,
        button_list = {
            { text = tr.back      or "Retour",          callback = main       },
            { text = tr.prev_page or "Page precedente", callback = credits    },
            { text = tr.next_page or "Page suivante",   callback = cheatertag },
        },
        w_mul = 2.2,
        h_mul = 4.2
    })
end

-- ============================================================
-- Page Cheater Tag
-- ============================================================
cheatertag = function()
    open_menu({
        title       = tr.help_cheatertag or "Cheater Tag",
        description = tr.help_cheatertag_desc or "Information sur le tag cheater.",
        button_list = {
            { text = tr.back      or "Retour",          callback = main     },
            { text = tr.prev_page or "Page precedente", callback = keybinds },
            { text = tr.next_page or "Page suivante",   callback = credits  },
        },
        w_mul = 2,
        h_mul = 2
    })
end

-- ============================================================
-- Page Credits
-- ============================================================
credits = function()
    open_menu({
        title       = tr.help_credits or "Credits",
        description = tr.help_credits_desc or "Exorciste - par Exorciste",
        button_list = {
            { text = tr.back      or "Retour",          callback = main       },
            { text = tr.prev_page or "Page precedente", callback = cheatertag },
            { text = tr.next_page or "Page suivante",   callback = keybinds  },
        },
        w_mul = 2,
        h_mul = 2
    })
end

return main
