-- Standalone SuperBLT hook for the Exorciste welcome message.
-- Loaded via MOD.txt directly (hook_id: lib/entry) so it does NOT
-- depend on the mod's internal ppr_require chain.

if _ExorcisteWelcomeHookLoaded then return end
_ExorcisteWelcomeHookLoaded = true

if log then
        pcall(function() log("[Exorciste] welcome_hook.lua loaded by SuperBLT") end)
end

local function get_text(key, fallback)
        if Localization and Localization.translate and Localization.translate[key] then
                return Localization.translate[key]
        end
        return fallback
end

local function show_welcome()
        -- On utilise le menu custom Exorciste (Menu:open) pour avoir le
        -- meme style rouge que les autres menus du Trainer.
        if not (Menu and Menu.open) then
                -- Pas encore charge : on tente le require.
                if ppr_require then
                        pcall(function() ppr_require('Trainer/tools/new_menu/menu') end)
                end
        end

        if Menu and Menu.open then
                local data = {
                        {
                                text = get_text("welcome_discord", "Rejoindre le Discord"),
                                callback = Steam and Steam.overlay_activate or function() end,
                                data = { Steam, "url", "https://discord.gg/Gy6SFgsK" },
                        },
                        {
                                text = get_text("btn_close", "Fermer"),
                                is_cancel_button = true,
                        },
                }
                local ok, err = pcall(function()
                        Menu:open({
                                title       = get_text("welcome_title", "Bienvenue a vous !"),
                                description = get_text("welcome_message", "Bienvenue dans le Mod Exorciste !"),
                                button_list = data,
                                w_mul = 2.5,
                                h_mul = 3.2,
                        })
                end)
                if log then
                        pcall(function() log("[Exorciste] Menu:open() ok=" .. tostring(ok) .. " err=" .. tostring(err)) end)
                end
                if ok then return true end
        end

        -- Fallback : si Menu:open echoue, on retombe sur le dialogue
        -- natif du jeu (au moins le message s'affiche).
        if managers and managers.system_menu and managers.system_menu.show then
                local data = {
                        title = get_text("welcome_title", "Bienvenue a vous !"),
                        text  = get_text("welcome_message", "Bienvenue dans le Mod Exorciste !"),
                        id    = "exorciste_welcome_" .. tostring(math.random(0, 0xFFFFFFFF)),
                        button_list = {
                                {
                                        text = get_text("welcome_discord", "Rejoindre le Discord"),
                                        callback_func = function()
                                                if Steam and Steam.overlay_activate then
                                                        pcall(function() Steam:overlay_activate("url", "https://discord.gg/Gy6SFgsK") end)
                                                end
                                        end,
                                },
                                { text = get_text("btn_close", "Fermer"), cancel_button = true },
                        },
                }
                pcall(function() managers.system_menu:show(data) end)
                return true
        end

        return false
end

local already_shown_this_open = false

if Hooks and Hooks.Add then
        Hooks:Add("MenuManagerOnOpenMenu", "ExorcisteWelcomeOnMainMenu",
                function(menu_manager, opened_menu)
                        if opened_menu ~= "menu_main" then return end
                        if already_shown_this_open then return end
                        already_shown_this_open = true
                        if executewithdelay then
                                executewithdelay(
                                        { func = show_welcome, params = {} },
                                        2.0,
                                        "exorciste_welcome_open"
                                )
                        else
                                show_welcome()
                        end
                end
        )

        -- Quand on quitte le menu principal (pour entrer en mission par
        -- ex), on reset le flag pour que le popup se reaffiche au
        -- retour.
        Hooks:Add("MenuManagerOnCloseMenu", "ExorcisteWelcomeReset",
                function(menu_manager, closed_menu)
                        if closed_menu == "menu_main" then
                                already_shown_this_open = false
                        end
                end
        )
end
