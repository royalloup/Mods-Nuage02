-- ================================================================
-- EXORCISTE - Menu Pseudo Personnalise (Name Spoof) v2.2
-- ================================================================

local ppr_require = ppr_require
ppr_require 'Trainer/tools/new_menu/menu'

local tab_insert = table.insert
local io_lines   = ppr_io.lines
local str_find   = string.find
local tostring   = tostring

local tr        = Localization.translate
local Menu      = Menu
local Menu_open = Menu.open

local change_name, spoof_menu, open_name_menu
local data_names

-- ------------------------------------------------------------------
-- change_name : met a jour le pseudo ET applique tous les patchs
-- (appel depuis le menu = en jeu, tous les managers disponibles)
-- ------------------------------------------------------------------
change_name = function(name)
    if name == nil then return end
    name = tostring(name)

    -- Mettre a jour la valeur globale (les hooks la lisent en direct)
    Global.spoofed_name   = (name ~= "") and name or nil
    ppr_config.NameSpoof  = Global.spoofed_name

    -- S'assurer que namespoof.lua est charge (premiere fois seulement)
    -- ppr_require cache, donc appelle toujours apply_namespoof()
    -- directement apres pour re-tenter le patch account si besoin.
    ppr_require('Trainer/addons/namespoof')

    -- Appliquer / confirmer tous les patchs (idempotent, sans risque)
    if type(apply_namespoof) == "function" then
        apply_namespoof()
    end

    -- Afficher confirmation
    local affiche = Global.spoofed_name
    if not affiche then
        -- Recuperer le vrai nom Steam en toute securite
        local ok, real = pcall(function()
            return managers.network.account:username()
        end)
        affiche = (ok and real) or "Nom Steam"
    end
    show_hint("Pseudo : " .. affiche)
end

-- ------------------------------------------------------------------
-- Ouvrir un sous-menu de noms
-- ------------------------------------------------------------------
open_name_menu = function(id, titre)
    if data_names and data_names[id] then
        Menu_open(Menu, { title = titre or "Choisir un pseudo", button_list = data_names[id] })
    end
end

-- ------------------------------------------------------------------
-- Menu principal
-- ------------------------------------------------------------------
spoof_menu = function()
    data_names = { [1]={}, [2]={}, [3]={}, [4]={}, [5]={} }

    -- Lire names.txt
    local current_cat = 1
    local ok, err = pcall(function()
        for line in io_lines("Trainer/other/names.txt") do
            if     line == "--Standard"     then current_cat = 1
            elseif line == "--Humour"       then current_cat = 2
            elseif line == "--Jeux"         then current_cat = 3
            elseif line == "--Films"        then current_cat = 4
            elseif line == "--Personnalise" then current_cat = 5
            elseif not str_find(line, "^%-%-") and line ~= "" then
                tab_insert(data_names[current_cat],
                    { text = line, callback = change_name, data = line })
            end
        end
    end)
    if not ok then
        m_log_error("spoof_name.lua", "Impossible de lire names.txt : " .. tostring(err))
    end

    -- Bouton desactiver en tete de liste Standard
    tab_insert(data_names[1], 1, {
        text     = "[ Desactiver - Utiliser nom Steam ]",
        callback = change_name,
        data     = ""
    })

    -- Pseudo actuel
    local pseudo_actuel = Global.spoofed_name or "Nom Steam"

    local data = {
        { text = ">> Pseudo actuel : " .. pseudo_actuel .. " <<", callback = void },
        {},
        { text = "Noms Standard",           callback = function() open_name_menu(1, "Noms Standard")       end },
        { text = "Noms Humour",             callback = function() open_name_menu(2, "Noms Humour")         end },
        { text = "Personnages de Jeux",     callback = function() open_name_menu(3, "Personnages de Jeux") end },
        { text = "Films & Series",          callback = function() open_name_menu(4, "Films & Series")      end },
        { text = "Noms Personnalises",      callback = function() open_name_menu(5, "Noms Personnalises")  end },
    }

    Menu_open(Menu, { title = tr['spoof_menu'] or "Pseudo Personnalise", button_list = data })
end

return spoof_menu
