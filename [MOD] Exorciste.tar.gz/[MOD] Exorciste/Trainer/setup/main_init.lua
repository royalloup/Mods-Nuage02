local ppr_dofile = ppr_dofile
--Hack lines
if (not orig__dofile) then
	orig__dofile = ppr_dofile
end
--End of hacks

ppr_dofile('Trainer/Setup/__require.lua') -- Charge la fonction ppr_require amelioree
__first_require_clbk =
function()
	ppr_dofile("Trainer/Setup/pre_init")
	-- Code a executer au tout premier ppr_require.
end
print("Exorciste Trainer \nv2.0.0-Free Edition \nSuperBLT v3.1.2 (R026) \npar Exorciste \ninitialized")
--[[
--Callbacks, these executed before ppr_require script being executed
__require_pre[required_script] = callback_function

--Callbacks, these executed after required script being executed
__require_after[required_script] = callback_function2

--Callbacks, these will override whole ppr_require
__require_override[required_script] = callback_function3
]]

-- Tout code supplementaire a executer au newstate va ici. Attention : a ce stade, seules les libs Lua sont disponibles, pas les classes internes du jeu.