-- Purpose : Téléporte TOUS les civils vivants sur la position du joueur
-- Author  : Exorciste
-- Type    : callback one-shot (à appeler depuis le menu Civil)

local pairs = pairs
local alive = alive

local function chat_msg(msg)
    pcall(function()
        if managers and managers.chat then
            managers.chat:_receive_message(1, "Exorciste",
                tostring(msg), Color.white)
        end
    end)
end

local function get_player_unit()
    if GetPlayerUnit then
        local u = GetPlayerUnit()
        if alive(u) then return u end
    end
    if managers and managers.player then
        local ok, u = pcall(function() return managers.player:player_unit() end)
        if ok and alive(u) then return u end
    end
    return nil
end

local function teleport_one(unit, pos, rot)
    -- Téléport direct sur l'unité (pos / rot dans le BON ordre PD2)
    pcall(function() unit:set_position(pos) end)
    pcall(function() unit:set_rotation(rot) end)

    -- Synchroniser l'extension de mouvement (sinon le brain remet le civ à
    -- son ancienne position au prochain tick)
    pcall(function()
        local mv = unit:movement()
        if not mv then return end
        if mv.set_position then pcall(mv.set_position, mv, pos) end
        if mv.set_rotation then pcall(mv.set_rotation, mv, rot) end
        -- warp_to est en (pos, rot) chez PD2, PAS (rot, pos)
        if mv.warp_to then pcall(mv.warp_to, mv, pos, rot) end
    end)
end

return function()
    -- IMPORTANT : on relit managers à CHAQUE appel (pas au load du fichier)
    local M_enemy = managers and managers.enemy

    local ply = get_player_unit()
    if not alive(ply) then
        chat_msg("[Civil] Erreur : pas de joueur vivant.")
        return
    end

    if not (M_enemy and M_enemy.all_civilians) then
        chat_msg("[Civil] Erreur : managers.enemy indisponible.")
        return
    end

    -- Position des PIEDS du joueur (et non camera) pour que le civ soit au sol
    local pos = ply:position()
    local rot = ply:rotation()
    local count = 0

    for _, ud in pairs(M_enemy:all_civilians()) do
        local u = ud.unit
        if alive(u) then
            teleport_one(u, pos, rot)
            count = count + 1
        end
    end

    chat_msg("[Civil] " .. count .. " civils téléportés.")
end
