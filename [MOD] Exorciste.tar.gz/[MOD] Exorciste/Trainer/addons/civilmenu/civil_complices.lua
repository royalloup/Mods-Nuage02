-- Purpose : "Civils complices" — marque automatiquement sur le HUD les caméras
--           de surveillance et les pagers à désactiver, comme si les civils
--           t'aidaient à repérer les obstacles de l'infiltration.
-- Author  : Exorciste
-- Type    : plugin toggle

plugins:new_plugin('civil_complices')

VERSION = '1.1'

local managers = managers
local World    = World
local Color    = Color
local pairs    = pairs
local tostring = tostring
local alive    = alive
local find     = string.find

local _wp_ids = {}

-- Couleurs (PD2: Color(alpha, r, g, b))
local COL_CAM   = Color(0.85, 1.0, 0.85, 0.10) -- jaune translucide
local COL_PAGER = Color(0.85, 1.0, 1.0, 1.0)   -- blanc translucide

local function add_wp(id, pos, icon, color)
    if not managers.hud then return end
    if _wp_ids[id] then return end
    pcall(function()
        managers.hud:add_waypoint(id, {
            icon          = icon or 'wp_camera',
            distance      = true,
            position      = pos,
            no_sync       = true,
            present_timer = 0,
            state         = "present",
            radius        = 1000000,
            color         = color or COL_CAM,
            blend_mode    = "add",
        })
        _wp_ids[id] = true
    end)
end

local function is_camera_unit(unit)
    if not (alive(unit) and unit:base()) then return false end
    local b = unit:base()
    if b.is_security_camera or b.is_camera then return true end
    if b.tweak_data == "camera" then return true end
    -- Fallback : on regarde le nom de l'unité
    local n = unit:name()
    if n then
        local s = tostring(n)
        if find(s, "camera", 1, true) or find(s, "surv", 1, true) then
            return true
        end
    end
    return false
end

local function refresh()
    if not (managers.hud and World and World.find_units_quick) then return end

    pcall(function()
        for _, unit in pairs(World:find_units_quick("all")) do
            if alive(unit) then
                -- Caméras de surveillance
                if is_camera_unit(unit) then
                    add_wp("exo_civ_cam_" .. tostring(unit:key()),
                           unit:position(),
                           "wp_camera",
                           COL_CAM)
                end

                -- Pagers actifs (corps avec pager bipant)
                if unit:interaction() then
                    local td = unit:interaction().tweak_data
                    if td == "corpse_alarm_pager" then
                        add_wp("exo_civ_pager_" .. tostring(unit:key()),
                               unit:position(),
                               "wp_pager_used",
                               COL_PAGER)
                    end
                end
            end
        end
    end)
end

function MAIN()
    if RunNewLoopIdent then
        RunNewLoopIdent('civil_complices_loop', refresh)
    end
end

function UNLOAD()
    if StopLoopIdent then
        StopLoopIdent('civil_complices_loop')
    end
    if managers.hud then
        for id, _ in pairs(_wp_ids) do
            pcall(function() managers.hud:remove_waypoint(id) end)
        end
    end
    _wp_ids = {}
end

FINALIZE()
