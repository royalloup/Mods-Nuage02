-- Purpose : Compteur civils live affiché en HUD (Vivants / Attachés / Otages /
--           Tués cette session)
-- Author  : Exorciste
-- Type    : plugin toggle

plugins:new_plugin('civil_hud_counter')

VERSION = '1.1'

local managers  = managers
local M_enemy   = managers.enemy
local pairs     = pairs
local alive     = alive
local Color     = Color
local sformat   = string.format

local _ws, _panel, _text

local function build_panel()
    if not (managers.hud and managers.hud._workspace) then return end
    pcall(function()
        _ws    = managers.hud._workspace
        _panel = _ws:panel():panel({
            name  = "exo_civ_hud_counter",
            layer = 1000,
            x     = 20,
            y     = 220,
            w     = 320,
            h     = 130,
        })
        -- PD2: Color(alpha, r, g, b) -> fond noir semi-transparent
        _panel:rect({ color = Color(0.55, 0, 0, 0), layer = 0 })
        _text = _panel:text({
            name      = "txt",
            text      = "",
            font      = "fonts/font_medium_mf",
            font_size = 18,
            color     = Color.white,
            layer     = 1,
            x         = 8,
            y         = 6,
            align     = "left",
            vertical  = "top",
        })
    end)
end

local function refresh()
    if not _text then return end

    local alive_count, tied_count, hostage_count, dead_count = 0, 0, 0, 0

    pcall(function()
        if M_enemy and M_enemy.all_civilians then
            for _, ud in pairs(M_enemy:all_civilians()) do
                local u = ud.unit
                if alive(u) then
                    alive_count = alive_count + 1
                    local ad = u.anim_data and u:anim_data()
                    if ad and (ad.tied or ad.hands_tied) then
                        tied_count = tied_count + 1
                    end
                end
            end
        end
    end)

    pcall(function()
        if managers.groupai and managers.groupai:state() then
            local s = managers.groupai:state()
            hostage_count = (s.hostage_count and s:hostage_count()) or 0
        end
    end)

    pcall(function()
        if managers.statistics
           and managers.statistics.session_total_civilian_kills then
            dead_count = managers.statistics:session_total_civilian_kills() or 0
        end
    end)

    pcall(function()
        _text:set_text(sformat(
            "CIVILS\nVivants : %d\nAttachés : %d\nOtages : %d\nTués (session) : %d",
            alive_count, tied_count, hostage_count, dead_count
        ))
    end)
end

function MAIN()
    build_panel()
    if RunNewLoopIdent then
        RunNewLoopIdent('civil_hud_counter_loop', refresh)
    end
end

function UNLOAD()
    if StopLoopIdent then
        StopLoopIdent('civil_hud_counter_loop')
    end
    pcall(function()
        if _panel and _ws and _ws:panel() then
            _ws:panel():remove(_panel)
        end
    end)
    _panel, _text, _ws = nil, nil, nil
end

FINALIZE()
