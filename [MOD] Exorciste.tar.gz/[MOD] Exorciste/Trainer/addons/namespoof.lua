-- ================================================================
-- EXORCISTE - Pseudo Personnalise (Name Spoof) v2.4
-- ================================================================
-- CORRECTIONS v2.4 :
--   - Acces DIRECT a managers.network._session._local_peer._name
--     (meme chemin utilise par le moteur du mod dans init.lua)
--   - Sauvegarde du vrai nom Steam dans ._real_name pour restauration
--   - Patchs de methodes conserves pour intercepter les appels futurs
--   - apply_namespoof() globale, appelee par le menu a chaque changement
-- ================================================================

local Global = Global

function apply_namespoof()
    local spoof = Global.spoofed_name
    if spoof == "" then spoof = nil end

    -- ================================================================
    -- PATCH PRINCIPAL : modification directe du champ _name du peer
    -- C'est la valeur lue par l'affichage du nom en lobby et en jeu.
    -- Chemin confirme dans setup/init.lua l.716 : M_network._session._local_peer._id
    -- ================================================================
    pcall(function()
        local net = managers.network
        if not net then return end
        local session = rawget(net, "_session")
        if not session then return end
        local lp = rawget(session, "_local_peer")
        if not lp then return end

        -- Sauvegarder le vrai nom la premiere fois
        if not rawget(lp, "_real_steam_name") and rawget(lp, "_name") then
            rawset(lp, "_real_steam_name", rawget(lp, "_name"))
        end

        if spoof then
            lp._name = spoof
        else
            -- Restaurer le vrai nom Steam
            local real = rawget(lp, "_real_steam_name")
            if real then lp._name = real end
        end
    end)

    -- ================================================================
    -- PATCH 2 : Hook NetworkPeer.name() pour les appels futurs
    -- Utilise l'ID du peer local pour l'identification (plus fiable)
    -- ================================================================
    if NetworkPeer and not rawget(NetworkPeer, "__exo_name_orig") then
        local orig = NetworkPeer.name
        if type(orig) == "function" then
            rawset(NetworkPeer, "__exo_name_orig", orig)
            NetworkPeer.name = function(self, ...)
                local sp = Global.spoofed_name
                if sp and sp ~= "" then
                    local ok, is_local = pcall(function()
                        local net = managers.network
                        local session = net and rawget(net, "_session")
                        local lp = session and rawget(session, "_local_peer")
                        return lp ~= nil and lp == self
                    end)
                    if ok and is_local then return sp end
                end
                return orig(self, ...)
            end
        end
    end

    -- ================================================================
    -- PATCH 3 : account:username() - nom dans les menus et le chat
    -- ================================================================
    pcall(function()
        local net = managers.network
        local account = net and net.account
        if account and not rawget(account, "__exo_acc_patched") then
            local orig = account.username
            if type(orig) == "function" then
                account.username = function(self, ...)
                    local sp = Global.spoofed_name
                    if sp and sp ~= "" then return sp end
                    return orig(self, ...)
                end
                rawset(account, "__exo_acc_patched", true)
            end
        end
    end)

    -- ================================================================
    -- PATCH 4 : NetworkMatchMakingSTEAM.user_name() - lobby Steam
    -- ================================================================
    if NetworkMatchMakingSTEAM and not rawget(NetworkMatchMakingSTEAM, "__exo_username_orig") then
        local orig = NetworkMatchMakingSTEAM.user_name
        if type(orig) == "function" then
            rawset(NetworkMatchMakingSTEAM, "__exo_username_orig", orig)
            NetworkMatchMakingSTEAM.user_name = function(self, ...)
                local sp = Global.spoofed_name
                if sp and sp ~= "" then return sp end
                return orig(self, ...)
            end
        end
    end

    if log then
        log("[Exorciste/NameSpoof] Pseudo applique : " .. (spoof or "(nom Steam reel)"))
    end
end

apply_namespoof()
