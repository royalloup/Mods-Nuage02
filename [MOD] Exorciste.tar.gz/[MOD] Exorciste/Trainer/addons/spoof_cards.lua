--  Author:  Davy Jones / Nuage 02
--  Purpose: Spoofs your loot drop (solo ET multijoueur) to always be a configured safe or drill.
--  Notes:   Hardened against missing managers, missing tweak entries, broken
--           localization keys and bad RNG seeding. Falls back gracefully instead
--           of crashing the lobby state.

local insert      = table.insert
local rand        = math.random
local randseed    = math.randomseed
local os_time     = os.time
local os_clock    = os.clock
local tostring    = tostring
local type        = type
local pcall       = pcall

local Color       = Color

-- Cache managers / tweak data lazily so we don't explode at file load time
-- if a manager isn't ready yet (e.g. early hook registration).
local function safe_get(tbl, key)
        if type(tbl) ~= "table" then return nil end
        return tbl[key]
end

local managers       = managers
local tweak_data     = tweak_data
local ppr_config     = ppr_config or {}
local backuper       = backuper

if not backuper or type(backuper.hijack) ~= "function" then
        -- Without the hijack helper there's nothing this script can do.
        return
end

local hijack = backuper.hijack

-- Default fallback drops: weapon / dallas / surf / pack safes & drills.
-- These are validated against tweak_data the first time we need them so we
-- never hand a nonexistent id back to the game.
local DEFAULT_TYPES = { "safes", "drills" }
local DEFAULT_IDS   = { "weapon_01", "dallas_01", "surf_01", "pack_01" }

local def_items_cache

local function build_default_items()
        local out = {}
        local economy = safe_get(tweak_data, "economy")
        for _, typ_n in ipairs(DEFAULT_TYPES) do
                local typ_tbl = safe_get(economy, typ_n)
                for _, id in ipairs(DEFAULT_IDS) do
                        -- Only keep ids that actually exist in tweak_data.economy[type].
                        if typ_tbl and typ_tbl[id] then
                                insert(out, { typ_n, id })
                        end
                end
        end
        -- Last-resort: if tweak_data was unavailable, still return the raw
        -- pairs so the original behaviour is preserved.
        if #out == 0 then
                for _, typ_n in ipairs(DEFAULT_TYPES) do
                        for _, id in ipairs(DEFAULT_IDS) do
                                insert(out, { typ_n, id })
                        end
                end
        end
        return out
end

local function get_default_items()
        if not def_items_cache then
                def_items_cache = build_default_items()
        end
        return def_items_cache
end

-- Better seeding: combine wall clock seconds with a high-resolution clock
-- sample. Avoids the original bug where yday*hour*min*sec could equal 0
-- (any factor at midnight / start of minute) and re-seed to a constant.
local function reseed_rng()
        local t = os_time() or 1
        local c = math.floor((os_clock() or 0) * 1e6)
        randseed(t + c)
        -- Discard the first values: some Lua RNGs are biased right after seeding.
        rand(); rand(); rand()
end

-- Build the list of spoof candidates from ppr_config, validated against
-- tweak_data so we never hand the game an unknown id.
local function collect_spoofs()
        local spoofs = {}
        local economy = safe_get(tweak_data, "economy")
        if not economy then
                return spoofs
        end
        local sources = { safes = economy.safes, drills = economy.drills }
        for typ_n, typ in pairs(sources) do
                if type(typ) == "table" then
                        for id, _ in pairs(typ) do
                                if ppr_config[typ_n .. id] then
                                        insert(spoofs, { typ_n, id })
                                end
                        end
                end
        end
        return spoofs
end

-- Resolve a localized item name without crashing on missing keys / managers.
local function resolve_item_name(temp)
        local M_localization = safe_get(managers, "localization")
        local T_blackmarket  = safe_get(tweak_data, "blackmarket")
        if not (temp and temp.type_items and temp.item_entry) then
                return "unknown"
        end
        local category = safe_get(T_blackmarket, temp.type_items)
        local entry    = safe_get(category, temp.item_entry)
        local name_id  = safe_get(entry, "name_id")
        if M_localization and name_id then
                local ok, txt = pcall(M_localization.text, M_localization, name_id)
                if ok and txt then return txt end
        end
        return tostring(temp.item_entry)
end

-- Resolve a localization string by key, with a safe fallback.
local function L(key, fallback)
        local M_localization = safe_get(managers, "localization")
        if M_localization then
                local ok, txt = pcall(M_localization.text, M_localization, key)
                if ok and txt and txt ~= "" then return txt end
        end
        return fallback or key
end

-- Best-effort chat broadcast; never throws.
local function chat_broadcast(name, msg)
        local M_chat = safe_get(managers, "chat")
        if not M_chat or type(M_chat._receive_message) ~= "function" then
                return
        end
        local color = (Color and Color.Free) or (Color and Color.white) or nil
        pcall(M_chat._receive_message, M_chat, 1, name, msg, color)
end

hijack(backuper, "IngameLobbyMenuState.set_lootdrop", function(o, self, drop_category, drop_item_id)
        -- If the original call already carries explicit drop info, just forward it.
        if drop_item_id and drop_category then
                return o(self, drop_category, drop_item_id)
        end

        -- Discover what the game would have rolled, so we can announce it.
        local M_lootdrop = safe_get(managers, "lootdrop")
        local temp = {}
        if M_lootdrop and type(M_lootdrop.new_make_drop) == "function" then
                local ok = pcall(M_lootdrop.new_make_drop, M_lootdrop, temp)
                if not ok then temp = {} end
        end

        chat_broadcast(
                L("loot_spoof_name", "Loot Spoof"),
                L("loot_spoof_actual", "Original drop: ") .. resolve_item_name(temp)
        )

        -- Pick a spoofed drop, falling back to validated defaults.
        local spoofs = collect_spoofs()
        if #spoofs == 0 then
                spoofs = get_default_items()
        end
        if #spoofs == 0 then
                -- Nothing safe to spoof to — let the original call run untouched.
                return o(self, drop_category, drop_item_id)
        end

        reseed_rng()
        local spoofed = spoofs[rand(#spoofs)]
        return o(self, spoofed[1], spoofed[2])
end)
