-- Annonces globales - DESACTIVE
-- L'ancien serveur (bitbucket pirate-perfection) n'existe plus.
-- Ce fichier est volontairement desactive pour eviter les fuites memoire,
-- les boucles HTTP infinies et les crashs reseau sur toutes versions du jeu.

-- managers.announce_manager reste nil intentionnellement.
-- Pour reactiver les annonces, pointez self.url vers votre propre serveur.

return
