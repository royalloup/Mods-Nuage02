-- Bunny Hop / Auto-Hop
-- Author: Exorciste
-- Tant que la touche SAUT est maintenue, le jeu re-declenche un saut
-- automatiquement des que le joueur retouche le sol.

plugins:new_plugin('bunny_hop')

VERSION = '1.0'

CATEGORY = 'character'

function MAIN()
backuper:hijack('PlayerStandard._get_input', function( o, self, t, dt, paused, ... )
local input = o( self, t, dt, paused, ... )
if input and self._controller and self._controller:get_input_bool("jump") then
input.btn_jump_press = true
end
return input
end)
end

function UNLOAD()
backuper:restore('PlayerStandard._get_input')
end

FINALIZE()
