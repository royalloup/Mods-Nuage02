-- Purpose: Hides your Mods
-- Author: Exorciste
function MenuCallbackHandler:build_mods_list()
	return {}
end