-- DLC Unlocker - Mise à jour
-- Compatible Steam, Epic Games et autres plateformes

-- Fonction principale de vérification DLC
local function unlockAllDLC(dlc_data)
    return true
end

-- Implémentations spécifiques aux plateformes
if rawget(_G, "WinSteamDLCManager") then
    function WinSteamDLCManager:_check_dlc_data(dlc_data)
        return unlockAllDLC(dlc_data)
    end
end

if rawget(_G, "WinEpicDLCManager") then
    function WinEpicDLCManager:_check_dlc_data(dlc_data)
        return unlockAllDLC(dlc_data)
    end
end

if rawget(_G, "WINDLCManager") then
    function WINDLCManager:_check_dlc_data(dlc_data)
        return unlockAllDLC(dlc_data)
    end
end

-- Gestionnaires supplémentaires pour compatibilité étendue
if rawget(_G, "SteamDLCManager") then
    function SteamDLCManager:_check_dlc_data(dlc_data)
        return unlockAllDLC(dlc_data)
    end
end

if rawget(_G, "EpicDLCManager") then
    function EpicDLCManager:_check_dlc_data(dlc_data)
        return unlockAllDLC(dlc_data)
    end
end

-- Hook générique pour toute autre implémentation DLC
local original_check_dlc = _G._check_dlc_data
function _G._check_dlc_data(dlc_data)
    return unlockAllDLC(dlc_data)
end

-- Message de confirmation
if io and io.write then
    io.write("[DLC Unlocker] Tous les DLC sont débloqués !\n")
end
