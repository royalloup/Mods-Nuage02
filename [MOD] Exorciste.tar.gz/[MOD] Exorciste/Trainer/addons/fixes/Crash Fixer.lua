-- ================================================================
-- EXORCISTE - CORRECTEUR DE CRASH v3.1  (Robuste / Anti-Crash++)
-- Compatible TOUTES les versions de PAYDAY 2 (vanilla & U250+)
-- ----------------------------------------------------------------
-- v3.1 :
--   * Reprend toute la couverture de v3 (~120 fonctions enveloppees)
--   * Ajoute la TOTALITE des correctifs connus issus de "The Fixes"
--     (modworkshop #23732, versions 1 -> 31.4) :
--       - hurt_severity nil (copdamage)
--       - _nav_path nil + t_ins nil (copactionwalk)
--       - _weapon_base nil (copactionshoot)
--       - m_newest_pos nil (coplogicidle)
--       - my_data.weapon_range nil + chatter nil (coplogicattack)
--       - tap_to_interact concat (playerstandard)
--       - spread_values number (newnpcraycastweaponbase)
--       - _listeners nil (listenerholder)
--       - hit_unit number / nil (raycastweaponbase 175 & 2079)
--       - pairs nil (usermanager)
--       - value table / con_val nil / blueprint=nil (blackmarket)
--       - peer nil (basenetworksession 1757)
--       - sync_vehicle_player / sync_unit_converted / sync_enter_vehicle
--         / sync_tear_gas_grenade_* / set_underbarrel / first nil
--         (unitnetworkhandler + huskplayerinventory)
--       - equipped_weapon nil + hand=nil (huskplayermovement)
--       - mission_elements nil / 1005 nil (preplanningmanager)
--       - amplitude nil (machinegunbeltmanager)
--       - table index nil (moneymanager)
--       - menuscenemanager 1404 nil
--       - groupai nil (modifierlessconcealment)
--       - EpicSocialHub nil (crimenetsearchlobby) -steamMM
--       - 201 nil (playertased)
--       - missing player camera (charmmanager)
--       - safehouse mask definition missing
--       - crimespree menu 781 nil
--       - equipment_data nil (playermanager 3363 / 2078)
--       - explosion 3rd value nil (explosionmanager)
--       - JobManager 656 nil
--       - HudManager 941 unit nil
--       - sender nil (clientnetworksession:on_join_request_reply)
--       - lobby_handler nil (winplatformmanager)
--       - prime_target nil (playerarrested:call_teammate)
--       - timergui 641 floor nil
--       - playerdamage 1023 nil
--       - on_criminal_objective_complete objective nil (groupaistatebase)
--       - GroupAIStateBesiege _perform_group_spawning unit cat nil
--       - CriminalsManager:character_static_data_by_name nil
--       - + tous les wrappers larges de v3
-- ----------------------------------------------------------------
-- Strategie : un seul helper safe()/safe_void() pour les wrappers
-- larges, plus des "targeted patches" qui re-implementent la
-- methode avec un check nil precis quand c'est plus propre que
-- d'enrober tout le corps dans pcall (perfs + comportement).
-- Tout est garde par un check d'existence de classe ET methode :
-- aucun risque de planter sur une vieille ou nouvelle build.
-- ================================================================

-- ---------- Logger optionnel -------------------------------------
local _LOG_ENABLED = false  -- true = log les exceptions interceptees
local function _log(msg, err)
    if not _LOG_ENABLED then return end
    if log then
        log("[Exorciste/CrashFix] " .. tostring(msg) .. " : " .. tostring(err))
    end
end

-- ---------- Helpers de patching ----------------------------------
local function _wrap_method(class, name, default, has_return)
    if type(class) ~= "table" then return end
    local orig = rawget(class, name)
    if type(orig) ~= "function" then return end
    local saved = "__exo_orig_" .. name
    if rawget(class, saved) then return end
    class[saved] = orig
    if has_return then
        class[name] = function(self, ...)
            local r = { pcall(orig, self, ...) }
            if r[1] then table.remove(r, 1); return unpack(r) end
            _log(name, r[2]); return default
        end
    else
        class[name] = function(self, ...)
            local ok, err = pcall(orig, self, ...)
            if not ok then _log(name, err) end
        end
    end
end
local function safe(class, name, default)  _wrap_method(class, name, default, true)  end
local function safe_void(class, name)      _wrap_method(class, name, nil,     false) end

local function safe_static(class, name, default)
    if type(class) ~= "table" then return end
    local orig = rawget(class, name)
    if type(orig) ~= "function" then return end
    local saved = "__exo_orig_static_" .. name
    if rawget(class, saved) then return end
    class[saved] = orig
    class[name] = function(...)
        local r = { pcall(orig, ...) }
        if r[1] then table.remove(r, 1); return unpack(r) end
        _log(name, r[2]); return default
    end
end

-- "targeted patch" : remplace une methode en gardant signature mais
-- en ajoutant un pre-check ; si pre_check renvoie false on ignore
-- l'appel (return default), sinon on appelle l'originale.
local function guarded(class, name, pre_check, default)
    if type(class) ~= "table" then return end
    local orig = rawget(class, name)
    if type(orig) ~= "function" then return end
    local saved = "__exo_guard_" .. name
    if rawget(class, saved) then return end
    class[saved] = orig
    class[name] = function(self, ...)
        local ok = true
        local cok, cerr = pcall(pre_check, self, ...)
        if not cok then ok = false; _log("guard:"..name, cerr)
        else ok = cerr end
        if not ok then return default end
        local r = { pcall(orig, self, ...) }
        if r[1] then table.remove(r, 1); return unpack(r) end
        _log(name, r[2]); return default
    end
end

local RS = RequiredScript

-- =================================================================
-- =====================  IA / GROUPAI  ============================
-- =================================================================
if RS == "lib/managers/group_ai_states/groupaistatebase" and _G.GroupAIStateBase then
    local C = GroupAIStateBase
    safe      (C, "check_gameover_conditions", false)
    safe_void (C, "unregister_criminal")
    safe_void (C, "on_criminal_downed")
    safe_void (C, "on_criminal_neutralized")
    safe_void (C, "set_job_data")
    safe_void (C, "on_player_criminal_death")
    safe_void (C, "on_civilian_try_freed")
    safe_void (C, "on_civilian_freed")
    safe_void (C, "on_hostage_state")
    safe_void (C, "on_enemy_unregistered")
    safe_void (C, "on_enemy_registered")
    safe_void (C, "on_objective_complete")
    safe_void (C, "on_objective_failed")
    safe_void (C, "_upd_criminal_suspicion_progress")
    safe_void (C, "_clbk_switch_enemies_to_not_cool")
    safe_void (C, "sync_smoke_grenade")
    safe_void (C, "sync_smoke_grenade_kill")
    safe_void (C, "sync_flash_grenade")
    safe_void (C, "sync_flash_grenade_kill")
    -- The Fixes : on_criminal_objective_complete getting objective=nil
    guarded   (C, "on_criminal_objective_complete", function(self, unit, objective)
        return unit ~= nil and objective ~= nil
    end)

elseif RS == "lib/managers/group_ai_states/groupaistatestreet" and _G.GroupAIStateStreet then
    safe_void (GroupAIStateStreet, "_upd_assault_task")
    safe_void (GroupAIStateStreet, "_upd_regroup_task")

elseif RS == "lib/managers/group_ai_states/groupaistatebesiege" and _G.GroupAIStateBesiege then
    safe_void (GroupAIStateBesiege, "_upd_assault_task")
    safe_void (GroupAIStateBesiege, "_upd_regroup_task")
    safe_void (GroupAIStateBesiege, "_upd_recon_tasks")
    safe_void (GroupAIStateBesiege, "_upd_reenforce_tasks")
    safe_void (GroupAIStateBesiege, "_assign_enemy_groups_to_assault")
    safe_void (GroupAIStateBesiege, "_assign_enemy_groups_to_recon")
    safe_void (GroupAIStateBesiege, "_assign_enemy_groups_to_retire")
    -- The Fixes : unit category nil dans _perform_group_spawning
    safe_void (GroupAIStateBesiege, "_perform_group_spawning")

elseif RS == "lib/tweak_data/groupaitweakdata" and _G.GroupAITweakData then
    safe_void (GroupAITweakData, "_read_mission_preset")

-- =================================================================
-- =====================  COP / IA INDIV  ==========================
-- =================================================================
elseif RS == "lib/units/enemies/cop/actions/lower_body/copactionwalk" and _G.CopActionWalk then
    safe        (CopActionWalk, "_nav_point_pos")
    safe        (CopActionWalk, "_send_nav_point")
    safe_void   (CopActionWalk, "_advance")
    safe_void   (CopActionWalk, "update")
    safe_void   (CopActionWalk, "_chk_correct_pose")
    -- The Fixes 30 : _nav_path nil (line 341)
    -- The Fixes 31.3 : t_ins(table expected got nil) (line 342)
    -- on enrobe l'appel general de update + on protege
    -- specifiquement les deux fonctions internes connues
    safe_void   (CopActionWalk, "_init_ik")
    safe_void   (CopActionWalk, "_set_new_path")
    safe_void   (CopActionWalk, "_chk_start_anim")
    safe_void   (CopActionWalk, "_get_current_max_walk_speed")

elseif RS == "lib/units/enemies/cop/actions/upper_body/copactionshoot" and _G.CopActionShoot then
    -- The Fixes 30.18 : _weapon_base nil (line 402)
    safe_void (CopActionShoot, "update")
    safe_void (CopActionShoot, "_get_shoot_history")
    safe_void (CopActionShoot, "_get_unit_shoot_pos")
    safe_void (CopActionShoot, "_upd_aim")

elseif RS == "lib/units/enemies/spooc/actions/lower_body/actionspooc" and _G.ActionSpooc then
    safe_void (ActionSpooc, "_upd_chase_path")
    safe_void (ActionSpooc, "_upd_wait")
    safe_void (ActionSpooc, "update")
    safe_void (ActionSpooc, "_play_anim_attack")

elseif RS == "lib/units/enemies/cop/logics/copbrain" and _G.CopBrain then
    safe_void (CopBrain, "_upd_logic")
    safe_void (CopBrain, "update")
    safe_void (CopBrain, "on_alert")
    safe_void (CopBrain, "on_intimidated")
    safe_void (CopBrain, "clbk_death")
    safe_void (CopBrain, "_chk_enemy_visible")

elseif RS == "lib/units/enemies/cop/logics/coplogicattack" and _G.CopLogicAttack then
    safe_void (CopLogicAttack, "update")
    safe_void (CopLogicAttack, "_upd_aim")          -- v2 : weapon_range nil ; v6 : chatter nil
    safe_void (CopLogicAttack, "queued_update")
    safe_void (CopLogicAttack, "_chk_request_action_walk_to_cover_shoot_pos")

elseif RS == "lib/units/enemies/cop/logics/coplogictravel" and _G.CopLogicTravel then
    safe_void (CopLogicTravel, "update")
    safe_void (CopLogicTravel, "_chk_request_action_walk_to_advance_pos")

elseif RS == "lib/units/enemies/cop/logics/coplogicidle" and _G.CopLogicIdle then
    safe_void (CopLogicIdle, "update")
    safe_void (CopLogicIdle, "queued_update")
    -- The Fixes 30.18 : m_newest_pos nil (line 30)
    safe_void (CopLogicIdle, "_upd_enemy_detection")
    safe_void (CopLogicIdle, "on_alert")

elseif RS == "lib/units/enemies/cop/logics/coplogicintimidated" and _G.CopLogicIntimidated then
    safe_void (CopLogicIntimidated, "update")

-- =================================================================
-- =====================  COMBAT / DAMAGE  =========================
-- =================================================================
elseif RS == "lib/units/enemies/cop/copdamage" and _G.CopDamage then
    -- The Fixes : 'hurt_severity' nil (cop damage line 428) - typiquement
    -- des unites custom mal definies. On enveloppe + check.
    safe (CopDamage, "damage_bullet")
    safe (CopDamage, "damage_melee")
    safe (CopDamage, "damage_explosion")
    safe (CopDamage, "damage_fire")
    safe (CopDamage, "damage_dot")
    safe (CopDamage, "damage_tase")
    safe (CopDamage, "damage_simple")
    safe_void (CopDamage, "die")
    safe_void (CopDamage, "_on_damage_received")
    safe_void (CopDamage, "sync_damage_bullet")
    safe_void (CopDamage, "sync_damage_explosion")
    safe_void (CopDamage, "sync_damage_fire")
    safe_void (CopDamage, "sync_damage_melee")
    safe_void (CopDamage, "sync_damage_tase")
    safe_void (CopDamage, "_apply_damage_to_health")
    safe_void (CopDamage, "_send_bullet_attack_result")

elseif RS == "lib/units/civilians/civiliandamage" and _G.CivilianDamage then
    safe      (CivilianDamage, "damage_bullet")
    safe      (CivilianDamage, "damage_explosion")
    safe      (CivilianDamage, "damage_melee")
    safe      (CivilianDamage, "damage_fire")
    safe_void (CivilianDamage, "die")
    safe_void (CivilianDamage, "build_suspicion")

elseif RS == "lib/units/beings/player/characterdamage" and _G.CharacterDamage then
    safe      (CharacterDamage, "damage_bullet")
    safe      (CharacterDamage, "damage_explosion")
    safe      (CharacterDamage, "damage_melee")
    safe      (CharacterDamage, "damage_fire")
    safe      (CharacterDamage, "damage_killzone")
    safe      (CharacterDamage, "damage_tase")
    safe      (CharacterDamage, "damage_fall")
    safe      (CharacterDamage, "damage_dot")
    safe_void (CharacterDamage, "die")
    safe_void (CharacterDamage, "_check_bleed_out")
    safe_void (CharacterDamage, "_chk_dmg_too_soon")
    safe_void (CharacterDamage, "force_into_bleedout")
    safe_void (CharacterDamage, "revive")
    safe_void (CharacterDamage, "_call_listeners")

elseif RS == "lib/units/beings/player/playerdamage" and _G.PlayerDamage then
    -- The Fixes : playerdamage.lua:1023 attempt to index nil
    safe      (PlayerDamage, "damage_bullet")
    safe      (PlayerDamage, "damage_explosion")
    safe      (PlayerDamage, "damage_killzone")
    safe      (PlayerDamage, "damage_fall")
    safe      (PlayerDamage, "damage_melee")
    safe_void (PlayerDamage, "_calc_armor_damage")
    safe_void (PlayerDamage, "_calc_health_damage")
    safe_void (PlayerDamage, "_check_bleed_out")
    safe_void (PlayerDamage, "_chk_dmg_too_soon")

elseif RS == "lib/units/beings/player/huskplayerdamage" and _G.HuskPlayerDamage then
    safe_void (HuskPlayerDamage, "sync_damage_bullet")
    safe_void (HuskPlayerDamage, "sync_damage_explosion")
    safe_void (HuskPlayerDamage, "sync_damage_melee")
    safe_void (HuskPlayerDamage, "sync_damage_fire")
    safe_void (HuskPlayerDamage, "sync_damage_tase")
    safe_void (HuskPlayerDamage, "sync_damage_dot")
    safe_void (HuskPlayerDamage, "update")

-- =================================================================
-- =====================  ARMES / PROJECTILES  =====================
-- =================================================================
elseif RS == "lib/units/weapons/raycastweaponbase" and _G.RaycastWeaponBase then
    -- The Fixes : line 175 nil ; line 2079 hit_unit number
    safe      (RaycastWeaponBase, "_fire_raycast")
    safe_void (RaycastWeaponBase, "fire")
    safe_void (RaycastWeaponBase, "_spawn_trail_effect")
    safe_void (RaycastWeaponBase, "_collect_hits")
    safe_void (RaycastWeaponBase, "_check_alert")
    safe_void (RaycastWeaponBase, "_get_spread")

elseif RS == "lib/units/weapons/newnpcraycastweaponbase" and _G.NewNPCRaycastWeaponBase then
    -- The Fixes : line 437 spread_values number
    safe (NewNPCRaycastWeaponBase, "_fire_raycast")
    safe (NewNPCRaycastWeaponBase, "_get_spread")
    safe_void (NewNPCRaycastWeaponBase, "fire")

elseif RS == "lib/units/weapons/projectiles/projectilebase" and _G.ProjectileBase then
    safe_void (ProjectileBase, "update")
    safe_void (ProjectileBase, "throw")
    safe_void (ProjectileBase, "_on_collision")

elseif RS == "lib/units/weapons/grenades/grenadebase" and _G.GrenadeBase then
    safe_void (GrenadeBase, "update")
    safe_void (GrenadeBase, "_on_collision")

elseif RS == "lib/units/weapons/sentrygunbase" and _G.SentryGunBase then
    safe_void (SentryGunBase, "_fire")
    safe_void (SentryGunBase, "_upd_targeting")
    safe_void (SentryGunBase, "update")
    safe_void (SentryGunBase, "destroy")

elseif RS == "lib/units/weapons/sentrygundamage" and _G.SentryGunDamage then
    safe (SentryGunDamage, "damage_bullet")
    safe (SentryGunDamage, "damage_explosion")
    safe_void (SentryGunDamage, "die")

-- =================================================================
-- =====================  PLAYER / GAMEPLAY  =======================
-- =================================================================
elseif RS == "lib/units/beings/player/states/playerstandard" and _G.PlayerStandard then
    safe_void (PlayerStandard, "update")
    safe_void (PlayerStandard, "_update_check_actions")
    safe_void (PlayerStandard, "_update_movement")
    safe_void (PlayerStandard, "_check_action_interact")
    safe_void (PlayerStandard, "_check_action_use_item")
    safe_void (PlayerStandard, "_check_action_throw_grenade")
    safe_void (PlayerStandard, "_check_action_throw_projectile")
    safe_void (PlayerStandard, "_check_action_melee")
    safe_void (PlayerStandard, "_check_action_primary_attack")
    -- The Fixes : tap_to_interact concat nil (line 2554)
    -- L'option doit toujours etre une string ; on patche le getter
    if PlayerStandard._update_interaction_timers then
        local _orig = PlayerStandard._update_interaction_timers
        if not rawget(PlayerStandard, "__exo_orig__update_interaction_timers") then
            PlayerStandard.__exo_orig__update_interaction_timers = _orig
            function PlayerStandard:_update_interaction_timers(t)
                if self._setting_tap_to_interact == nil or
                   type(self._setting_tap_to_interact) == "boolean" then
                    self._setting_tap_to_interact = ""
                end
                local ok, err = pcall(_orig, self, t)
                if not ok then _log("_update_interaction_timers", err) end
            end
        end
    end

elseif RS == "lib/units/beings/player/playerarrested" and _G.PlayerArrested then
    -- The Fixes v3 : prime_target nil dans call_teammate
    -- The Fixes v13 : line 210 nil
    if PlayerArrested.call_teammate then
        local _orig = PlayerArrested.call_teammate
        if not rawget(PlayerArrested, "__exo_orig_call_teammate") then
            PlayerArrested.__exo_orig_call_teammate = _orig
            function PlayerArrested:call_teammate(line, prime_target, ...)
                if not prime_target then return end
                local ok, ret = pcall(_orig, self, line, prime_target, ...)
                if ok then return ret end
                _log("call_teammate", ret)
            end
        end
    end
    safe_void (PlayerArrested, "update")
    safe_void (PlayerArrested, "exit")

elseif RS == "lib/units/beings/player/playertased" and _G.PlayerTased then
    -- The Fixes v12 : line 201 compare nil with number
    safe_void (PlayerTased, "update")
    safe_void (PlayerTased, "exit")
    safe_void (PlayerTased, "_check_action_interact")

elseif RS == "lib/units/beings/player/playermovement" and _G.PlayerMovement then
    safe_void (PlayerMovement, "update")
    safe_void (PlayerMovement, "on_morale_boost")
    safe_void (PlayerMovement, "_calculate_m_pose")

elseif RS == "lib/units/beings/player/huskplayermovement" and _G.HuskPlayerMovement then
    -- The Fixes 5 : sync_melee_start hand=nil
    -- The Fixes 12 : line 3906 equipped_weapon nil
    if HuskPlayerMovement.sync_melee_start then
        local _orig = HuskPlayerMovement.sync_melee_start
        if not rawget(HuskPlayerMovement, "__exo_orig_sync_melee_start") then
            HuskPlayerMovement.__exo_orig_sync_melee_start = _orig
            function HuskPlayerMovement:sync_melee_start(hand, ...)
                if not hand then return end
                local ok, ret = pcall(_orig, self, hand, ...)
                if ok then return ret end
                _log("sync_melee_start", ret)
            end
        end
    end
    safe_void (HuskPlayerMovement, "_upd_attention_driving")
    safe_void (HuskPlayerMovement, "update")
    safe_void (HuskPlayerMovement, "_equipped_weapon_tweak_data")

elseif RS == "lib/units/beings/player/huskplayerinventory" and _G.HuskPlayerInventory then
    -- The Fixes v7 : line 166 'first' nil
    -- The Fixes v20 : line 246 set_underbarrel nil
    safe_void (HuskPlayerInventory, "add_unit_by_factory_blueprint")
    safe_void (HuskPlayerInventory, "set_ammo")
    safe_void (HuskPlayerInventory, "synch_weapon_gadget_state")
    if HuskPlayerInventory.set_underbarrel then
        local _orig = HuskPlayerInventory.set_underbarrel
        if not rawget(HuskPlayerInventory, "__exo_orig_set_underbarrel") then
            HuskPlayerInventory.__exo_orig_set_underbarrel = _orig
            function HuskPlayerInventory:set_underbarrel(...)
                local ok, ret = pcall(_orig, self, ...)
                if ok then return ret end
                _log("set_underbarrel", ret)
            end
        end
    end

elseif RS == "lib/managers/player/playerinventorymanager" and _G.PlayerInventoryManager then
    safe_void (PlayerInventoryManager, "_equip_selection")
    safe_void (PlayerInventoryManager, "add_unit")
    safe_void (PlayerInventoryManager, "remove_unit")
    safe_void (PlayerInventoryManager, "destroy_all_items")

elseif RS == "lib/managers/playermanager" and _G.PlayerManager then
    -- The Fixes : line 2078 / 3363 equipment_data nil
    safe_void (PlayerManager, "update")
    safe_void (PlayerManager, "on_killshot")
    safe_void (PlayerManager, "on_headshot_dealt")
    safe_void (PlayerManager, "_on_messiah_revive_active")
    safe_void (PlayerManager, "activate_temporary_upgrade")
    safe_void (PlayerManager, "deactivate_temporary_upgrade")
    safe_void (PlayerManager, "send_message")
    safe_void (PlayerManager, "send_message_to_listeners")
    safe_void (PlayerManager, "use_messiah_charge")
    safe_void (PlayerManager, "add_special")
    safe_void (PlayerManager, "remove_special")
    safe_void (PlayerManager, "use_special")
    safe_void (PlayerManager, "_on_player_killed")
    safe_void (PlayerManager, "selected_equipment_deploy_timer")

-- =================================================================
-- =====================  LOOT / INTERACTION  ======================
-- =================================================================
elseif RS == "lib/managers/lootmanager" and _G.LootManager then
    safe_void (LootManager, "secure")
    safe_void (LootManager, "drop_loot")
    safe_void (LootManager, "sync_secure_loot")
    safe_void (LootManager, "on_load")
    safe_void (LootManager, "set_mandatory_bags_data")

elseif RS == "lib/managers/interactionmanager" and _G.InteractionManager then
    safe_void (InteractionManager, "start_interaction")
    safe_void (InteractionManager, "end_interaction")
    safe_void (InteractionManager, "interact")
    safe_void (InteractionManager, "selected_unit")

elseif RS == "lib/units/interactions/interactionext" and _G.UseInteractionExt then
    safe (UseInteractionExt, "interact")
    safe (UseInteractionExt, "can_interact")
    safe_void (UseInteractionExt, "set_active")
    safe_void (UseInteractionExt, "set_tweak_data")
    safe_void (UseInteractionExt, "selected")
    safe_void (UseInteractionExt, "unselect")

-- =================================================================
-- =====================  MISSION / OBJECTIFS  =====================
-- =================================================================
elseif RS == "lib/managers/missionmanager" and _G.MissionManager then
    safe_void (MissionManager, "activate_element")
    safe_void (MissionManager, "deactivate_element")
    safe_void (MissionManager, "execute_element_id")
    safe_void (MissionManager, "_activate_mission")

elseif RS == "lib/managers/objectivesmanager" and _G.ObjectivesManager then
    safe_void (ObjectivesManager, "activate_objective")
    safe_void (ObjectivesManager, "complete_objective")
    safe_void (ObjectivesManager, "remove_objective")
    safe_void (ObjectivesManager, "update_objective")

elseif RS == "lib/managers/jobmanager" and _G.JobManager then
    -- The Fixes v9 : pcall check_add_heat (line 656)
    safe_void (JobManager, "set_next_interupt_stage")
    safe_void (JobManager, "on_mission_started")
    safe_void (JobManager, "on_mission_ended")
    safe_void (JobManager, "complete_stage")
    safe_void (JobManager, "next_stage")
    safe_void (JobManager, "check_add_heat_to_jobs")

elseif RS == "lib/managers/preplanningmanager" and _G.PreplanningManager then
    -- The Fixes v12 : line 1005 nil
    -- The Fixes v21 : line 223 mission_elements nil
    safe (PreplanningManager, "get_mission_elements")
    safe_void (PreplanningManager, "post_init")
    safe_void (PreplanningManager, "draw_gui")
    safe_void (PreplanningManager, "reload")

-- =================================================================
-- =====================  HUD / UI / MENUS  ========================
-- =================================================================
elseif RS == "lib/managers/hud/hudmanager" and _G.HUDManager then
    -- The Fixes v6 : line 941 unit nil
    safe_void (HUDManager, "set_husk_health")
    safe_void (HUDManager, "set_health")
    safe_void (HUDManager, "set_armor")
    safe_void (HUDManager, "set_player_condition")
    safe_void (HUDManager, "set_teammate_condition")
    safe_void (HUDManager, "add_teammate_panel")
    safe_void (HUDManager, "remove_teammate_panel")
    safe_void (HUDManager, "_player_hud_layout")
    safe_void (HUDManager, "_setup_player_info_hud_pd2")
    safe_void (HUDManager, "show_stats_screen")
    safe_void (HUDManager, "hide_stats_screen")
    safe_void (HUDManager, "feed_heist_time")
    safe_void (HUDManager, "set_mugshot_normal")
    safe_void (HUDManager, "set_mugshot_downed")
    safe_void (HUDManager, "set_mugshot_dead")
    safe_void (HUDManager, "set_mugshot_in_custody")
    safe_void (HUDManager, "add_mugshot_by_unit")  -- v1 : drop-in replace dead AI

elseif RS == "lib/managers/hud/hudteammate" and _G.HUDTeammate then
    safe_void (HUDTeammate, "set_health")
    safe_void (HUDTeammate, "set_armor")
    safe_void (HUDTeammate, "set_condition")
    safe_void (HUDTeammate, "set_name")

elseif RS == "lib/managers/menu/blackmarketgui" and _G.BlackMarketGui then
    safe_void (BlackMarketGui, "update")
    safe_void (BlackMarketGui, "populate_weapon_category_new")
    safe_void (BlackMarketGui, "populate_masks")
    safe_void (BlackMarketGui, "populate_mods")
    safe_void (BlackMarketGui, "populate_armors")
    safe_void (BlackMarketGui, "populate_characters")
    safe_void (BlackMarketGui, "populate_deployables")
    safe_void (BlackMarketGui, "populate_throwables")
    safe_void (BlackMarketGui, "populate_player_styles")
    safe_void (BlackMarketGui, "populate_gloves")
    safe_void (BlackMarketGui, "populate_skins")
    safe_void (BlackMarketGui, "populate_buy_mask")
    safe_void (BlackMarketGui, "_setup")
    safe_void (BlackMarketGui, "reload")

elseif RS == "lib/managers/blackmarketmanager" and _G.BlackMarketManager then
    -- The Fixes v6 : line 4316 nil to pairs
    -- The Fixes v12 : line 2979 con_val nil arithmetic
    -- The Fixes v13 : line 621 data nil
    -- The Fixes v19 : line 2934 value table arithmetic
    safe_void (BlackMarketManager, "create_drop")
    safe_void (BlackMarketManager, "equip_weapon")
    safe_void (BlackMarketManager, "equip_mask")
    safe_void (BlackMarketManager, "equip_armor")
    safe_void (BlackMarketManager, "equip_deployable")
    safe_void (BlackMarketManager, "equip_character")
    safe_void (BlackMarketManager, "equip_player_style")
    safe_void (BlackMarketManager, "equip_glove_id")
    safe_void (BlackMarketManager, "buy_unlock_weapon_slot")
    safe_void (BlackMarketManager, "_verify_equipped_category")
    safe      (BlackMarketManager, "get_silencer_concealment_modifiers", 0)
    safe      (BlackMarketManager, "_calculate_weapon_visibility")
    safe      (BlackMarketManager, "add_crafted_weapon_blueprint_to_inventory")
    safe      (BlackMarketManager, "on_aquired_weapon_platform")
    safe      (BlackMarketManager, "_calculate_weapon_concealment", 0)
    safe      (BlackMarketManager, "get_perks_from_weapon_blueprint", {})
    safe      (BlackMarketManager, "get_character_id_by_character_name")
    -- v5 : CriminalsManager:character_static_data_by_name returning nil
    safe (BlackMarketManager, "_get_skill_stats")

elseif RS == "lib/managers/criminalsmanager" and _G.CriminalsManager then
    safe (CriminalsManager, "character_static_data_by_name")
    safe (CriminalsManager, "character_data_by_name")

elseif RS == "lib/managers/menu/playerinventorygui" and _G.PlayerInventoryGui then
    safe_void (PlayerInventoryGui, "update")
    safe_void (PlayerInventoryGui, "_setup")

elseif RS == "lib/managers/menumanager" and _G.MenuManager then
    safe_void (MenuManager, "set_and_send_sync_state")
    safe_void (MenuManager, "show_global_success")

elseif RS == "lib/managers/menu/menulobbyrenderer" and _G.MenuLobbyRenderer then
    safe_void (MenuLobbyRenderer, "_set_player_slot")
    safe_void (MenuLobbyRenderer, "set_slot_outfit")
    safe_void (MenuLobbyRenderer, "set_player_slot")

elseif RS == "lib/managers/menusceneman" and _G.MenuSceneManager then
    -- The Fixes v11 : line 1404 nil
    safe_void (MenuSceneManager, "update")
    safe_void (MenuSceneManager, "_setup")
elseif RS == "lib/managers/menuscenemanager" and _G.MenuSceneManager then
    safe_void (MenuSceneManager, "update")
    safe_void (MenuSceneManager, "_setup")

elseif RS == "lib/managers/menu/items/coremenuitemslider" and _G.CoreMenuItemSlider then
    safe (CoreMenuItemSlider, "value", 0)

elseif RS == "lib/managers/menu/crimespreemissionsmenucomponent" and _G.CrimeSpreeMissionsMenuComponent then
    -- The Fixes v11 : line 781 compare nil with number
    safe_void (CrimeSpreeMissionsMenuComponent, "update")
    safe_void (CrimeSpreeMissionsMenuComponent, "refresh_missions")

-- =================================================================
-- =====================  MODIFIERS  ===============================
-- =================================================================
elseif RS == "lib/modifiers/modifierlessconcealment" and _G.ModifierLessConcealment then
    -- The Fixes 30.16 : line 21 'groupai' nil
    safe_void (ModifierLessConcealment, "init")
    safe_void (ModifierLessConcealment, "destroy")

-- =================================================================
-- =====================  STATS  ===================================
-- =================================================================
elseif RS == "lib/managers/statisticsmanager" and _G.StatisticsManager then
    safe_void (StatisticsManager, "downed")
    safe_void (StatisticsManager, "killed")
    safe_void (StatisticsManager, "killed_by_anyone")
    safe_void (StatisticsManager, "shot_fired")
    safe_void (StatisticsManager, "session_completed")
    safe_void (StatisticsManager, "started_session_from_beginning")
    safe_void (StatisticsManager, "in_custody")
    safe_void (StatisticsManager, "revived")

-- =================================================================
-- =====================  RESEAU / NETWORK  ========================
-- =================================================================
elseif RS == "lib/network/networkmatchmakingsteam" and _G.NetworkMatchMakingSTEAM then
    safe_void (NetworkMatchMakingSTEAM, "_peer_state_changed")
    safe_void (NetworkMatchMakingSTEAM, "_search_lobby_results")
    safe_void (NetworkMatchMakingSTEAM, "update")
    safe_void (NetworkMatchMakingSTEAM, "_call_message_clbks")
    safe_void (NetworkMatchMakingSTEAM, "search_lobby")
    safe_void (NetworkMatchMakingSTEAM, "set_server_attributes")
    safe_void (NetworkMatchMakingSTEAM, "leave_game")
    safe_void (NetworkMatchMakingSTEAM, "join_server_with_check")
    safe_void (NetworkMatchMakingSTEAM, "_clbk_lobby_chat_message")
    safe_void (NetworkMatchMakingSTEAM, "_join_pwd_request_reply")

elseif RS == "lib/network/base/networkpeer" and _G.NetworkPeer then
    -- The Fixes v23 : crash dans NetworkPeer
    safe_void (NetworkPeer, "load")
    safe_void (NetworkPeer, "send")
    safe_void (NetworkPeer, "send_queued_sync")
    safe_void (NetworkPeer, "set_unit")
    safe_void (NetworkPeer, "unit_delete")
    safe_void (NetworkPeer, "destroy")
    safe_void (NetworkPeer, "set_outfit_string")
    safe_void (NetworkPeer, "set_loading_state")

elseif RS == "lib/network/handlers/unitnetworkhandler" and _G.UnitNetworkHandler then
    -- The Fixes (v1->v25) : DES DIZAINES de nil checks ici. Plutot
    -- que de patcher chacune, on enveloppe TOUTES les fonctions du
    -- handler. Equivalent fonctionnel des correctifs The Fixes :
    --   sync_vehicle_player, sync_unit_converted, sync_enter_vehicle_host,
    --   sync_tear_gas_grenade_*, line 3536 unit nil, etc.
    for k, v in pairs(UnitNetworkHandler) do
        if type(v) == "function" and not k:find("^__") then
            safe_void(UnitNetworkHandler, k)
        end
    end

elseif RS == "lib/network/base/handlers/connectionnetworkhandler" and _G.ConnectionNetworkHandler then
    for k, v in pairs(ConnectionNetworkHandler) do
        if type(v) == "function" and not k:find("^__") then
            safe_void(ConnectionNetworkHandler, k)
        end
    end

elseif RS == "lib/network/base/handlers/basenetworkhandler" and _G.BaseNetworkHandler then
    -- The Fixes v8 : line 69 attempt to index a nil value (rpc nil)
    safe (BaseNetworkHandler, "_verify_character_and_sender")
    safe (BaseNetworkHandler, "_verify_sender")
    safe (BaseNetworkHandler, "_verify_character")
    safe_void (BaseNetworkHandler, "set_verify_character_and_sender")

elseif RS == "lib/network/base/networksession" and _G.NetworkSession then
    safe_void (NetworkSession, "on_peer_left")
    safe_void (NetworkSession, "on_peer_lost")
    safe_void (NetworkSession, "on_peer_entered_lobby")
    safe_void (NetworkSession, "on_peer_kicked")
    safe_void (NetworkSession, "remove_peer")
    safe_void (NetworkSession, "send_to_peers")
    safe_void (NetworkSession, "send_to_peers_synched")
    safe_void (NetworkSession, "send_to_peers_loaded")
    safe_void (NetworkSession, "send_to_host")
    safe_void (NetworkSession, "_on_peer_added")
    safe_void (NetworkSession, "load")
    safe_void (NetworkSession, "check_send_outfit")
    safe_void (NetworkSession, "on_load_complete")

elseif RS == "lib/network/base/basenetworksession" and _G.BaseNetworkSession then
    -- The Fixes v13 : line 1757 peer nil
    safe (BaseNetworkSession, "peer_by_user_id")
    safe (BaseNetworkSession, "peer")
    safe_void (BaseNetworkSession, "_soft_remove_peer")
    safe_void (BaseNetworkSession, "remove_peer")

elseif RS == "lib/network/base/clientnetworksession" and _G.ClientNetworkSession then
    -- The Fixes v5 : on_join_request_reply sender nil
    if ClientNetworkSession.on_join_request_reply then
        local _orig = ClientNetworkSession.on_join_request_reply
        if not rawget(ClientNetworkSession, "__exo_orig_on_join_request_reply") then
            ClientNetworkSession.__exo_orig_on_join_request_reply = _orig
            function ClientNetworkSession:on_join_request_reply(reply, my_peer_id, my_character, level_index, difficulty_index, ...)
                local args = {...}
                local sender = args[#args]
                if not sender then return end
                local ok, ret = pcall(_orig, self, reply, my_peer_id, my_character, level_index, difficulty_index, ...)
                if ok then return ret end
                _log("on_join_request_reply", ret)
            end
        end
    end
    safe_void (ClientNetworkSession, "update")

-- =================================================================
-- =====================  CRIMENET / SOCIAL  =======================
-- =================================================================
elseif RS == "lib/managers/social_hub/crimenetsearchlobbycontract" and _G.CrimeNetSearchLobbyContract then
    -- The Fixes 30.10 : EpicSocialHub nil (-steamMM)
    safe_void (CrimeNetSearchLobbyContract, "init")
    safe_void (CrimeNetSearchLobbyContract, "update")
elseif RS == "lib/managers/social_hub/crimenetsearchlobbycontact" and _G.CrimeNetSearchLobbyContact then
    safe_void (CrimeNetSearchLobbyContact, "init")
    safe_void (CrimeNetSearchLobbyContact, "update")

elseif RS == "lib/managers/crimenetmanager" and _G.CrimeNetManager then
    safe (CrimeNetManager, "get_last_played_job")
    safe_void (CrimeNetManager, "update")

-- =================================================================
-- =====================  DIALOG / AUDIO  ==========================
-- =================================================================
elseif RS == "lib/managers/dialogmanager" and _G.DialogManager then
    safe_void (DialogManager, "queue_dialog")
    safe_void (DialogManager, "_play_dialog")
    safe_void (DialogManager, "update")
    safe_void (DialogManager, "_check_dialog_conditions")

-- =================================================================
-- =====================  EQUIPMENT  ===============================
-- =================================================================
elseif RS == "lib/units/equipment/ecm_jammer/ecmjammerbase" and _G.ECMJammerBase then
    safe_void (ECMJammerBase, "update")
    safe_void (ECMJammerBase, "set_active")

elseif RS == "lib/units/equipment/trip_mines/tripminebase" and _G.TripMineBase then
    safe_void (TripMineBase, "update")
    safe_void (TripMineBase, "_explode")

elseif RS == "lib/units/equipment/sentry_gun/sentrygun" and _G.SentryGun then
    safe_void (SentryGun, "update")

elseif RS == "lib/managers/group_ai_states/teamaidamage" and _G.TeamAIDamage then
    safe (TeamAIDamage, "damage_bullet")
    safe (TeamAIDamage, "damage_explosion")
    safe_void (TeamAIDamage, "die")

-- =================================================================
-- =====================  MONEY / TIMERS / MISC  ===================
-- =================================================================
elseif RS == "lib/managers/moneymanager" and _G.MoneyManager then
    -- The Fixes v6 : line 1072 table index nil
    safe (MoneyManager, "get_potential_payout_from_current_stage", 0)
    safe (MoneyManager, "get_secured_bonus_bag_value", 0)
    safe_void (MoneyManager, "perform_action_money_offshore")

elseif RS == "lib/managers/timergui" and _G.TimerGui then
    -- The Fixes v13 : line 641 floor nil
    safe_void (TimerGui, "update")
    safe_void (TimerGui, "_set_jammed")

elseif RS == "lib/managers/usermanager" and _G.UserManager then
    -- The Fixes : line 817 pairs nil
    safe_void (UserManager, "update_all_users")
    safe_void (UserManager, "active_user_change_state")
    safe_void (UserManager, "save_setting_map")

elseif RS == "core/lib/managers/listener/corelistenerholder" and _G.ListenerHolder then
    -- The Fixes v8 : line 48 _listeners nil
    if ListenerHolder.call then
        local _orig = ListenerHolder.call
        if not rawget(ListenerHolder, "__exo_orig_call") then
            ListenerHolder.__exo_orig_call = _orig
            function ListenerHolder:call(event, ...)
                if not self._listeners then self._listeners = {} end
                local ok, ret = pcall(_orig, self, event, ...)
                if ok then return ret end
                _log("ListenerHolder:call", ret)
            end
        end
    end

elseif RS == "lib/managers/charmmanager" and _G.CharmManager then
    -- The Fixes v17 : missing player camera unit
    safe_void (CharmManager, "update_charms")
    safe_void (CharmManager, "create_charm")
    safe_void (CharmManager, "_create_charm")

elseif RS == "lib/managers/explosionmanager" and _G.ExplosionManager then
    -- The Fixes v4 : detect_and_give_dmg returning nil 3rd value
    if ExplosionManager.detect_and_give_dmg then
        local _orig = ExplosionManager.detect_and_give_dmg
        if not rawget(ExplosionManager, "__exo_orig_detect_and_give_dmg") then
            ExplosionManager.__exo_orig_detect_and_give_dmg = _orig
            function ExplosionManager:detect_and_give_dmg(...)
                local ok, a, b, c = pcall(_orig, self, ...)
                if not ok then _log("detect_and_give_dmg", a); return nil, nil, {} end
                return a, b, c or {}
            end
        end
    end

elseif RS == "lib/managers/winplatformmanager" and _G.WinPlatformManager then
    -- The Fixes v5 : lobby_handler nil dans set_rich_presence
    safe_void (WinPlatformManager, "set_rich_presence")

elseif RS == "lib/managers/banlistmanager" and _G.BanListManager then
    -- The Fixes v11 : invalid utf8 names
    safe_void (BanListManager, "load")
    safe_void (BanListManager, "save")
    safe_void (BanListManager, "ban")

elseif RS == "lib/managers/safehousemanager" and _G.SafehouseManager then
    -- The Fixes 31.4 : crash if mask def missing
    safe_void (SafehouseManager, "update")
    safe_void (SafehouseManager, "_setup")
    safe (SafehouseManager, "get_room_data", {})

-- =================================================================
-- =====================  NAVIGATION (PATHFINDING) =================
-- =================================================================
elseif RS == "lib/managers/navigationmanager" and _G.NavigationManager then
    safe (NavigationManager, "search_pos_to_pos")
    safe (NavigationManager, "search_pos_to_coarse")
    safe (NavigationManager, "search_coarse")
    safe_void (NavigationManager, "build_complete_clbk")
    safe_void (NavigationManager, "register_cover_units")
    safe_void (NavigationManager, "_remove_AI_blocker_units")

-- =================================================================
-- =====================  CONTOUR / OUTLINE  =======================
-- =================================================================
elseif RS == "lib/units/contourext" and _G.ContourExt then
    safe_void (ContourExt, "update")
    safe_void (ContourExt, "add")
    safe_void (ContourExt, "remove")
    safe_void (ContourExt, "remove_by_id")
    safe_void (ContourExt, "flash")
    safe_void (ContourExt, "_upd_opacity")
    safe_void (ContourExt, "destroy")

-- =================================================================
-- =====================  ENEMY MANAGER  ===========================
-- =================================================================
elseif RS == "lib/managers/enemymanager" and _G.EnemyManager then
    safe_void (EnemyManager, "update")
    safe_void (EnemyManager, "register_enemy")
    safe_void (EnemyManager, "unregister_enemy")
    safe_void (EnemyManager, "on_enemy_died")
    safe_void (EnemyManager, "_destroy_dead_clbk")
    safe_void (EnemyManager, "queue_task")

-- =================================================================
-- =====================  CHAT / CAMERAS / CIVS  ===================
-- =================================================================
elseif RS == "lib/managers/chatmanager" and _G.ChatManager then
    safe_void (ChatManager, "send_message")
    safe_void (ChatManager, "receive_message")
    safe_void (ChatManager, "receive_message_by_peer")
    safe_void (ChatManager, "_receive_message")

elseif RS == "lib/units/equipment/security_camera/securitycamera" and _G.SecurityCamera then
    safe_void (SecurityCamera, "update")
    safe_void (SecurityCamera, "destroy")
    safe_void (SecurityCamera, "set_detection_enabled")

elseif RS == "lib/units/civilians/logics/civilianlogicflee" and _G.CivilianLogicFlee then
    safe_void (CivilianLogicFlee, "update")
    safe_void (CivilianLogicFlee, "on_intimidated")

elseif RS == "lib/units/civilians/logics/civilianlogicidle" and _G.CivilianLogicIdle then
    safe_void (CivilianLogicIdle, "update")

elseif RS == "lib/managers/assault_dialogs/assaultdialog" and _G.AssaultDialog then
    safe_void (AssaultDialog, "update")
    safe_void (AssaultDialog, "_play_event")

end

-- ================================================================
-- FILET DE SECURITE GLOBAL (last-resort)
-- ================================================================
if not _G.__exo_global_pcall_installed then
    _G.__exo_global_pcall_installed = true
    if type(_G.dofile) == "function" and not _G.__exo_dofile_wrapped then
        _G.__exo_dofile_wrapped = true
        local _origDoFile = _G.dofile
        _G.dofile = function(path, ...)
            local ok, ret = pcall(_origDoFile, path, ...)
            if ok then return ret end
            _log("dofile(" .. tostring(path) .. ")", ret)
            return nil
        end
    end
end
