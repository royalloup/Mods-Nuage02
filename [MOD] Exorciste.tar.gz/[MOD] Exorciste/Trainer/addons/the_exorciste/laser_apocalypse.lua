-- The Exorciste : Laser de l'Apocalypse (rouge sang)
-- Auteur : Exorciste

plugins:new_plugin('laser_apocalypse')

VERSION = '1.0'
CATEGORY = 'the_exorciste'

function MAIN()
    if _G._ExoState and _G._ExoState.enable then
        _G._ExoState.enable('laser')
    end
end

function UNLOAD()
    if _G._ExoState and _G._ExoState.disable then
        _G._ExoState.disable('laser')
    end
end

FINALIZE()
