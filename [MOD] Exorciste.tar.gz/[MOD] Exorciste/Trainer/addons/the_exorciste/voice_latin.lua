-- The Exorciste : Priere en Latin (silence sacre des flics)
-- Auteur : Exorciste
--
-- Note technique : sans fichiers audio personnels (.ogg) il
-- n'est pas possible de remplacer reellement les voix par des
-- chants latins. On installe donc le "silence sacre" : toutes
-- les vocalisations des flics (CopSound:say) sont supprimees,
-- ce qui plonge la scene dans une ambiance d'exorcisme.

plugins:new_plugin('voice_latin')

VERSION = '1.0'
CATEGORY = 'the_exorciste'

function MAIN()
    if _G._ExoState and _G._ExoState.enable then
        _G._ExoState.enable('voice_latin')
    end
end

function UNLOAD()
    if _G._ExoState and _G._ExoState.disable then
        _G._ExoState.disable('voice_latin')
    end
end

FINALIZE()
