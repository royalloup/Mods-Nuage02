-- The Exorciste : Visage qui se retourne (180 degres)
-- Auteur : Exorciste

plugins:new_plugin('head_180')

VERSION = '1.0'
CATEGORY = 'the_exorciste'

function MAIN()
    if _G._ExoState and _G._ExoState.enable then
        _G._ExoState.enable('head_180')
    end
end

function UNLOAD()
    if _G._ExoState and _G._ExoState.disable then
        _G._ExoState.disable('head_180')
    end
end

FINALIZE()
