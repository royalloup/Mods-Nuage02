-- The Exorciste : Levitation des cadavres
-- Auteur : Exorciste

plugins:new_plugin('levitation')

VERSION = '1.0'
CATEGORY = 'the_exorciste'

function MAIN()
    if _G._ExoState and _G._ExoState.enable then
        _G._ExoState.enable('levitation')
    end
end

function UNLOAD()
    if _G._ExoState and _G._ExoState.disable then
        _G._ExoState.disable('levitation')
    end
end

FINALIZE()
