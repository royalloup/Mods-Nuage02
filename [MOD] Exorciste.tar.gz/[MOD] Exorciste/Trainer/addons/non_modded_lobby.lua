-- Purpose: Sets your Lobby to Not modded
-- Author: Exorciste

show_hint("(Non modded Lobby is V.I.P. Only)")