--Purpose: converts all enemies
--Author: baldwin (fix : preload une seule fois + re-fetch managers a chaque clic)

local managers = managers
local plugins = plugins
local g_loaded = plugins.g_loaded
local prequire = plugins.ppr_require
local pairs = pairs
local safecall = safecall

-- "Charge une fois, ne decharge jamais" : avant, le plugin
-- inf_converts etait charge ET decharge a chaque clic, ce qui
-- demandait deux clics avant que le cap de minions soit reellement
-- en place au moment ou la boucle de conversion s'executait.
local _preloaded = false

return function()
        if not _preloaded then
                if not g_loaded( plugins, "inf_converts" ) then
                        prequire( plugins, 'Trainer/addons/stealthmenu/inf_converts', true )
                end
                _preloaded = true
        end

        -- Re-fetch des managers a chaque appel : ils peuvent etre
        -- recrees entre deux missions.
        local AI_State = managers.groupai and managers.groupai:state()
        local convert_hostage_to_criminal = AI_State and AI_State.convert_hostage_to_criminal
        local all_enemies = managers.enemy and managers.enemy:all_enemies()
        if not (AI_State and convert_hostage_to_criminal and all_enemies) then
                return
        end

        for _, ud in pairs( all_enemies ) do
                local unit = ud.unit
                if unit and unit:brain() and unit:brain()._logic_data
                        and not unit:brain()._logic_data.is_converted then
                        --Sometimes it fails to convert single unit
                        safecall( convert_hostage_to_criminal, AI_State, unit )
                end
        end
end
