-- Verificateur de mise a jour - Mod Exorciste
-- L'ancien serveur (bitbucket pirate-perfection) n'existe plus
-- et provoquait un appel HTTP en boucle infinie toutes les 2.5s.
-- Ce fichier est volontairement desactive pour eviter les fuites memoire,
-- les logs spam et les crashs reseau sur les nouvelles versions du jeu.

local Global = Global
if Global then
        Global.update_checked = true
end

return
