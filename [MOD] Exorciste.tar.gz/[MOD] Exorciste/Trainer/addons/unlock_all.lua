-- Unlock All
-- Author: Exorciste
-- Master unlock SAFE : chaque bloc est protege par pcall pour qu'une eventuelle
-- erreur n'empeche pas le reste du trainer de se charger.

local pairs = pairs
local ipairs = ipairs
local pcall = pcall
local managers = managers
local tweak_data = tweak_data

-- ---- 1) PERKS (deck d'armures / specialisations) -------------------------
pcall(function()
if not (managers and managers.skilltree and tweak_data and tweak_data.skilltree
and tweak_data.skilltree.specializations) then return end
for _, specialization in pairs( tweak_data.skilltree.specializations ) do
for _, tree in pairs( specialization ) do
if tree.upgrades then
for _, upgrade in ipairs( tree.upgrades ) do
pcall(function()
managers.upgrades:aquire( upgrade, false )
end)
end
end
end
end
end)

-- ---- 2) CREW (boosts & abilities) ---------------------------------------
pcall(function()
if not (BlackMarketManager and backuper) then return end
backuper:backup('BlackMarketManager.is_crew_item_unlocked')
function BlackMarketManager.is_crew_item_unlocked()
return true
end
end)

-- ---- 3) DLC (toutes plateformes) ----------------------------------------
pcall(function()
local function unlockAllDLC() return true end

if rawget(_G, "WinSteamDLCManager") then
function WinSteamDLCManager:_check_dlc_data() return unlockAllDLC() end
end
if rawget(_G, "WinEpicDLCManager") then
function WinEpicDLCManager:_check_dlc_data() return unlockAllDLC() end
end
if rawget(_G, "WINDLCManager") then
function WINDLCManager:_check_dlc_data() return unlockAllDLC() end
end
if rawget(_G, "SteamDLCManager") then
function SteamDLCManager:_check_dlc_data() return unlockAllDLC() end
end
if rawget(_G, "EpicDLCManager") then
function EpicDLCManager:_check_dlc_data() return unlockAllDLC() end
end
end)

-- ---- 4) ARMOR SKINS -----------------------------------------------------
pcall(function()
if not (BlackMarketManager and tweak_data.economy and tweak_data.economy.armor_skins) then
return
end
function BlackMarketManager:_remove_unowned_armor_skin()
local armor_skins = {}
Global.blackmarket_manager.armor_skins = armor_skins
for id, _ in pairs(tweak_data.economy.armor_skins) do
armor_skins[id] = {unlocked = true}
end
return false
end
end)

-- ---- 5) WEAPON SKINS (deverrouille les skins legendaires) ---------------
pcall(function()
if not (tweak_data.blackmarket and tweak_data.blackmarket.weapon_skins) then return end
for _, data in pairs(tweak_data.blackmarket.weapon_skins) do
data.locked = false
end
end)
