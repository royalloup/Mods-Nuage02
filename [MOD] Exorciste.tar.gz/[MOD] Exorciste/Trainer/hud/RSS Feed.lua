-- Fil RSS - DESACTIVE
-- Les URLs pirateperfection.com et tumblr ne sont plus valides.
-- Ce fichier est desactive pour eviter les crashs reseau.

return
