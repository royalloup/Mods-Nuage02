-- Affiche le texte de version dans le menu principal du jeu

backuper:hijack('MenuNodeMainGui._add_version_string', function(o, self, ... )
        local r = o(self, ...)
        local ok_app, app_ver = pcall(function() return Application:version() end)
        local game_ver = ok_app and app_ver or 'inconnue'
        self._version_string:set_text(string.format(
                " Exorciste Trainer \n Version : %s (%s) \n Version du jeu : %s \n SuperBLT : %s \n par %s ",
                ppr_config.const_version or 'v2.0.0-FR',
                ppr_config.const_edition or 'Exorciste',
                game_ver,
                ppr_config.const_blt_version or 'SuperBLT',
                ppr_config.const_creator or 'Exorciste'
        ))
        self._version_string:set_align(SystemInfo:platform() == Idstring("WIN32") and "center")
        self._version_string:set_color(Color(1, 1, 0.1, 0.1))
        self._version_string:set_name(version_string)
        self._version_string:set_vertical(bottom)
        self._version_string:set_font_size(20)
        self._version_string:set_alpha(1.00)
        self._version_string:set_w(1234)
        self._version_string:set_h(666)
        return r
end)
