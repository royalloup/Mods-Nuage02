-- Texte defilant - VERSION CORRIGEE
-- L'appel HTTP avec une URL vide est supprime (provoquait un crash reseau).
-- Le texte defilant est maintenant desactive par defaut.

return
