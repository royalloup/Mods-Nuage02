-- pubinfloopv2.lua  (Exorciste - patch stabilite v2.3.1)
--
-- Correctifs vs version d'origine :
--   * On ne fait plus "unpack(f)" a chaque frame pour chaque tache : on stocke
--     le nombre d'arguments (n) lors de l'insertion, et on appelle directement
--     pcall(func, a1..a8) sans realloc (jusqu'a 8 arguments suffisent largement
--     pour tous les usages internes du mod). Pour > 8 arguments on retombe
--     sur l'ancien comportement (rare).
--     -> Beaucoup moins de pression GC en jeu, donc moins de micro-freeze.
--
--   * Si une tache echoue de maniere repetee, on l'auto-desactive apres N
--     echecs consecutifs au lieu de continuer a la rappeler indefiniment a
--     chaque frame (cause classique de lag silencieux progressif).
--     -> Une tache cassee n'aspire plus le CPU pour rien.
--
--   * On loggue (au plus une fois par tache) la premiere erreur via les
--     helpers du mod si disponibles, pour faciliter le debug.
--
--   * API publique inchangee : RunNewLoop, RunNewLoopIdent, StopLoopIdent,
--     StopRnLoop, StopAllLoops, AllRunningLoops, executewithdelay restent
--     strictement compatibles avec tout le code existant.

local void = void

local table = table
local random = math.random
local insert = table.insert
local char = string.char

local select = select
local unpack = unpack
local assert = assert
local type = type
local pcall = pcall
local tostring = tostring
local pairs = pairs
local next = next

local os_clock = os.clock

local FAIL_LIMIT = 5  -- nb d'echecs consecutifs avant desactivation auto

local _log_warn = m_log_error or m_log_v or function() end

function GenerateRandomIdent(settings)
        local lenght = settings.len
        local num = settings.num
        local uppercase = settings.up
        local lowercase = settings.low
        local morechars = settings.char
        local result = {}
        local function randomChar()
                local possibilities = {}
                local rand_by_mode = { uppercase = random(65,90),
                        lowercase = random(97,122),
                        num = random(48,57),
                        morechars = function()
                                local poss = { random(33,47), random(58,64), random(91,96), random(123,126) }
                                return poss[random(1,#poss)]
                        end
                }
                if uppercase then insert(possibilities,"uppercase") end
                if lowercase then insert(possibilities,"lowercase") end
                if morechars then insert(possibilities,"morechars") end
                if num then insert(possibilities,"num") end
                local mode = possibilities[random(1,#possibilities)]
                local r
                if mode == "morechars" then
                        r = rand_by_mode["morechars"]()
                else
                        r = rand_by_mode[mode]
                end
                return r
        end
        for _=1,lenght do
                insert(result, char(randomChar()))
        end
        return table.concat(result)
end

local ranThreads = {}
local toAdd = {}
local toRemove = {}

-- Construit une entree de tache : { func, n, a1..an, fails }
local function _build_entry(func, ...)
        local n = select('#', ...)
        local entry = { func, n, ... }
        entry.fails = 0
        return entry
end

function RunNewLoop( func, ... )
        assert(type(func) == 'function', 'Incorrect attributes passed')
        local ident = tostring(random())
        toAdd[ident] = _build_entry(func, ...)
        return ident
end

function RunNewLoopIdent( id, func, ... )
        assert(type(func) == 'function', 'Incorrect attributes passed')
        toAdd[id] = _build_entry(func, ...)
        return id
end

function StopLoopIdent( ident )
        local ret = false
        if ( toAdd[ident] ) then
                toAdd[ident] = nil
                ret = true
        end
        if ( not toRemove[ident] ) then
                local entry = ranThreads[ident]
                if ( entry ) then
                        toRemove[ident] = true
                        -- Empeche la methode d'etre executee si elle est en
                        -- cours d'iteration sur cette frame
                        entry[1] = void
                        ret = true
                end
        end
        return ret
end

function StopRnLoop( func, data )
        for key,tdata in pairs(ranThreads) do
                -- Compat : on regarde func + 1er argument comme avant.
                if tdata[1] == func and tdata[3] == data then
                        toRemove[key] = true
                        tdata[1] = void
                        return true
                end
        end
        return false
end

function StopAllLoops()
        ranThreads = {}
        toRemove = {}
        toAdd = {}
end

function AllRunningLoops()
        return ranThreads
end

-- Executeur rapide pour 0..8 arguments sans realloc.
local function _call_entry(entry)
        local f = entry[1]
        local n = entry[2]
        if n == 0 then return pcall(f)
        elseif n == 1 then return pcall(f, entry[3])
        elseif n == 2 then return pcall(f, entry[3], entry[4])
        elseif n == 3 then return pcall(f, entry[3], entry[4], entry[5])
        elseif n == 4 then return pcall(f, entry[3], entry[4], entry[5], entry[6])
        elseif n == 5 then return pcall(f, entry[3], entry[4], entry[5], entry[6], entry[7])
        elseif n == 6 then return pcall(f, entry[3], entry[4], entry[5], entry[6], entry[7], entry[8])
        elseif n == 7 then return pcall(f, entry[3], entry[4], entry[5], entry[6], entry[7], entry[8], entry[9])
        elseif n == 8 then return pcall(f, entry[3], entry[4], entry[5], entry[6], entry[7], entry[8], entry[9], entry[10])
        else
                -- Fallback rare : > 8 args. On passe par unpack sur la sous-liste.
                return pcall(f, unpack(entry, 3, 2 + n))
        end
end

do
        if not orig__update then
                orig__update = update
        end
        local orig__update = orig__update

        function update( ... )
                orig__update( ... )

                for k, entry in pairs(ranThreads) do
                        local ok, err = _call_entry(entry)
                        if not ok then
                                local fails = (entry.fails or 0) + 1
                                entry.fails = fails
                                if fails == 1 then
                                        -- premier echec : on logge sans spammer
                                        _log_warn("{pubinfloopv2.lua}",
                                                "Tache '"..tostring(k).."' a echoue : "..tostring(err))
                                end
                                if fails >= FAIL_LIMIT then
                                        -- Auto-desactivation pour proteger les FPS.
                                        toRemove[k] = true
                                        entry[1] = void
                                        _log_warn("{pubinfloopv2.lua}",
                                                "Tache '"..tostring(k).."' desactivee apres "
                                                ..FAIL_LIMIT.." echecs consecutifs.")
                                end
                        elseif entry.fails ~= 0 then
                                -- succes : on remet le compteur a zero
                                entry.fails = 0
                        end
                end

                if ( next(toRemove) ) then
                        for key,_ in pairs(toRemove) do
                                ranThreads[key] = nil
                        end
                        toRemove = {}
                end
                if ( next(toAdd) ) then
                        for key,v in pairs(toAdd) do
                                ranThreads[key] = v
                        end
                        toAdd = {}
                end
        end
end

local RunNewLoopIdent = RunNewLoopIdent
local StopLoopIdent = StopLoopIdent

function executewithdelay(callback, delay, id)
        if type(callback) == "function" then
                callback = { func = callback, params = {} }
        end
        local updator
        local clbk = callback.func
        local params = callback.params or {}
        local mark = os_clock()
        local r = function()
                if os_clock() - mark >= delay then
                        clbk(unpack(params))
                        StopLoopIdent(updator)
                end
        end
        if not id then
                id = tostring( random() )
        end
        updator = RunNewLoopIdent(id, r)
        return updator
end
