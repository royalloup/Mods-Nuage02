-- Menu component. Represents progress bar that can be changed by user.
-- Author: Simplity
-- Modernized visuals: dark track + accent fill + value label on the right.

local mouse = Input:mouse()
local mouse_down = mouse.down
local Idstring = Idstring
local left_click = Idstring('0')
local right_click = Idstring('1')
local ceil = math.ceil

local managers = managers
local M_mouse_pointer = managers.mouse_pointer

local game_config = game_config
local togg_vars = togg_vars
local RunNewLoop = RunNewLoop
local callback = callback
local tweak_data = tweak_data
local pd2_small_font = tweak_data.menu.pd2_small_font

local THEME_ACCENT = Color(0.310, 0.760, 0.970)
local THEME_TRACK  = Color(0.078, 0.090, 0.118)
local THEME_BORDER = Color(0.180, 0.200, 0.235)

local Slider = class()

function Slider:init( panel, button )
        local data = button.slider_data

        self.panel = panel
        self.button = button
        self.name = data.name
        self.max = data.max
        local name = self.name
        self.value = togg_vars[ name ] or data.value or 0
        togg_vars[ name ] = self.value

        self:create_gui()
        self.id = RunNewLoop( callback( self, self, "update" ) )
end

function Slider:create_gui()
        local panel = self.panel

        -- Track sits on the right side of the row, leaving room for label text on the left
        local track_w = math.max( panel:w() * 0.50, 180 )
        local track_h = 8

        local slider = panel:panel( { name = "slider", w = panel:w(), h = panel:h(), layer = 2 } )
        self.slider = slider

        local track = slider:panel( { name = "track", w = track_w, h = track_h, layer = 2 } )
        track:set_right( slider:w() - 56 )
        track:set_center_y( slider:h() / 2 )

        -- Track background
        track:rect( {
                name = "track_bg", layer = 1,
                color = THEME_TRACK, alpha = 1.0,
                halign = "grow", valign = "grow"
        } )

        -- Track border
        track:rect( { name = "tk_top",   layer = 2, color = THEME_BORDER, w = track_w, h = 1, x = 0, y = 0 } )
        track:rect( { name = "tk_bot",   layer = 2, color = THEME_BORDER, w = track_w, h = 1, x = 0, y = track_h - 1 } )
        track:rect( { name = "tk_left",  layer = 2, color = THEME_BORDER, w = 1, h = track_h, x = 0, y = 0 } )
        track:rect( { name = "tk_right", layer = 2, color = THEME_BORDER, w = 1, h = track_h, x = track_w - 1, y = 0 } )

        -- Fill (cyan accent)
        self.slider_bg = track:rect( {
                name = "slider_bg", layer = 3,
                color = THEME_ACCENT, alpha = 0.95,
                w = 0, h = track_h, x = 0, y = 0
        } )

        -- Thumb
        self.thumb = slider:rect( {
                name = "thumb", layer = 5,
                color = Color.white, alpha = 1.0,
                w = 4, h = 16, x = 0, y = 0
        } )
        self.thumb:set_center_y( slider:h() / 2 )

        self.track = track

        -- Value label on the right
        self.slider_text = slider:text( {
                name = "slider_text", layer = 4,
                wrap = "true", word_wrap = "true", visible = true,
                font = pd2_small_font, font_size = 15, color = Color.Free,
                align = "right", halign = "right", vertical = "center", valign = "center",
                blend_mode = "add"
        } )

        self:set_default_value()

        self.slider_text:set_right( slider:w() - 4 )
        self.slider_text:set_center_y( slider:h() / 2 )
end

function Slider:set_default_value()
        local where = ( self.value * 100 / self.max ) / 100
        local fill_w = self.track:w() * where
        self.slider_bg:set_w( fill_w )
        if self.thumb then
                self.thumb:set_x( self.track:x() + fill_w - 2 )
        end
        self:safe_set_text( self.value )
end

function Slider:update()
        local M = M_mouse_pointer._mouse
        local x, y = M:x(), M:y()

        local target = self.track or self.slider
        if target:inside( x, y ) and ( ( not self.button.plugin and mouse_down( mouse, left_click ) ) or mouse_down( mouse, right_click ) ) then
                self:on_slider( x )
        end
end

function Slider:on_slider( x )
        local track = self.track
        local slider_bg = self.slider_bg

        local where = ( x - track:world_left() ) / ( track:world_right() - track:world_left() )
        if where < 0 then where = 0 end
        if where > 1 then where = 1 end

        local fill_w = track:w() * where
        slider_bg:set_w( fill_w )
        if self.thumb then
                self.thumb:set_x( track:x() + fill_w - 2 )
        end

        self.value = ceil( self.max * where )
        self:safe_set_text( self.value )

        self:do_callback()
end

function Slider:do_callback()
        if self.button.plugin then
                self:callback_plugin()
        else
                self:callback_button()
        end
end

function Slider:callback_plugin()
        local callback_func = self.button.slider_callback

        if callback_func then
                callback_func( self.value )
        end

        togg_vars[ self.name ] = self.value

        if game_config then
                game_config[ self.name ] = self.value
        end
end

function Slider:callback_button()
        togg_vars[ self.name ] = self.value

        if game_config then
                game_config[ self.name ] = self.value
        end
end

function Slider:safe_set_text( text )
        local slider_text = self.slider_text

        slider_text:set_text( text )
        local _,_,w,h = slider_text:text_rect()
        slider_text:set_size( w, h )
        slider_text:set_right( self.slider:w() - 4 )
        slider_text:set_center_y( self.slider:h() / 2 )
end

function Slider:close()
        StopLoopIdent( self.id )
end

local G = getfenv(0)
G.Slider = Slider
