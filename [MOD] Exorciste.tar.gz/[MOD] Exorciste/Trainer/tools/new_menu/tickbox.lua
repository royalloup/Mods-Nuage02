-- Menu component. Represents tickbox.
-- Author: Simplity
-- Modernized visuals: framed background + accent fill when active.

local type = type

local togg_vars = togg_vars
local plugins = plugins
local required_plugins = plugins.required
local loaded = plugins.g_loaded

local THEME_ACCENT = Color(0.310, 0.760, 0.970)
local THEME_TRACK  = Color(0.110, 0.125, 0.157)
local THEME_BORDER = Color(0.180, 0.200, 0.235)

local Tickbox = class()

function Tickbox:init( panel, button, plugin_path )
        self.panel = panel
        self.button = button
        self.plugin_path = plugin_path

        self:create_gui()
end

function Tickbox:create_gui()
        local panel = self.panel

        -- A small modern toggle pill: 36x18 track + 14x14 thumb
        local track_w, track_h = 36, 18
        local toggle_panel = panel:panel( { name = "tickbox_toggle", w = track_w, h = track_h, layer = 2 } )
        toggle_panel:set_right( panel:w() )
        toggle_panel:set_center_y( panel:h() / 2 )

        -- Track background
        self.track_bg = toggle_panel:rect( {
                name = "track_bg", layer = 1,
                color = THEME_TRACK, alpha = 1.0,
                halign = "grow", valign = "grow"
        } )

        -- Track border
        toggle_panel:rect( { name = "tb_top",    layer = 2, color = THEME_BORDER, w = track_w, h = 1, x = 0, y = 0 } )
        toggle_panel:rect( { name = "tb_bot",    layer = 2, color = THEME_BORDER, w = track_w, h = 1, x = 0, y = track_h - 1 } )
        toggle_panel:rect( { name = "tb_left",   layer = 2, color = THEME_BORDER, w = 1, h = track_h, x = 0, y = 0 } )
        toggle_panel:rect( { name = "tb_right",  layer = 2, color = THEME_BORDER, w = 1, h = track_h, x = track_w - 1, y = 0 } )

        -- Active fill
        self.fill = toggle_panel:rect( {
                name = "track_fill", layer = 3,
                color = THEME_ACCENT, alpha = 0.0,
                halign = "grow", valign = "grow"
        } )

        -- Thumb
        self.thumb = toggle_panel:rect( {
                name = "thumb", layer = 4,
                color = Color.white, alpha = 0.95,
                w = 12, h = 12, x = 3, y = 3
        } )

        self.toggle_panel = toggle_panel

        -- Hidden legacy bitmap kept for compatibility (some code may toggle it).
        -- It does not draw anything visible because alpha is 0.
        self.tickbox = panel:bitmap( {
                name = "tickbox", texture = "guis/textures/menu_tickbox", layer = 0,
                texture_rect = { 0,0,24,24 }, w = 24, h = 24,
                color = Color.white, alpha = 0,
                visible = false
        } )

        self:toggle()
end

function Tickbox:toggle()
        local state = self:get_state() and true or false
        if state == self._last_state then
                return
        end
        self._last_state = state

        if not self.fill or not self.thumb then
                return
        end

        if state then
                self.fill:set_alpha( 1.0 )
                self.thumb:set_x( self.toggle_panel:w() - self.thumb:w() - 3 )
                self.thumb:set_color( Color.white )
        else
                self.fill:set_alpha( 0.0 )
                self.thumb:set_x( 3 )
                self.thumb:set_color( Color(0.55, 0.58, 0.63) )
        end
end

function Tickbox:refresh()
        self._last_state = nil
        self:toggle()
end

function Tickbox:get_state()
        local button = self.button

        local obj_toggle = button.toggle
        local toggle = type( obj_toggle )
        local plug = button.plugin
        if ( plug ) then
                local path = self.plugin_path
                if ( path ) then
                        local real_name = required_plugins[path..plug]
                        if ( real_name ) then
                                return loaded( plugins, real_name )
                        end
                end
        end
        if toggle ~= 'nil' then
                if toggle == "string" then
                        return togg_vars[ obj_toggle ]
                elseif toggle == "function" then
                        return obj_toggle()
                end
        end
        return false
end

local G = getfenv(0)
G.Tickbox = Tickbox
