-- ============================================================
-- EXORCISTE - Notifications toast + sons
-- Self-contained, fonctionne en pre-game ET in-game.
-- Patron base sur Trainer/addons/missionmenu/debug_hud.lua qui
-- est confirme fonctionnel en jeu.
-- ============================================================

local _G              = _G
local rawget          = rawget
local rawset          = rawset
local Color           = Color
local Overlay         = Overlay
local Application     = Application
local RenderSettings  = RenderSettings
local tweak_data      = tweak_data
local Vector3         = Vector3
local managers        = managers
local alive           = alive
local pcall           = pcall
local table           = table
local math            = math
local os              = os
local tostring        = tostring
local type            = type
local ipairs          = ipairs

-- Persistent state across reloads
local store = rawget(_G, "__exorciste_notif_store")
if not store then
    store = { ws = nil, root = nil, items = {}, sources = {} }
    rawset(_G, "__exorciste_notif_store", store)
end

-- ============================================================
-- Visual constants
-- ============================================================
local TOAST_W    = 380
local TOAST_H    = 46
local TOAST_GAP  = 8
local TOAST_LIFE = 2.4   -- seconds visible
local TOAST_FADE = 0.20  -- seconds fade in/out

local function col(r, g, b)
    return Color(r, g, b)
end

-- ============================================================
-- Workspace management — uses the SAME pattern as debug_hud.lua
-- ws:panel() returns the root panel WITHOUT args; we then create
-- a child with :panel({config}).
-- ============================================================
local function ensure_root()
    if alive(store.ws) and alive(store.root) then
        return store.root
    end
    local ok, ws = pcall(function()
        return Overlay:newgui():create_screen_workspace()
    end)
    if not ok or not ws then
        return nil
    end
    store.ws = ws
    -- ws:panel() with NO args returns the workspace root panel
    local ok2, root = pcall(function() return ws:panel() end)
    if not ok2 or not root then
        return nil
    end
    store.root = root
    return root
end

local function get_screen_w()
    if RenderSettings and RenderSettings.resolution then
        return RenderSettings.resolution.x
    end
    return 1280
end

-- ============================================================
-- Reflow toasts vertically (top-right area)
-- ============================================================
local function reflow()
    local root = store.root
    if not alive(root) then return end
    local sw = get_screen_w()
    local x = sw - TOAST_W - 24
    local y = 80
    for i = 1, #store.items do
        local it = store.items[i]
        if alive(it.panel) then
            it.panel:set_x(x)
            it.panel:set_y(y)
            y = y + TOAST_H + TOAST_GAP
        end
    end
end

local function remove_toast(toast)
    for i, it in ipairs(store.items) do
        if it == toast then
            table.remove(store.items, i)
            break
        end
    end
    if alive(toast.panel) and alive(store.root) then
        pcall(function() store.root:remove(toast.panel) end)
    end
    reflow()
end

-- ============================================================
-- Animation — uses Application:time() based dt (more reliable
-- than coroutine.yield() return value across BLT versions)
-- ============================================================
local function animate_toast(toast)
    local p = toast.panel
    if not alive(p) then return end
    p:animate(function(o)
        local t0 = Application:time()
        local last = t0
        -- Fade in
        while true do
            coroutine.yield()
            local now = Application:time()
            local elapsed = now - t0
            local a = math.min(1, elapsed / TOAST_FADE)
            if alive(o) then o:set_alpha(a) end
            last = now
            if elapsed >= TOAST_FADE then break end
        end
        if alive(o) then o:set_alpha(1) end
        -- Hold
        local hold_start = Application:time()
        while Application:time() - hold_start < TOAST_LIFE do
            coroutine.yield()
        end
        -- Fade out
        local fade_start = Application:time()
        while true do
            coroutine.yield()
            local elapsed = Application:time() - fade_start
            local a = math.max(0, 1 - (elapsed / TOAST_FADE))
            if alive(o) then o:set_alpha(a) end
            if elapsed >= TOAST_FADE then break end
        end
        remove_toast(toast)
    end)
end

-- ============================================================
-- Build a toast panel (proven pattern: root:panel{config})
-- ============================================================
local THEME_BG     = col(0.05, 0.06, 0.08)
local THEME_BORDER = col(0.31, 0.76, 0.97)
local THEME_TEXT   = col(0.95, 0.97, 1.00)
local ACCENT_INFO  = col(0.31, 0.76, 0.97)  -- cyan
local ACCENT_ON    = col(0.42, 0.92, 0.55)  -- green
local ACCENT_OFF   = col(0.96, 0.34, 0.34)  -- red

local function show_toast(message, kind)
    if type(message) ~= "string" or message == "" then return end
    local root = ensure_root()
    if not root then return end

    local accent = ACCENT_INFO
    if     kind == "on"  then accent = ACCENT_ON
    elseif kind == "off" then accent = ACCENT_OFF end

    -- Create toast panel as a CHILD of root (correct pattern)
    local sw = get_screen_w()
    local px = sw - TOAST_W - 24
    local py = 80

    local p
    local ok, err = pcall(function()
        p = root:panel({
            name  = "exo_toast_" .. tostring(os.time()) .. "_" .. tostring(math.random(1, 9999999)),
            x     = px,
            y     = py,
            w     = TOAST_W,
            h     = TOAST_H,
            alpha = 0,
            layer = 2500,
        })
    end)
    if not ok or not alive(p) then return end

    -- Background fill
    pcall(function()
        p:rect({ color = THEME_BG, alpha = 0.92, layer = 0 })
    end)
    -- Top + bottom border lines (use border color with low alpha)
    pcall(function()
        p:rect({ color = THEME_BORDER, alpha = 0.85, h = 1, y = 0,            layer = 1 })
        p:rect({ color = THEME_BORDER, alpha = 0.85, h = 1, y = TOAST_H - 1,  layer = 1 })
    end)
    -- Left accent bar
    pcall(function()
        p:rect({ color = accent, w = 4, x = 0, layer = 2 })
    end)

    -- Pick a font that's known to exist on the player's machine
    local font_name = "core/fonts/diesel"
    if tweak_data and tweak_data.hud and tweak_data.hud.medium_font then
        font_name = tweak_data.hud.medium_font
    end

    pcall(function()
        p:text({
            name      = "txt",
            text      = message,
            font      = font_name,
            font_size = 20,
            color     = THEME_TEXT,
            x         = 16,
            y         = 0,
            w         = TOAST_W - 32,
            h         = TOAST_H,
            vertical  = "center",
            align     = "left",
            layer     = 3,
        })
    end)

    local toast = { panel = p }
    table.insert(store.items, toast)

    -- Cap visible toasts
    while #store.items > 5 do
        local oldest = table.remove(store.items, 1)
        if alive(oldest.panel) and alive(store.root) then
            pcall(function() store.root:remove(oldest.panel) end)
        end
    end

    reflow()
    animate_toast(toast)
end

-- ============================================================
-- Sound — XAudio (custom OGG) with explicit listener-relative
-- positioning so it stays audible during heists.
-- ============================================================
local function mod_path()
    return rawget(_G, "exorciste_mod_path") or rawget(_G, "ModPath") or ""
end

local function play_sound(filename)
    local XAudio = rawget(_G, "XAudio")
    if not XAudio then return false end
    local base = mod_path()
    if base == "" then return false end
    local full = base .. "Trainer/sounds/" .. filename

    local ok_buf, buffer = pcall(function() return XAudio.Buffer:new(full) end)
    if not ok_buf or not buffer then return false end

    local ok_src, source = pcall(function() return XAudio.Source:new(buffer) end)
    if not ok_src or not source then return false end

    pcall(function() source:set_relative_to_listener(true) end)
    if Vector3 then
        pcall(function() source:set_position(Vector3(0, 0, 0)) end)
    end
    pcall(function() source:set_volume(1.0) end)
    pcall(function() source:set_looping(false) end)
    pcall(function() source:play() end)

    -- Keep references alive so GC doesn't free them mid-play
    table.insert(store.sources, { source = source, buffer = buffer, t = os.time() })
    local cutoff = os.time() - 10
    local i = 1
    while i <= #store.sources do
        local ref = store.sources[i]
        if ref.t and ref.t < cutoff then
            pcall(function() if ref.source.close then ref.source:close() end end)
            pcall(function() if ref.buffer.close then ref.buffer:close() end end)
            table.remove(store.sources, i)
        else
            i = i + 1
        end
    end
    return true
end

-- ============================================================
-- Native PD2 sound fallback — guaranteed audible in any state
-- ============================================================
local function play_native_event(event_name)
    if not event_name or event_name == "" then return false end
    -- 1) Player unit's sound source (works in-heist)
    if managers and managers.player then
        local ok, player = pcall(function() return managers.player:player_unit() end)
        if ok and player and alive(player) and player.sound_source then
            pcall(function() player:sound_source():post_event(event_name) end)
            return true
        end
    end
    -- 2) Menu component (works in main menu / pre-game)
    if managers and managers.menu_component then
        pcall(function() managers.menu_component:post_event(event_name) end)
        return true
    end
    -- 3) Global music source (always available)
    local g = rawget(_G, "Global")
    if g and g.music_manager and g.music_manager.source then
        pcall(function() g.music_manager.source:post_event(event_name) end)
        return true
    end
    return false
end

-- ============================================================
-- Public API
-- ============================================================
local M = {}

function M.notify(msg)
    show_toast(msg, "info")
end

function M.notify_on(label)
    show_toast(tostring(label) .. "  -  ACTIVE", "on")
    play_native_event("box_tick")
    play_sound("activer.ogg")
end

function M.notify_off(label)
    show_toast(tostring(label) .. "  -  DESACTIVE", "off")
    play_native_event("box_untick")
    play_sound("desactiver.ogg")
end

function M.notify_action(label)
    show_toast(tostring(label), "info")
    play_native_event("menu_enter")
end

rawset(_G, "exorciste_notify",     M.notify)
rawset(_G, "exorciste_notify_on",  M.notify_on)
rawset(_G, "exorciste_notify_off", M.notify_off)

return M
