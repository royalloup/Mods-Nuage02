-- Spawn Tourelle (mode bruyant)
-- Fait apparaitre une tourelle automatique a l'endroit vise

if inGame() and isPlaying() and not inChat() then
    local function spawner()
        local ammo_multiplier  = managers.player:upgrade_value("sentry_gun", "extra_ammo_multiplier", 1)
        local armor_multiplier = managers.player:upgrade_value("sentry_gun", "armor_multiplier", 1)
        local damage_multiplier = managers.player:upgrade_value("sentry_gun", "damage_multiplier", 1)
        local unit = managers.player:player_unit()
        if not alive(unit) then return end

        local from = unit:movement():m_head_pos()
        local to   = from + unit:movement():m_head_rot():y() * 200
        local ray  = unit:raycast("ray", from, to,
            "slot_mask", managers.slot:get_mask("trip_mine_placeables"),
            "ignore_unit", {})

        if not ray then return end

        local pos  = ray.position
        local rot  = Rotation(unit:movement():m_head_rot():yaw(), 0, 0)
        local selected_index = nil

        if Network:is_client() then
            managers.network:session():send_to_host(
                "place_sentry_gun", pos, rot,
                ammo_multiplier, armor_multiplier, damage_multiplier,
                selected_index, unit)
            PlayerEquipment.sentrygun_placement_requested = true
        else
            local shield = managers.player:has_category_upgrade("sentry_gun", "shield")
            local ok, sentry_unit = pcall(SentryGunBase.spawn, unit, pos, rot,
                ammo_multiplier, armor_multiplier, damage_multiplier)
            if ok and sentry_unit then
                managers.network:session():send_to_peers_synched(
                    "from_server_sentry_gun_place_result",
                    managers.network:session():local_peer():id(),
                    selected_index, sentry_unit,
                    sentry_unit:movement()._rot_speed_mul,
                    sentry_unit:weapon()._setup.spread_mul,
                    shield)
            end
        end
    end

    local ok, err = pcall(spawner)
    if not ok and log then
        log("[Exorciste] Spawn Tourelle - erreur : " .. tostring(err))
    end
end
