---@meta

---@class Unit: ScriptReference
---@field type_name "Unit"
Unit = {}

function Unit:activate(...) end

function Unit:activate_graphic_group(...) end

function Unit:activate_mover(...) end

function Unit:active(...) end

function Unit:add_body_activation_callback(...) end

function Unit:add_body_enabled_callback(...) end

function Unit:add_velocity(...) end

function Unit:airborn(...) end

---Returns the unit's animation data
---@return table
function Unit:anim_data() end

function Unit:anim_groups(...) end

function Unit:anim_is_playing(...) end

function Unit:anim_is_playing_to(...) end

function Unit:anim_length(...) end

function Unit:anim_play(...) end

function Unit:anim_play_loop(...) end

function Unit:anim_play_to(...) end

function Unit:anim_playing_speed(...) end

function Unit:anim_playing_to(...) end

function Unit:anim_set_time(...) end

function Unit:anim_state_machine(...) end

function Unit:anim_stop(...) end

function Unit:anim_time(...) end

---Returns the unit's animation timer
---@return Timer?
function Unit:animation_timer() end

function Unit:approximate_orientation(...) end

---Returns the unit's armor skin extension
---@return ArmorSkinExt|MenuArmourBase?
function Unit:armor_skin() end

function Unit:ballistic_raycast(...) end

---Returns the unit's base extension
---@return UnitBase|CopBase|PlayerBase?
function Unit:base() end

---Returns a unit body by name
---@param name string
---@return Body?
function Unit:body(name) end

---Returns a unit body by index
---@param index integer
---@return Body?
function Unit:body(index) end

function Unit:body_group(...) end

function Unit:bounding_sphere_radius(...) end

---Returns the unit's brain extension
---@return CopBrain|HuskCopBrain|CivilianBrain|TeamAIBrain|PlayerTurretBrain|SentryGunBrain?
function Unit:brain() end

---Returns the unit's camera extension
---@return PlayerCamera?
function Unit:camera() end

function Unit:can_activate_mover(...) end

function Unit:can_activate_mover_isolated(...) end

---Returns the unit's carry data extension
---@return CarryData?
function Unit:carry_data() end

---Returns the unit's character damage extension
---@return PlayerDamage|HuskPlayerDamage|CivilianDamage|BossDamage|CopDamage|MedicDamage|TankCopDamage|TankMedicCopDamage|TeamAIDamage|SentryGunDamage?
function Unit:character_damage() end

---Returns the unit's linked units
---@return Unit[]
function Unit:children() end

function Unit:clear_body_activation_callbacks(...) end

function Unit:clear_body_enabled_callbacks(...) end

function Unit:configure_constraint(...) end

function Unit:constraint_type(...) end

---Returns the unit's contour extension
---@return ContourExt?
function Unit:contour() end

---Returns the unit's damage extension
---@return UnitDamage?
function Unit:damage() end

function Unit:deactivate(...) end

function Unit:debug_callback(...) end

function Unit:decal_surface(...) end

function Unit:destructible(...) end

function Unit:digital_gui(...) end

function Unit:digital_gui_upper(...) end

function Unit:disable_constraint(...) end

function Unit:disable_constraint_group(...) end

function Unit:disable_rendering_permanent(...) end

function Unit:driving(...) end

function Unit:editable_gui(...) end

---@return integer
function Unit:editor_id() end

function Unit:effect_spawner(...) end

function Unit:effect_spawner_group(...) end

function Unit:enable_constraint(...) end

function Unit:enable_constraint_group(...) end

function Unit:enabled(...) end

function Unit:event_listener(...) end

---Returns a list of names of the unit's extensions
---@return string[]
function Unit:extensions() end

function Unit:extensions_infos(...) end

---@return Body[]
function Unit:find_bodies(...) end

---@return Unit[]
function Unit:find_units(...) end

---@return Unit[]
function Unit:find_units_quick(...) end

function Unit:get_active_mover_offset(...) end

function Unit:get_animation_delta_position(...) end

function Unit:get_animation_delta_rotation(...) end

function Unit:get_body_index(...) end

function Unit:get_destructible_index(...) end

---Gets a unit object by name
---@param name Idstring
---@return Object3D?
function Unit:get_object(name) end

---Returns a list of all the unit's objects of a given type
---@param type Idstring
---@return any[]
function Unit:get_objects_by_type(type) end

function Unit:get_phantom_index(...) end

function Unit:get_rope_index(...) end

function Unit:has_constraint(...) end

function Unit:has_material_assigned(...) end

---Returns the unit's id
---@return integer
function Unit:id() end

---Returns if the unit is in slot `slot`
---@param slot integer
---@return boolean
function Unit:in_slot(slot) end

---Returns if the unit slot is contained in `slot_mask`
---@param slot_mask SlotMask
---@return boolean
function Unit:in_slot(slot_mask) end

---Returns the unit's interaction extension
---@return BaseInteractionExt?
function Unit:interaction() end

---Returns the unit's inventory extension
---@return PlayerInventory|HuskPlayerInventory|CopInventory|TeamAIInventory?
function Unit:inventory() end

function Unit:is_constraint_enabled(...) end

function Unit:kill_mover(...) end

function Unit:light_group(...) end

---Links `unit` to the unit
---@param unit Unit
function Unit:link(unit) end

---Links `unit` by its `from_obj` to the object `obj` on the unit
---@param obj Idstring
---@param unit Unit
---@param from_obj? Idstring
function Unit:link(obj, unit, from_obj) end

---Returns the unit's position relative to its parent
---@return Vector3
function Unit:local_position() end

---Returns the unit's rotation relative to its parent
---@return Rotation
function Unit:local_rotation() end

---Copies the unit's position to `out`
---@param out Vector3
function Unit:m_position(out) end

---Copies the unit's rotation to `out`
---@param out Rotation
function Unit:m_rotation(out) end

function Unit:make_ball_and_socket(...) end

function Unit:make_limited_hinge(...) end

function Unit:mass(...) end

---Returns the specified material of the unit
---@param name Idstring
---@return Material?
function Unit:material(name) end

---Returns the material config name
---@return Idstring
function Unit:material_config() end

function Unit:mission_door_device(...) end

function Unit:move(...) end

---Returns the unit's movement extension
---@return PlayerMovement|HuskPlayerMovement|CopMovement|TeamAIMovement|PlayerTurretMovement|SentryGunMovement|nil
function Unit:movement() end

function Unit:mover(...) end

function Unit:mover_by_name(...) end

---Returns whether the unit is moving
---@return boolean
function Unit:moving() end

function Unit:moving_reason(...) end

---Returns the unit's name as an Idstring
---@return Idstring
function Unit:name() end

---Returns the unit's network extension
---@return NetworkBaseExtension?
function Unit:network() end

---Returns the unit's network sync type
---@return "none"|"client"|"spawn"?
function Unit:network_sync() end

---Returns the number of bodies of the unit
---@return integer
function Unit:num_bodies() end

function Unit:num_destructibles(...) end

function Unit:num_phantoms(...) end

function Unit:num_ropes(...) end

---Returns whether the unit is occluded
---@return boolean
function Unit:occluded() end

function Unit:occlusion_time(...) end

---Returns the unit's object oriented bounding box
---@return OOBB
function Unit:oobb() end

---Returns the root object of the unit
---@return Object3D
function Unit:orientation_object() end

---Returns the unit's parent unit
---@return Unit?
function Unit:parent() end

function Unit:phantom(...) end

function Unit:phantom_by_index(...) end

function Unit:play_redirect(...) end

function Unit:play_state(...) end

---Returns the unit's position
---@return Vector3
function Unit:position() end

function Unit:push(...) end

function Unit:push_at(...) end

function Unit:push_cone(...) end

function Unit:push_rnd(...) end

function Unit:push_sphere(...) end

function Unit:radius(...) end

---Tests for collisions between two positions, ignoring the unit that's doing the raycast  
---@param type "ray"
---@param from Vector3
---@param to Vector3
---@param ... any @Additional parameters (parameter option name followed by the value if it takes one)
---@return ray_res?
function Unit:raycast(type, from, to, ...) end

function Unit:refresh_object_materials(...) end

function Unit:release_animation(...) end

function Unit:reload_anim_state_machine(...) end

function Unit:remove_body_activation_callback(...) end

function Unit:remove_body_enabled_callback(...) end

function Unit:remove_constraint(...) end

function Unit:rope(...) end

function Unit:rotate_with(...) end

---Returns the unit's rotation
---@return Rotation
function Unit:rotation() end

function Unit:sampled_velocity(...) end

---Returns the unit's script data
---@return table?
function Unit:script_data() end

function Unit:separate(...) end

function Unit:separate_distance(...) end

function Unit:separate_weight(...) end

function Unit:set_active_mover_offset(...) end

function Unit:set_animatable_enabled(...) end

function Unit:set_animation_lod(...) end

function Unit:set_animation_timer(...) end

function Unit:set_animations_enabled(...) end

function Unit:set_approximate_orientation(...) end

function Unit:set_body_activation_callback(...) end

function Unit:set_body_collision_callback(...) end

function Unit:set_body_enabled_callback(...) end

function Unit:set_destructible_collision_callback(...) end

function Unit:set_driving(...) end

function Unit:set_editor_id(...) end

function Unit:set_enabled(...) end

---Enables or disables the update function of an extension
---@param ext Idstring
---@param enabled boolean
function Unit:set_extension_update_enabled(ext, enabled) end

---Sets the unit's position relative to its parent
---@param pos Vector3
function Unit:set_local_position(pos) end

---Sets the unit's rotation relative to its parent
---@param rot Rotation
function Unit:set_local_rotation(rot) end

---Changes the unit's material configuration file
---@param material_name Idstring
---@param b boolean?
---@param callback function?
---@param n number?
function Unit:set_material_config(material_name, b, callback, n) end

function Unit:set_mover_collision_callback(...) end

function Unit:set_moving(...) end

function Unit:set_object_visibility(...) end

---Sets the unit's position
---@param pos Vector3
function Unit:set_position(pos) end

function Unit:set_radius(...) end

---Sets the unit's rotation 
---@param rot Rotation
function Unit:set_rotation(rot) end

function Unit:set_separate(...) end

function Unit:set_separate_distance(...) end

function Unit:set_separate_weight(...) end

---Disables or enables the unit's shadow casters
---@param disabled boolean
function Unit:set_shadows_disabled(disabled) end

---Sets the unit's slot
---@param slot integer
function Unit:set_slot(slot) end

function Unit:set_spawn_delayed(...) end

function Unit:set_timer(...) end

function Unit:set_velocity(...) end

function Unit:set_visibility(...) end

---Shows or hides the unit
---@param visible boolean
function Unit:set_visible(visible) end

---Returns whether the unit's shadow casters are enabled
---@return boolean
function Unit:shadows_disabled() end

---Returns the unit's slot
---@return integer
function Unit:slot() end

---Returns the unit's sound extension
---@return PlayerSound|CopSound|BossSound|CivilianHeisterSound|SafehouseNPCSound|TeamAISound?
function Unit:sound() end

---Returns the unit's sound source
---@return SoundSource?
function Unit:sound_source() end

function Unit:spawn_manager(...) end

function Unit:switch_body_off(...) end

function Unit:switch_body_on(...) end

function Unit:switch_body_on_with_no_velocity(...) end

---Returns the unit's timer
---@return Timer?
function Unit:timer() end

---Returns the unit's timer GUI extension
---@return TimerGui?
function Unit:timer_gui() end

---Returns the unit's type
---@return Idstring
function Unit:type() end

---Returns the unit's data
---@return ScriptUnitData?
function Unit:unit_data() end

---Unlinks the unit from its parent unit
function Unit:unlink() end

function Unit:update_render_templates(...) end

function Unit:updated(...) end

function Unit:vehicle(...) end

---Returns the unit's current velocity
---@return Vector3
function Unit:velocity() end

function Unit:visibility(...) end

---Returns whether the unit is visible or not
---@return boolean
function Unit:visible() end

---Warps the unit to the specified position with the specified rotation
---@param rot Rotation
---@param pos Vector3
function Unit:warp_to(rot, pos) end

function Unit:warp_to_floor(...) end

function Unit:wire_data(...) end
