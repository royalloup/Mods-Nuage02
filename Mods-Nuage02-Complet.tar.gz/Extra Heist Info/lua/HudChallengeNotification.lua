local EHI = EHI
local titles = {}
local to_localize = {}
local hooked = false
---@param ehi_title string
---@param localization string
---@param c Color?
function EHI:SetNotificationAlert(ehi_title, localization, c)
    if localization then
        if managers.localization then
            localization = managers.localization:text(localization)
        else
            to_localize[ehi_title] = { localization = localization, color = c or Color.red }
        end
    end
    titles[ehi_title] = { localization = localization or ehi_title, color = c or Color.red }
    if not hooked then
        local _f_init = HudChallengeNotification.init
        if VoidUI and VoidUI.options.enable_challanges then
            function HudChallengeNotification:init(title, ...)
                local color = nil
                if title and titles[title] then
                    local _t = titles[title]
                    title = _t.localization
                    color = _t.color
                end
                _f_init(self, title, ...)
                if color then
                    for _, d in ipairs(self._hud:children()) do ---@diagnostic disable-line
                        if d.panel then
                           for _, dd in ipairs(d:children()) do
                                if dd.set_image then
                                    dd:set_color(color)
                                end
                            end
                        end
                    end
                end
            end
        else
            function HudChallengeNotification:init(title, ...)
                local color = nil
                if title and titles[title] then
                    local _t = titles[title]
                    title = _t.localization
                    color = _t.color
                end
                _f_init(self, title, ...)
                if color and self._box then
                    for _, d in ipairs(self._box:children()) do ---@cast d Bitmap
                        if d.set_image then
                            d:set_color(color)
                        end
                    end
                end
            end
        end
        hooked = true
    end
end

EHI:AddOnLocalizationLoaded(function(loc, lang_name)
    for title, alert in pairs(to_localize or {}) do
        titles[title] = { localization = loc:text(alert.localization), color = alert.color }
    end
    to_localize = nil
end)

if EHI:GetUnlockableOption("show_achievement_failed_popup") then
    EHI:SetNotificationAlert("ACHIEVEMENT FAILED!", "ehi_popup_achievement_failed")
end
if EHI:GetUnlockableOption("show_achievement_started_popup") then
    EHI:SetNotificationAlert("ACHIEVEMENT STARTED!", "ehi_popup_achievement_started", Color.green)
end
if EHI:GetOption("show_all_loot_secured_popup") then
    EHI:SetNotificationAlert("LOOT COUNTER", "ehi_popup_loot_counter", Color.green)
end
if EHI:GetUnlockableOption("show_trophy_failed_popup") then
    EHI:SetNotificationAlert("TROPHY FAILED!", "ehi_popup_trophy_failed")
end
if EHI:GetUnlockableOption("show_trophy_started_popup") then
    EHI:SetNotificationAlert("TROPHY STARTED!", "ehi_popup_trophy_started", Color.green)
end
if EHI:GetUnlockableOption("show_daily_failed_popup") then
    EHI:SetNotificationAlert("DAILY SIDE JOB FAILED!", "ehi_popup_daily_failed")
end
if EHI:GetUnlockableOption("show_daily_started_popup") then
    EHI:SetNotificationAlert("DAILY SIDE JOB STARTED!", "ehi_popup_daily_started", Color.green)
end
if EHI:GetUnlockableOption("show_event_started_popup") then
    EHI:SetNotificationAlert("EVENT MISSION STARTED!", "ehi_popup_event_started", Color.green)
end
if EHI:GetOption("show_sniper_spawned_popup") then
    local color = EHI:GetColorFromOption("tracker_waypoint", "sniper_count")
    EHI:SetNotificationAlert("SNIPER!", "ehi_popup_sniper", color)
    EHI:SetNotificationAlert("SNIPERS!", "ehi_popup_snipers", color)
end
if EHI:GetOption("show_sniper_logic_start_popup") then
    EHI:SetNotificationAlert("SNIPER_LOGIC_START", "ehi_popup_sniper_logic_start", Color.yellow)
end
if EHI:GetOption("show_sniper_logic_end_popup") then
    EHI:SetNotificationAlert("SNIPER_LOGIC_END", "ehi_popup_sniper_logic_end", Color.green)
end