local EHI = EHI
Hooks:PostHook(MenuNodeMainGui, "_setup_item_rows", "EHI_MenuNodeMainGui_setup_item_rows", function(...)
    if EHI._cache.SaveFileCorrupted then -- Should always show, because it is important
        QuickMenu:new(
            managers.localization:text("ehi_save_data_corrupted"),
            managers.localization:text("ehi_save_data_corrupted_desc"),
            {},
            true
        )
        EHI._cache.SaveFileCorrupted = nil
    end
    if EHI._cache.GameVersionNotCompatible then
        QuickMenu:new(
            managers.localization:text("ehi_wrong_game_version"),
            managers.localization:text("ehi_wrong_game_version_desc"),
            {},
            true
        )
        EHI._cache.GameVersionNotCompatible = nil
        if EHI.ModInstance then
            EHI.ModInstance:SetEnabled(false, true)
            MenuCallbackHandler:perform_blt_save()
        end
    end
end)