local EHI = EHI

---@class EHIList
---@field _set_items_y fun(self: self, item: EHILeftListBase|EHIRightListBase?)
local EHIList = class()
---@param o Panel
---@param target_y number
EHIList._set_y = function(o, target_y)
    local t, total = 0, 0.15
    local from_y = o:y()
    while t < total do
        t = t + coroutine.yield()
        o:set_y(math.lerp(from_y, target_y, t / total))
    end
    o:set_y(target_y)
end
function EHIList:init()
    self._options = {}
    self._items = {} ---@type table<string, EHILeftListBase|EHIRightListBase>
    self._itemized_list = {} ---@type EHILeftListBase[]|EHIRightListBase[]
    self._n_of_visible_items = 0
end

---@param x number
---@param y number
---@param scale number
function EHIList:post_init(x, y, scale)
end

function EHIList:SwitchToLoudMode()
    for _, item in ipairs(self._itemized_list) do
        item:SwitchToLoudMode()
    end
end

---@param id string
---@param f string
function EHIList:CallItemFunction(id, f, ...)
    local item = self._items[id]
    if item and item[f] then
        item[f](item, ...)
    end
end

---@param item EHILeftListBase|EHIRightListBase
function EHIList:ItemSetVisible(item)
    self._n_of_visible_items = self._n_of_visible_items + 1
    if self._n_of_visible_items == 1 then
        item._panel:set_y(self._options.y)
        return
    end
    self:_set_items_y(item)
end

function EHIList:ItemSetHidden()
    self._n_of_visible_items = self._n_of_visible_items - 1
    if self._n_of_visible_items <= 0 then
        return
    end
    self:_set_items_y()
end

---@param id string
function EHIList:RemoveItem(id)
    local item = table.remove_key(self._items, id)
    if item then
        item:destroy()
        for i, itm in ipairs(self._itemized_list) do
            if itm == item then
                table.remove(self._itemized_list, i)
                break
            end
        end
    end
end

---@class EHILeftList : EHIList
---@field new fun(self: self): self
---@field super EHIList
local EHILeftList = class(EHIList)
function EHILeftList:post_init(x, y, scale)
    self._options.x = x
    self._options.y = y
    self._options.scale = scale
    self._options.y_offset = 2 * scale
end

---@param class EHILeftListBase
---@param panel Panel
---@param params table
function EHILeftList:AddItem(class, panel, params)
    local texture, texture_rect = tweak_data.ehi.default.hudlist.get_icon(params.icon)
    params.x = self._options.x
    params.scale = self._options.scale
    local item = class:new(panel, params, texture, texture_rect)
    self._items[params.id] = item
    table.insert(self._itemized_list, item)
    item._panel:child("icon"):move(self._options.x, 0)
    item:CacheFrequentlyUsedValues()
end

---@param new_item EHILeftListBase
function EHILeftList:_set_items_y(new_item)
    local y = self._options.y
    for _, item in ipairs(self._itemized_list) do
        if item:visible() then
            if item == new_item then -- Don't animate movement for the new item, just set Y coordinate
                item._panel:set_y(y)
            else
                item._panel:animate(self._set_y, y)
            end
            y = y + item._panel:h() + self._options.y_offset
        end
    end
end

---@param id string
---@param f string
function EHILeftList:ReturnValue(id, f, ...)
    local item = self._items[id]
    if item and item[f] then
        return item[f](item, ...)
    end
end

---@class EHIRightList : EHIList
---@field new fun(self: self): self
---@field super EHIList
local EHIRightList = class(EHIList)
function EHIRightList:post_init(y, scale)
    self._options.y = y
    self._options.scale = scale
    self._options.y_offset = 2 * scale
end

---@generic T : EHIRightListBase
---@param class T|EHIRightListBase
---@param panel Panel
---@param params table
---@return T
function EHIRightList:AddItem(class, panel, params)
    local item = class:new(panel, params)
    self._items[params.id] = item
    table.insert(self._itemized_list, item)
    return item
end

---@param new_item EHIRightListBase
function EHIRightList:_set_items_y(new_item)
    local y = self._options.y
    for _, item in ipairs(self._itemized_list) do
        if item:visible() then
            item._panel:stop()
            if item == new_item then -- Don't animate movement for the new item, just set Y coordinate
                item._panel:set_y(y)
            else
                item._panel:animate(self._set_y, y)
            end
            y = y + item._panel:h() + self._options.y_offset
        end
    end
end

function EHIRightList:Spawned()
    for _, item in ipairs(self._itemized_list) do ---@cast item -EHILeftListBase
        item:Spawned()
    end
end

---@class EHIHudlistManager
local EHIHudlistManager = {}
EHIHudlistManager._left_list = EHILeftList:new()
EHIHudlistManager._right_list = EHIRightList:new()
---@param id string
---@param f string
function EHIHudlistManager:CallLeftListItemFunction(id, f, ...)
    self._left_list:CallItemFunction(id, f, ...)
end

---@param id string
---@param f string
function EHIHudlistManager:ReturnLeftListItemValue(id, f, ...)
    return self._left_list:ReturnValue(id, f, ...)
end

---@param id string
---@param f string
function EHIHudlistManager:CallRightListItemFunction(id, f, ...)
    self._right_list:CallItemFunction(id, f, ...)
end

if EHI:GetOption("show_hudlist") then
    if EHI:GetHudlistOption("show_left_list") then
        dofile(EHI.LuaPath .. "hudlist/left_items.lua")
        EHILeftListBase._parent = EHIHudlistManager._left_list
        EHILeftListBase._LIST_ICON_VISIBLE = EHI:GetHudlistOption("left_list_icon")
        EHILeftListBase._ANIM_RIGHT_TO_LEFT = EHI:GetHudlistOption("left_list_alignment") == 2
        EHILeftListBase._BG_ALPHA = EHI:GetHudlistOption("left_list_bg_alpha")
        EHILeftListBase._BG_COLOR = EHI:GetColor(EHI:GetHudlistOption("left_list_bg_color"))
        EHILeftListBase._PROGRESS = EHI:GetHudlistOption("left_list_progress")
        EHILeftListBase._PROGRESS_ALPHA = EHI:GetHudlistOption("left_list_progress_alpha")
        EHILeftListBase._PROGRESS_VISIBILITY = EHI:GetHudlistOption("left_list_progress_visibility")
        EHILeftListBase._PROGRESS_STATIC = EHI:GetHudlistOption("left_list_progress_static")
        function EHIHudlistManager:_init_left_list()
            self._panel = self._ws:panel():panel({ layer = -5 })
            local x, y = managers.gui_data:safe_to_full(EHI:GetHudlistOption("left_list_x"), EHI:GetHudlistOption("left_list_y"))
            self._left_list:post_init(x, y, EHI:GetHudlistOption("left_list_scale"))
            local color_index = EHI:GetHudlistOption("left_list_item_color") --[[@as integer]]
            local color, color_string = tweak_data.ehi:GetBuffColorFromIndex(color_index)
            EHILeftListBase._PROGRESS_COLOR = color
            EHILeftListBase._PROGRESS_COLOR_STRING = color_string
            local options = EHI:GetHudlistOption("left_list")
            local stealth_is_available = tweak_data.levels:IsStealthAvailable()
            if options.show_timers then
                self._left_list:AddItem(EHILeftTimerList, self._panel, {
                    id = "Timer",
                    icon = { skills = { 3, 6 } },
                    color_index = color_index,
                    jammed = options.timer_jammed,
                    not_powered = options.timer_not_powered,
                    autorepair = options.timer_autorepair,
                    top_text = options.timer_top_text
                })
            else
                EHILeftTimerList = nil ---@diagnostic disable-line
            end
            if options.show_minions and not tweak_data.levels:IsStealthRequired() then
                self._left_list:AddItem(EHILeftMinionList, self._panel, {
                    id = "Minion",
                    icon = EHILeftMinionList._ICON,
                    minion_option = options.minions_option,
                    health_circle = options.minions_health_circle,
                    top_text = options.minions_top_text
                })
            else
                EHILeftMinionList = nil ---@diagnostic disable-line
            end
            if options.show_deployables and
                (options.deployable_show_doctor or
                options.deployable_show_ammo or
                options.deployable_show_grenades or
                options.deployable_show_fak or
                (options.deployable_show_bodybags and stealth_is_available)) then
                self._left_list:AddItem(EHILeftDeployableList, self._panel, {
                    id = "Deployable",
                    icon = { ehi = "deployables" },
                    update_on_alarm = true,
                    top_text = options.deployable_top_text,
                    format = options.deployable_format,
                    show_doctor = options.deployable_show_doctor,
                    show_ammo = options.deployable_show_ammo,
                    show_grenades = options.deployable_show_grenades,
                    block_grenades = options.deployable_grenades_block_on_ability_or_no_throwable,
                    show_fak = options.deployable_show_fak,
                    show_bodybags = options.deployable_show_bodybags and stealth_is_available
                })
            else
                EHILeftDeployableList = nil ---@diagnostic disable-line
            end
            if options.show_jammers then
                self._left_list:AddItem(EHILeftJammerList, self._panel, {
                    id = "Jammer",
                    icon = EHILeftJammerList._ICON
                })
            else
                EHILeftJammerList = nil ---@diagnostic disable-line
            end
            if options.show_ecm_retrigger then
                self._left_list:AddItem(EHILeftJammerRetriggerList, self._panel, {
                    id = "JammerRetrigger",
                    icon = EHILeftJammerRetriggerList._ICON
                })
            else
                EHILeftJammerRetriggerList = nil ---@diagnostic disable-line
            end
            if stealth_is_available then
                if options.show_enemy_pagers then
                    self._left_list:AddItem(EHILeftPagerList, self._panel, {
                        id = "Pager",
                        icon = { ehi = "pager_icon" },
                        delete_on_alarm = true
                    })
                else
                    EHILeftPagerList = nil ---@diagnostic disable-line
                end
                if options.show_camera_loop and not _G.ch_settings then
                    self._left_list:AddItem(EHILeftCameraLoopList, self._panel, {
                        id = "Camera",
                        icon = EHILeftCameraLoopList._ICON,
                        delete_on_alarm = true
                    })
                else
                    EHILeftCameraLoopList = nil ---@diagnostic disable-line
                end
            end
        end
    end
    if EHI:GetHudlistOption("show_right_list") then
        dofile(EHI.LuaPath .. "hudlist/right_items.lua")
        EHIRightListBase._parent = EHIHudlistManager._right_list
        EHIRightListBase._BG_ALPHA = EHI:GetHudlistOption("right_list_bg_alpha")
        EHIRightListBase._BG_COLOR = EHI:GetColor(EHI:GetHudlistOption("right_list_bg_color"))
        EHIRightListBase._PROGRESS = EHI:GetHudlistOption("right_list_progress")
        EHIRightListBase._PROGRESS_ALPHA = EHI:GetHudlistOption("right_list_progress_alpha")
        EHIRightListBase._PROGRESS_VISIBILITY = EHI:GetHudlistOption("right_list_progress_visibility")
        EHIRightListBase._PROGRESS_STATIC = EHI:GetHudlistOption("right_list_progress_static")
        function EHIHudlistManager:_init_right_list()
            self._panel = self._panel or self._ws:panel():panel({ layer = -5 })
            local x, y = managers.gui_data:safe_to_full(EHI:GetHudlistOption("right_list_x"), EHI:GetHudlistOption("right_list_y"))
            local scale = EHI:GetHudlistOption("right_list_scale") --[[@as number]]
            self._right_list:post_init(y, scale)
            EHIRightListBase._RIGHT_OFFSET = self._panel:w() - x
            EHIRightListBase._SCALE = scale
            local color, color_string = tweak_data.ehi:GetBuffColorFromIndex(EHI:GetHudlistOption("right_list_item_color"))
            EHIRightListBase._PROGRESS_COLOR = color
            EHIRightListBase._PROGRESS_COLOR_STRING = color_string
            local options = EHI:GetHudlistOption("right_list")
            local stealth_is_available = tweak_data.levels:IsStealthAvailable()
            if options.show_units then
                local is_holdout = tweak_data.levels:IsLevelSkirmish()
                local item = self._right_list:AddItem(EHIRightUnitList, self._panel, {
                    id = "Unit"
                })
                item:CreateItemsFromMap(is_holdout, options.unit_types)
            else
                EHIRightUnitList = nil ---@diagnostic disable-line
            end
            if options.show_loot then
                local item = self._right_list:AddItem(EHIRightLootList, self._panel, {
                    id = "Loot",
                    show_potentional_loot = options.potentional_loot,
                    update_on_alarm = true
                })
                item:CreateItemsFromMap(stealth_is_available, options.loot_top_type)
                if options.loot_color_items_based_on_their_weight then
                    item:ColorItemsBasedOnTheirWeight(options.loot_color_items_light, options.loot_color_items_heavy, options.loot_color_items_body)
                end
            else
                EHIRightLootList = nil ---@diagnostic disable-line
            end
            if options.show_special_items then
                local item = self._right_list:AddItem(EHIRightSpecialItemsList, self._panel, {
                    id = "Special",
                    update_on_spawn = true
                })
                item:CreateItemsFromMap(options.special_items_type)
            else
                EHIRightSpecialItemsList = nil ---@diagnostic disable-line
            end
            if options.show_stealth_info and stealth_is_available then
                local item = self._right_list:AddItem(EHIRightStealthList, self._panel, {
                    id = "Stealth",
                    delete_on_alarm = true,
                    bodybags_format = options.stealth_info_bodybags_format,
                    warning_index = options.stealth_info_warning
                })
            else
                EHIRightStealthList = nil ---@diagnostic disable-line
            end
        end
    end
    EHI:AddCallback(EHI.CallbackMessage.InitManagers, function(managers) ---@param managers managers
        EHIHudlistManager._ws = managers.gui_data:create_fullscreen_workspace()
        EHIHudlistManager._ws:hide()
        EHI:AddCallback(EHI.CallbackMessage.HUDVisibilityChanged, function(visibility) ---@param visibility boolean
            if visibility then
                EHIHudlistManager._ws:show()
            else
                EHIHudlistManager._ws:hide()
            end
        end)
        if EHIHudlistManager._init_left_list then
            EHIHudlistManager:_init_left_list()
        end
        if EHIHudlistManager._init_right_list then
            EHIHudlistManager:_init_right_list()
        end
        EHI:AddOnAlarmCallback(function(dropin)
            EHIHudlistManager._left_list:SwitchToLoudMode()
            EHIHudlistManager._right_list:SwitchToLoudMode()
        end)
        EHI:AddOnSpawnedCallback(function()
            EHIHudlistManager._right_list:Spawned()
        end)
    end)
end

return EHIHudlistManager