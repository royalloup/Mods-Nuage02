---@class EHIAssaultManagerSyncData
---@field diff number

local EHI = EHI
---@class EHIAssaultManager
local EHIAssaultManager = {}
EHIAssaultManager._diff = 0
EHIAssaultManager._sync_anticipation_start = "EHI_AM_SyncAnticipationStart"
EHIAssaultManager._sync_sustain_start = "EHI_AM_SyncSustainStart"
EHIAssaultManager._sync_endless_stop = "EHI_AM_SyncEndlessStop"
function EHIAssaultManager.GetTrackerName()
    if EHI:CombineAssaultDelayAndAssaultTime() then
        return "Assault"
    end
    return EHI:GetOption("show_assault_delay_tracker") and "AssaultDelay" or "AssaultTime"
end

function EHIAssaultManager:init_finalize()
    self._assault_number = 0
    self._on_sustain_listener = ListenerHolder:new()
    self._playing_from_start = true
    self._internal = {}
    self._is_skirmish = tweak_data.levels:IsLevelSkirmish()
    local combine = EHI:CombineAssaultDelayAndAssaultTime()
    self._anticipation_sync_f = (EHI.IsHost or self._is_skirmish) and "SyncAnticipationColor" or "SyncAnticipation"
    self._assault_delay =
    {
        blocked = not (combine or EHI:GetTrackerOption("show_assault_delay_tracker")),
        name = combine and "Assault" or "AssaultDelay",
        hint = combine and "assault" or "assault_delay"
    }
    self._assault_delay.hide_on_delete = not (combine or self._assault_delay.blocked)
    self._assault_time =
    {
        blocked = not (combine or EHI:GetTrackerOption("show_assault_time_tracker")),
        name = combine and "Assault" or "AssaultTime",
        show_endless_assault = true,
        hint = combine and "assault" or "assault_time"
    }
    if not (self._assault_delay.blocked and self._assault_time.blocked) then
        EHI:LoadTracker("EHIAssaultTracker")
    end
    self:AddAssaultTypeChangedCallback(function(mode, element_id)
        if self._blocked_wave_mode_elements and self._blocked_wave_mode_elements[element_id] then
            return
        end
        self._endless_assault = mode == "endless"
        local data
        if not self._endless_assault then
            if EHI.IsHost then
                local ai_state = managers.groupai:state()
                local assault_data = ai_state._task_data.assault or {}
                local current_state = assault_data.phase
                local assault_values = tweak_data.group_ai[tweak_data.levels:GetGroupAIState()].assault
                if current_state then
                    data = {
                        state = current_state
                    }
                    if current_state == "build" then
                        data.t_correction = assault_values.build_duration - (assault_data.phase_end_t - ai_state._t)
                    elseif current_state == "sustain" then
                        local t = ai_state._t
                        data.sustain_original_t = assault_data.phase_end_t - t
                        data.sustain_t = ai_state:assault_phase_end_time() - t
                    end
                    managers.ehi_sync:SyncTable(self._sync_endless_stop, data)
                end
            elseif self._synced_from_host then
                return
            end
        end
        managers.ehi_tracker:CallFunction(self._assault_time.name, "SetEndlessAssault", self._endless_assault, data)
    end)
    if not self._assault_time.blocked then
        self:AddAssaultModeChangedCallback(function(mode)
            managers.ehi_tracker:CallFunction(self._assault_time.name, mode == "phalanx" and "CaptainArrived" or "CaptainDefeated")
            self._endless_assault = nil
        end)
        -- Crime Spree
        EHI:AddOnSpawnedCallback(function()
            local modifier = managers.modifiers:GetModifier("ModifierAssaultExtender", "crime_spree")
            if modifier and EHIAssaultTracker then
                -- Crime-Spree Rogue Like mod uses 2 separate values instead of 1 in Vanilla (duration_deduction is from CSRL)
                EHIAssaultTracker._CRIME_SPREE =
                {
                    duration = modifier:value("duration") * 0.01,
                    deduction = (modifier:value("duration_deduction") or modifier:value("deduction")) * 0.01,
                    max_hostages = modifier:value("max_hostages")
                }
                self._minions = {} ---@type table<userdata, boolean>
                EHI:AddCallback(EHI.CallbackMessage.OnMinionAdded, function(unit, ...) ---@param unit UnitEnemy
                    local key = unit:key()
                    if self._minions[key] then
                        return
                    end
                    self._minions[key] = true
                    managers.ehi_tracker:CallFunction(self._assault_time.name, "OnMinionCountChanged")
                end)
                EHI:AddCallback(EHI.CallbackMessage.OnMinionKilled, function(key, ...) ---@param key userdata
                    if table.remove_key(self._minions, key) then
                        managers.ehi_tracker:CallFunction(self._assault_time.name, "OnMinionCountChanged")
                    end
                end)
            end
        end)
        self:AddOnSustainListener("EHIAssaultManager", function(duration)
            managers.ehi_tracker:CallFunction(self._assault_time.name, "OnEnterSustain", duration)
        end)
    end
    if EHI.IsHost then
        ---@class EHISustainListenerModifier : BaseModifier
        local EHISustainListenerModifier = class(BaseModifier)
        ---@param duration number
        function EHISustainListenerModifier:OnEnterSustainPhase(duration)
            managers.ehi_assault._on_sustain_listener:call(duration)
        end
        managers.modifiers:add_modifier(EHISustainListenerModifier, "EHI")
        self:AddOnSustainListener("EHIAssaultManagerSync", function(duration)
            self._internal.sustain_app = duration
            self._internal.sustain_app_t = managers.game_play_central:get_heist_timer()
            if not self._is_skirmish then
                managers.ehi_sync:SyncTable(self._sync_sustain_start, { t = duration })
            end
        end)
    else
        if not self._assault_delay.blocked then
            managers.ehi_sync:AddReceiveHook(self._sync_anticipation_start, function(data, sender)
                local tbl = json.decode(data)
                if tbl and tbl.t then
                    self:AnticipationStartHost(tbl.t)
                end
            end)
        end
        if not self._is_skirmish and (not self._assault_time.blocked or EHI:GetOption("show_captain_spawn_chance")) then
            managers.ehi_sync:AddReceiveHook(self._sync_sustain_start, function(data, sender)
                local tbl = json.decode(data)
                if tbl and tbl.t then
                    self._on_sustain_listener:call(tbl.t)
                end
            end)
        end
        managers.ehi_sync:AddReceiveHook(self._sync_endless_stop, function(data, sender)
            managers.ehi_tracker:CallFunction(self._assault_time.name, "SetEndlessAssault", false, json.decode(data))
        end)
        managers.ehi_sync:AddDropInListener(function()
            self._playing_from_start = false
        end)
    end
    self:AddAssaultDifficultyCallback(callback(self, self, "SetDiff"))
end

---@param hud HUDManager
function EHIAssaultManager:init_hud(hud)
    self._hud = hud
    self._control_info_f = function(_, data)
        managers.ehi_tracker:CallFunction(self._assault_delay.name, "SetHostages", data.nr_hostages)
    end
    Hooks:PostHook(hud, "set_control_info", "EHI_Assault_set_control_info", self._control_info_f)
end

---@param params ParseTriggersTable.assault?
function EHIAssaultManager:Parse(params)
    if not params then
        return
    end
    self:SetDiff(params.diff or 0)
    self._force_assault_start = params.force_assault_start
    self._ignore_assault_start_count = params.ignore_assault_start_count
    if params.wave_mode_elements_block then
        self._blocked_wave_mode_elements = table.list_to_set(params.wave_mode_elements_block)
    end
    if params.fake_assault_block then
        self._assault_block = true
        EHI:AddOnAlarmCallback(callback(self, self, "SetAssaultBlock", false))
    end
end

---@param diff number
function EHIAssaultManager:SetDiff(diff)
    if self._diff == diff then
        return
    end
    self._diff = diff
    self:CallFunction("UpdateDiff", diff)
end

---@param block boolean
---@param t number
function EHIAssaultManager:SetControlStateBlock(block, t)
    self._control_block = block
    if managers.ehi_tracker:Exists(self._assault_delay.name) then
        managers.ehi_tracker:CallFunction(self._assault_delay.name, "SetControlStateBlock", block, t)
    elseif not block then
        self:StartAssaultCountdown(t, true)
    end
end

---@param t number
---@param block_if_exists boolean?
function EHIAssaultManager:StartAssaultCountdown(t, block_if_exists)
    if self._assault_delay.blocked or self._control_block or self._internal.is_assault then
        return
    elseif block_if_exists and managers.ehi_tracker:Exists(self._assault_delay.name) then
        return
    end
    managers.ehi_tracker:AddTracker({
        id = self._assault_delay.name,
        time = t,
        diff_visual = self._diff,
        hint = self._assault_delay.hint,
        assault_number = self._assault_number,
        class = EHI.Trackers.Assault
    }, 0)
end

---@param t number
function EHIAssaultManager:AnticipationStartHost(t)
    managers.ehi_tracker:CallFunction(self._assault_delay.name, "StartAnticipation", t)
end

---@param t number
function EHIAssaultManager:SyncAnticipationStartHost(t)
    managers.ehi_sync:SyncTable(self._sync_anticipation_start, { t = t })
end

function EHIAssaultManager:AnticipationStart()
    if self._assault_delay.blocked then
        return
    end
    managers.ehi_tracker:CallFunction(self._assault_delay.name, self._anticipation_sync_f, 30)
    Hooks:RemovePostHook("EHI_Assault_set_control_info")
end

function EHIAssaultManager:AssaultStart()
    if (self._ignore_assault_start_count or 0) > 0 and self._playing_from_start then
        self._ignore_assault_start_count = self._ignore_assault_start_count - 1
        return
    end
    Hooks:RemovePostHook("EHI_Assault_set_control_info")
    if self._assault_delay.hide_on_delete then
        managers.ehi_tracker:CallFunction(self._assault_delay.name, "Hide")
    end
    if not self._internal.is_assault then
        self._assault_number = self._assault_number + 1
        if self._assault_start_callback then
            self._assault_start_callback:call(self._assault_number)
        end
    end
    if self._assault_time.blocked or (self._endless_assault and not self._assault_time.show_endless_assault) or self._internal.is_assault or self._assault_block then
        self._internal.is_assault = true
        if self._force_assault_start and not self._endless_assault and not self._assault_time.blocked and managers.ehi_tracker:CallFunction2(self._assault_time.name, "AssaultStart", self._diff) then
            managers.ehi_tracker:AddTracker({
                id = self._assault_time.name,
                assault = true,
                diff = self._diff,
                endless_assault = self._endless_assault,
                hint = self._assault_time.hint,
                assault_number = self._assault_number,
                class = EHI.Trackers.Assault
            }, 0)
        end
        return
    elseif managers.ehi_tracker:Exists(self._assault_time.name) then
        if self._endless_assault then
            managers.ehi_tracker:CallFunction(self._assault_time.name, "CalculateDifficultyRamp", self._diff)
            managers.ehi_tracker:CallFunction(self._assault_time.name, "SetEndlessAssault", true)
        else
            managers.ehi_tracker:CallFunction(self._assault_time.name, "AssaultStart", self._diff)
        end
    elseif self._diff > 0 or self._is_skirmish then
        managers.ehi_tracker:AddTracker({
            id = self._assault_time.name,
            assault = true,
            diff = self._diff,
            endless_assault = self._endless_assault,
            hint = self._assault_time.hint,
            assault_number = self._assault_number,
            class = EHI.Trackers.Assault
        }, 0)
    end
    self._internal.is_assault = true
end

---@param id string
---@param f fun(assault_number: integer)
function EHIAssaultManager:AddAssaultStartCallback(id, f)
    self._assault_start_callback = self._assault_start_callback or ListenerHolder:new()
    self._assault_start_callback:add(id, f)
end

---@param id string
function EHIAssaultManager:RemoveAssaultStartCallback(id)
    if self._assault_start_callback then
        self._assault_start_callback:remove(id)
    end
end

function EHIAssaultManager:AssaultEnd()
    if self._internal.is_assault and self._assault_end_callback then
        self._assault_end_callback:call(self._assault_number)
    end
    self._internal.is_assault = false
    if self._assault_block or self._assault_delay.blocked then
        return
    elseif managers.ehi_tracker:Exists(self._assault_time.name) then
        local f = self._control_block and "AssaultEndWithBlock" or "AssaultEnd"
        managers.ehi_tracker:CallFunction(self._assault_time.name, f, self._diff)
    elseif managers.ehi_tracker:Exists(self._assault_delay.name) and self._assault_delay.hide_on_delete then
        managers.ehi_tracker:RunTracker(self._assault_delay.name, {
            control_block = self._control_block,
            diff = self._diff
        }, 0)
    elseif self._diff > 0 and not self._control_block then
        managers.ehi_tracker:AddTracker({
            id = self._assault_delay.name,
            diff = self._diff,
            hint = self._assault_delay.hint,
            assault_number = self._assault_number,
            class = EHI.Trackers.Assault
        }, 0)
    end
    if not self._assault_delay.blocked then
        Hooks:PostHook(self._hud, "set_control_info", "EHI_Assault_set_control_info", self._control_info_f)
    end
end

---@param id string
---@param f fun(assault_number: integer)
function EHIAssaultManager:AddAssaultEndCallback(id, f)
    self._assault_end_callback = self._assault_end_callback or ListenerHolder:new()
    self._assault_end_callback:add(id, f)
end

---@param id string
function EHIAssaultManager:RemoveAssaultEndCallback(id)
    if self._assault_end_callback then
        self._assault_end_callback:remove(id)
    end
end

---@param f fun(assault_number: integer, in_assault: boolean)
function EHIAssaultManager:AddAssaultNumberSyncCallback(f)
    if self._vanilla_synced_from_host then
        return
    end
    self._assault_number_sync_callback = self._assault_number_sync_callback or CallbackEventHandler:new()
    self._assault_number_sync_callback:add(f)
end

---@param f fun(mode: "normal"|"endless", element_id: number)
function EHIAssaultManager:AddAssaultTypeChangedCallback(f)
    self._assault_type_changed_callback = self._assault_type_changed_callback or CallbackEventHandler:new()
    self._assault_type_changed_callback:add(f)
end

---@param mode "normal"|"endless"
---@param element_id number
function EHIAssaultManager:CallAssaultTypeChangedCallback(mode, element_id)
    if self._assault_type_changed_callback then
        self._assault_type_changed_callback:dispatch(mode, element_id)
    end
end

---@param f fun(mode: "normal"|"phalanx")
function EHIAssaultManager:AddAssaultModeChangedCallback(f)
    self._assault_mode_changed_callback = self._assault_mode_changed_callback or CallbackEventHandler:new()
    self._assault_mode_changed_callback:add(f)
end

---@param mode "normal"|"phalanx"
function EHIAssaultManager:CallAssaultModeChangedCallback(mode)
    if self._assault_mode_changed_callback then
        self._assault_mode_changed_callback:dispatch(mode)
    end
end

---@param id string
---@param f fun(duration: number)
function EHIAssaultManager:AddOnSustainListener(id, f)
    self._on_sustain_listener:add(id, f)
end

---@param id string
function EHIAssaultManager:RemoveOnSustainListener(id)
    self._on_sustain_listener:remove(id)
end

---@param f fun(diff: number) Number is always between 0 and 1
function EHIAssaultManager:AddAssaultDifficultyCallback(f)
    self._assault_diff_callback = self._assault_diff_callback or CallbackEventHandler:new()
    self._assault_diff_callback:add(f)
end

---@param diff number Number is always between 0 and 1
function EHIAssaultManager:CallAssaultDifficultyCallback(diff)
    if self._assault_diff_callback then
        self._assault_diff_callback:dispatch(diff)
    end
end

---@param assault_number number
---@param in_assault boolean
function EHIAssaultManager:SetCurrentAssaultNumber(assault_number, in_assault)
    self._assault_number = assault_number
    self._internal.is_assault = in_assault
    if self._assault_number_sync_callback then
        self._assault_number_sync_callback:dispatch(assault_number, in_assault)
        self._assault_number_sync_callback:clear()
        self._assault_number_sync_callback = nil
    end
    self._vanilla_synced_from_host = true
    self:CallFunction("SetProgress", assault_number)
end

---@param block boolean?
function EHIAssaultManager:SetAssaultBlock(block)
    self._assault_block = block
    if block then
        self:CallFunction("PoliceActivityBlocked")
    end
end

---@param f string
function EHIAssaultManager:CallFunction(f, ...)
    managers.ehi_tracker:CallFunction("Assault", f, ...)
    managers.ehi_tracker:CallFunction("AssaultDelay", f, ...)
    managers.ehi_tracker:CallFunction("AssaultTime", f, ...)
end

function EHIAssaultManager:Exists()
    return managers.ehi_tracker:Exists("Assault") or managers.ehi_tracker:Exists("AssaultDelay") or managers.ehi_tracker:Exists("AssaultTime")
end

---@param data SyncData
function EHIAssaultManager:save(data)
    if not self._is_skirmish then
        local state = {}
        state.diff = self._diff
        data.EHIAssaultManager = state
    end
end

---@param data SyncData
function EHIAssaultManager:load(data)
    local state = data.EHIAssaultManager
    if state then
        self._diff = state.diff
        self._anticipation_sync_f = "SyncAnticipationColor"
        self._synced_from_host = true
    end
end

return EHIAssaultManager