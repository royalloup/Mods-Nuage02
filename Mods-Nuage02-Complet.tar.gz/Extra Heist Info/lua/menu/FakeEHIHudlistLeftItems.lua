---@alias FakeEHILeftListBase.Item { panel: Panel, progress: Bitmap[][], progress_to_update: Bitmap[], progress_bg: Bitmap[], progress_only: Bitmap[], fake_pos: integer?, progress_value: number, progress_raw_value: number, progress_bar: Color, allow_color_change: boolean, allow_icon_color_change: boolean }

local template1 = Idstring("VertexColorTexturedRadial")
local template2 = Idstring("VertexColorTexturedRadialFlex")

---@class FakeEHILeftListBase
---@field new fun(self: self, panel: Panel, params: table, texture: string, texture_rect: TextureRect): self
FakeEHILeftListBase = class()
FakeEHILeftListBase._COLOR_CHANGE_AFFECTS_WHOLE_ITEM = true
FakeEHILeftListBase._PROGRESS_RECT = {
    { 32, 0, -32, 32 },
    { 128, 0, -128, 128 }
}
---@param panel Panel
---@param params table
---@param texture string
---@param texture_rect TextureRect
function FakeEHILeftListBase:init(panel, params, texture, texture_rect)
    self._id = params.id
    self._enabled = params.enabled
    self._visible = params.visible
    self._list_enabled = params.list_enabled
    local scale = params.scale or 1
    self._params = {
        x = params.x,
        progress = params.progress or 1,
        bg_color = params.bg_color,
        progress_visibility = params.progress_visibility,
        scale = scale,
        top_text_enabled = params.top_text,
        bottom_text_enabled = params.bottom_text,
        list_icon = params.list_icon,
        anim_right_to_left = params.right_to_left,
        top_offset = 16,
        bottom_offset = 16,
        item_w = 32 * scale
    }
    if self._params.anim_right_to_left and not self._params.list_icon then
        self.__add_x_item_offset = true
    end
    local top_text, bottom_text = 0, 0
    if params.items then
        for _, data in ipairs(params.items) do
            if data.top_text then
                top_text = top_text + 1
            end
            if data.bottom_text then
                bottom_text = bottom_text + 1
            end
        end
    end
    self._params.top_text = top_text
    self._params.bottom_text = bottom_text
    self._panel = panel:panel({
        y = 80,
        w = panel:w(),
        h = 64 * scale, -- 32 is base, 32 is for top and bottom text
        visible = self._enabled and self._visible and self._list_enabled or false
    })
    local icon_size = 32 * scale
    self._panel:bitmap({
        name = "icon",
        y = 16 * scale,
        w = icon_size,
        h = icon_size,
        texture = texture,
        texture_rect = texture_rect,
        visible = params.list_icon
    })
    self._items = {} ---@type FakeEHILeftListBase.Item[]
    if params.items then
        local bg_alpha = params.bg_alpha or 1
        local progress_alpha = params.progress_alpha or 1
        local color_index = params.color_index
        for i, data in ipairs(params.items) do
            self:AddItem(i, data, scale, bg_alpha, progress_alpha, color_index)
        end
    end
end

---@param scale number
function FakeEHILeftListBase:Rescale(scale)
    self._params.scale = scale
    local w = 32 * scale
    local h = 16 * scale
    local icon_offset = 4 * scale
    local icon_size = 24 * scale
    self._params.item_w = w
    self._panel:set_h(64 * scale)
    local main_icon = self._panel:child("icon") ---@cast main_icon -?
    main_icon:set_y(h)
    main_icon:set_size(w, w)
    local panel_h = self._panel:h()
    local icon_y = main_icon:y()
    for i, item in ipairs(self._items) do
        local panel = item.panel
        panel:set_size(w, panel_h)
        local top_text = panel:child("top_text") --[[@as Text?]]
        if top_text then
            top_text:set_size(w, h)
            top_text:set_font_size(h)
            self:FitTheText(top_text)
        end
        local bottom_text = panel:child("bottom_text") --[[@as Text?]]
        if bottom_text then
            bottom_text:set_y(icon_y + w)
            bottom_text:set_size(w, h)
            bottom_text:set_font_size(h)
            self:FitTheText(bottom_text)
        end
        local icon = panel:child("icon") ---@cast icon -?
        icon:set_position(icon_offset, icon_y + icon_offset)
        icon:set_size(icon_size, icon_size)
        for _, bitmaps in ipairs(item.progress) do
            for _, bitmap in ipairs(bitmaps) do
                bitmap:set_y(icon_y)
                bitmap:set_size(w, w)
            end
        end
        self:SortAddedItem(panel, item.fake_pos or i, scale)
    end
end

---@param scale number
function FakeEHILeftListBase:GetFirstItemStartX(scale)
    local x, w = self._params.x, self._params.item_w
    local first_item_offset = 10 * scale
    if self._params.list_icon then
        if self._params.anim_right_to_left then
            return x - w - first_item_offset
        else
            return x + w + first_item_offset
        end
    elseif self._params.anim_right_to_left then
        return x + w - first_item_offset
    end
    return x
end

---@param text Text
function FakeEHILeftListBase:FitTheText(text)
    text:set_font_size(text:h())
    local w = select(3, text:text_rect())
    if w > text:w() then
        text:set_font_size(text:font_size() * (text:w() / w))
    end
end

---@param t number
---@param i integer
function FakeEHILeftListBase:Format(t, i)
    if self._parent._format.time == 1 then
        return tweak_data.ehi.functions:ReturnSecondsOnly(t)
    else
        return tweak_data.ehi.functions:ReturnMinutesAndSeconds(t)
    end
end

---@param enabled boolean
function FakeEHILeftListBase:SetEnabled(enabled)
    self._enabled = enabled
    self._panel:set_visible(self._visible and self._list_enabled and enabled)
end

---@param enabled boolean
function FakeEHILeftListBase:SetListEnabled(enabled)
    self._list_enabled = enabled
    self._panel:set_visible(self._visible and self._enabled and enabled)
end

---@param visibility boolean
function FakeEHILeftListBase:SetVisibility(visibility)
    self._visible = visibility
    self._panel:set_visible(self._enabled and self._list_enabled and visibility)
end

function FakeEHILeftListBase:ItemIsVisible()
    return self._enabled
end

function FakeEHILeftListBase:GetRealHeight()
    local h = 64 --32 + self._params.top_offset + self._params.bottom_offset
    if self._params.top_text <= 0 or not self._params.top_text_enabled then
        h = h - self._params.top_offset
    end
    if self._params.bottom_text <= 0 or not self._params.bottom_text_enabled then
        h = h - self._params.bottom_offset
    end
    return h * self._params.scale
end

function FakeEHILeftListBase:GetOffset()
    local offset = 0
    if self._params.top_text <= 0 or not self._params.top_text_enabled then
        offset = offset + self._params.top_offset
    end
    return offset * self._params.scale
end

---@param x number
function FakeEHILeftListBase:SetX(x)
    if self.__add_x_item_offset then
        x = x + self._params.item_w
    end
    self._params.x = x
    self._panel:child("icon"):set_x(x)
    self:_SetX()
end

function FakeEHILeftListBase:_SetX()
    for i, item in ipairs(self._items) do
        self:SortAddedItem(item.panel, item.fake_pos or i, self._params.scale)
    end
end

---@param y number
function FakeEHILeftListBase:SetY(y)
    self._panel:set_y(y - self:GetOffset())
end

---@param i integer
---@param params { icon: table, progress: number?, progress_between: number[]?, color: integer?, icon_color: Color?, top_text: table, bottom_text: table, fake_pos: integer? }
---@param scale number
---@param bg_alpha number
---@param progress_alpha number
---@param color_index integer
function FakeEHILeftListBase:AddItem(i, params, scale, bg_alpha, progress_alpha, color_index)
    local progress, max_progress
    if params.progress_between then
        max_progress = params.progress_between[2]
        progress = math.rand(params.progress_between[1], params.progress_between[2])
    else
        max_progress = params.progress
        progress = math.rand(params.progress)
    end
    local value = progress / max_progress
    local w = 32 * scale
    local h = 16 * scale
    local progress_bar = Color(1, value, 0.125, 1)
    local y = self._panel:child("icon"):y()
    local panel = self._panel:panel({
        w = w,
        h = self._panel:h() -- Scale is already applied here
    })
    local texture, texture_rect = tweak_data.ehi.default.hudlist.get_icon(params.icon)
    local color_value, color_string = tweak_data.ehi:GetBuffColorFromIndex(params.color or color_index)
    local icon_color = params.icon_color or color_value
    local progress_sframe, progress_cframe = {}, {}
    progress_sframe[1] = panel:bitmap({
        alpha = progress_alpha,
        render_template = "VertexColorTexturedRadialFlex",
        layer = 10,
        y = y,
        w = w,
        h = w,
        texture = string.format("guis/textures/pd2_mod_ehi/buffs/buff_sframe_%s", color_string),
        texture_rect = self._PROGRESS_RECT[1],
        color = progress_bar,
        visible = self._params.progress == 1 and self._params.progress_visibility
    })
    progress_sframe[2] = panel:rect({
        blend_mode = "normal",
        halign = "grow",
        alpha = bg_alpha,
        layer = -1,
        valign = "grow",
        y = y,
        w = w,
        h = w,
        color = self._params.bg_color,
        visible = self._params.progress == 1
    })
    progress_cframe[1] = panel:bitmap({
        alpha = progress_alpha,
        render_template = "VertexColorTexturedRadial",
        layer = 10,
        y = y,
        w = w,
        h = w,
        texture = string.format("guis/textures/pd2_mod_ehi/buffs/buff_cframe_%s", color_string),
        texture_rect = self._PROGRESS_RECT[2],
        color = progress_bar,
        visible = self._params.progress == 2 and self._params.progress_visibility
    })
    progress_cframe[2] = panel:bitmap({
        alpha = bg_alpha,
        layer = -1,
        y = y,
        w = w,
        h = w,
        texture = "guis/textures/pd2_mod_ehi/buffs/buff_cframe_bg_white",
        color = self._params.bg_color:with_alpha(0.2),
        visible = self._params.progress == 2
    })
    local icon_offset = 4 * scale
    local icon_size = 24 * scale
    panel:bitmap({
        name = "icon",
        x = icon_offset,
        y = y + icon_offset,
        w = icon_size,
        h = icon_size,
        texture = texture,
        texture_rect = texture_rect,
        color = icon_color
    })
    if params.top_text then
        local text = params.top_text.text or ""
        if params.top_text.localize then
            text = managers.localization:text(text)
        end
        self:FitTheText(panel:text({
            name = "top_text",
            w = w,
            h = h,
            text = text,
            font = tweak_data.menu.pd2_large_font,
            font_size = h,
            align = "center",
            vertical = "center",
            color = color_value,
            visible = self._params.top_text_enabled
        }))
    end
    if params.bottom_text then
        self:FitTheText(panel:text({
            name = "bottom_text",
            y = y + w,
            w = w,
            h = h,
            text = self:Format(progress, i),
            font = tweak_data.menu.pd2_large_font,
            font_size = h,
            align = "center",
            vertical = "center",
            color = color_value
        }))
    end
    local pos = table.size(self._items) + 1
    local fake_pos = params.fake_pos
    local data =
    {
        fake_pos = fake_pos,
        panel = panel,
        progress = { progress_sframe, progress_cframe },
        progress_to_update = { progress_sframe[1], progress_cframe[1] },
        progress_bg = { progress_sframe[2], progress_cframe[2] },
        progress_only = { progress_sframe[1], progress_cframe[1] },
        progress_raw_value = progress,
        progress_value = value,
        progress_bar = progress_bar,
        allow_color_change = params.color == nil,
        allow_icon_color_change = params.icon_color == nil
    }
    self:_AddItem(data, panel, y, progress_bar, scale, bg_alpha, progress_alpha, color_string)
    self:SortAddedItem(panel, fake_pos or pos, scale)
    self._items[pos] = data
end

---@param data FakeEHILeftListBase.Item
---@param panel Panel
---@param y number
---@param progress_bar Color
---@param scale number
---@param bg_alpha number
---@param progress_alpha number
---@param color_string string
function FakeEHILeftListBase:_AddItem(data, panel, y, progress_bar, scale, bg_alpha, progress_alpha, color_string)
end

---Sorts newly added item panel on the HUD, but not in the memory
---@param panel Panel
---@param pos integer
---@param scale number
function FakeEHILeftListBase:SortAddedItem(panel, pos, scale)
    local x = self:GetFirstItemStartX(scale)
    if pos <= 1 then
        panel:set_x(x)
    else
        local offset = 5 * scale
        pos = pos - 1
        if self._params.anim_right_to_left then
            panel:set_x(x - (panel:w() + offset) * pos)
        else
            panel:set_x(x + (panel:w() + offset) * pos)
        end
    end
end

---@param static boolean
function FakeEHILeftListBase:SetProgressStatic(static)
    for _, item in ipairs(self._items) do
        item.progress_bar.r = static and 1 or item.progress_value
        for _, bitmap in ipairs(item.progress_only) do
            local render_template = bitmap:render_template()
            if render_template == template1 or render_template == template2 then
                bitmap:set_color(item.progress_bar)
            end
        end
    end
end

---@param progress integer
---@param from_visibility boolean?
function FakeEHILeftListBase:SetProgress(progress, from_visibility)
    self._params.progress = progress
    for _, item in ipairs(self._items) do
        for i, bitmaps in ipairs(item.progress) do
            for _, obj in ipairs(bitmaps) do
                obj:set_visible(i == progress)
            end
        end
    end
    self:_SetProgress(progress)
    if not from_visibility then
        self:SetProgressVisibility(self._params.progress_visibility, true)
    end
end

---@param progress integer
function FakeEHILeftListBase:_SetProgress(progress)
end

---@param visibility boolean
---@param from_progress boolean?
function FakeEHILeftListBase:SetProgressVisibility(visibility, from_progress)
    self._params.progress_visibility = visibility
    for _, item in ipairs(self._items) do
        for i, bitmap in ipairs(item.progress_only) do
            bitmap:set_visible(i == self._params.progress and visibility)
        end
    end
end

---@param pos integer
---@param clr integer Gets converted to color and string
function FakeEHILeftListBase:SetItemProgressColor(pos, clr)
    local item = self._items[pos]
    local color, color_string = tweak_data.ehi:GetBuffColorFromIndex(clr)
    if self._COLOR_CHANGE_AFFECTS_WHOLE_ITEM then
        local top_text = item.panel:child("top_text") --[[@as Text?]]
        if top_text then
            top_text:set_color(color)
        end
        local bottom_text = item.panel:child("bottom_text") --[[@as Text?]]
        if bottom_text then
            bottom_text:set_color(color)
        end
        item.panel:child("icon"):set_color(color) ---@diagnostic disable-line
    end
    for i, obj in ipairs(item.progress_to_update) do
        obj:set_image(string.format("guis/textures/pd2_mod_ehi/buffs/buff_%s_%s", i == 1 and "sframe" or "cframe", color_string), unpack(self._PROGRESS_RECT[i]))
    end
end

function FakeEHILeftListBase:SetTimeFormat()
    for i, item in ipairs(self._items) do
        local bottom_text = item.panel:child("bottom_text") --[[@as Text?]]
        if bottom_text then
            bottom_text:set_text(self:Format(item.progress_raw_value, i))
        end
    end
end

---@param a number
function FakeEHILeftListBase:UpdateBGAlpha(a)
    for _, item in ipairs(self._items) do
        for _, bitmap in ipairs(item.progress_bg) do
            bitmap:set_alpha(a)
        end
    end
end

---@param color { r: number, g: number, b: number }
function FakeEHILeftListBase:UpdateBGColor(color)
    local c = Color(255, color.r, color.g, color.b) / 255
    for _, item in ipairs(self._items) do
        for i, bitmap in ipairs(item.progress_bg) do
            if i == 1 then
                bitmap:set_color(c)
            elseif i == 2 then
                bitmap:set_color(c:with_alpha(0.2))
            else
                self:_UpdateBGColor(i, bitmap, c)
            end
        end
    end
end

---@param i integer
---@param bitmap Bitmap
---@param color Color
function FakeEHILeftListBase:_UpdateBGColor(i, bitmap, color)
end

---@param a number
function FakeEHILeftListBase:UpdateProgressAlpha(a)
    for _, item in ipairs(self._items) do
        for _, bitmap in ipairs(item.progress_only) do
            bitmap:set_alpha(a)
        end
    end
end

---@param visible boolean
function FakeEHILeftListBase:UpdateTopText(visible)
    if self._params.top_offset <= 0 then
        return
    end
    self._params.top_text_enabled = visible
    for _, item in ipairs(self._items) do
        local top_text = item.panel:child("top_text")
        if top_text then
            top_text:set_visible(visible)
        end
    end
    self:_UpdateTopText(visible)
end

---@param visible boolean
function FakeEHILeftListBase:_UpdateTopText(visible)
end

---@param visible boolean
function FakeEHILeftListBase:UpdateListIconVisibility(visible)
    self._panel:child("icon"):set_visible(visible)
    self._params.list_icon = visible
    self:_SetX()
end

---@param alignment boolean
function FakeEHILeftListBase:UpdateAlignment(alignment)
    local previous_state = self._params.anim_right_to_left
    self._params.anim_right_to_left = alignment
    if previous_state == alignment then -- Nothing changed
        return
    elseif previous_state and not alignment then -- Went from RtL to LtR
        self:_SetX()
        self.__add_x_item_offset = nil
    else -- Went from LtR to RtL
        self:_SetX()
        self.__add_x_item_offset = true
    end
end

---@param color_index integer
function FakeEHILeftListBase:UpdateItemsColor(color_index)
    local color, color_string = tweak_data.ehi:GetBuffColorFromIndex(color_index)
    for _, item in ipairs(self._items) do
        if item.allow_color_change then
            local top_text = item.panel:child("top_text") --[[@as Text?]]
            if top_text then
                top_text:set_color(color)
            end
            local bottom_text = item.panel:child("bottom_text") --[[@as Text?]]
            if bottom_text then
                bottom_text:set_color(color)
            end
            if item.allow_icon_color_change then
                item.panel:child("icon"):set_color(color) ---@diagnostic disable-line
            end
            for i, bitmap in ipairs(item.progress_only) do
                bitmap:set_image(string.format("guis/textures/pd2_mod_ehi/buffs/buff_%s_%s", i == 1 and "sframe" or "cframe", color_string), unpack(self._PROGRESS_RECT[i] or self._PROGRESS_RECT[2]))
            end
        end
    end
end

---@class FakeEHILeftDeployableItem : FakeEHILeftListBase
---@field super FakeEHILeftListBase
FakeEHILeftDeployableList = class(FakeEHILeftListBase)
function FakeEHILeftDeployableList:init(panel, params, ...)
    FakeEHILeftDeployableList.super.init(self, panel, params, ...)
    self._selected_color = tweak_data.ehi:GetBuffColorFromIndex(params.color_index)
    self._peer_color = self._items[3].panel:child("icon"):color():with_alpha(1) ---@diagnostic disable-line
    self:UpdateFormat(params.format)
    self:SetAggregateDeployables(params.aggregate)
end

---@param aggregate boolean
function FakeEHILeftDeployableList:SetAggregateDeployables(aggregate)
    self._items[1].panel:set_visible(not aggregate)
    self._items[2].panel:set_visible(aggregate)
    self._items[3].panel:child("icon"):set_color(aggregate and Color.white or self._peer_color) ---@diagnostic disable-line
end

---@param t number
---@param i integer
function FakeEHILeftDeployableList:Format(t, i)
    if not self._params.format then
        return FakeEHILeftDeployableList.super.Format(self, t, 0)
    elseif self._params.format == 1 then -- Multiplier
        return string.format(i == 3 and "%.2fx" or "%dx", t)
    else -- Percent
        return string.format("%d%%", t * 100)
    end
end

---@param format integer
function FakeEHILeftDeployableList:UpdateFormat(format)
    if self._params.format == format then
        return
    end
    self._params.format = format
    for i, item in ipairs(self._items) do
        item.panel:child("bottom_text"):set_text(self:Format(item.progress_raw_value, i)) ---@diagnostic disable-line
    end
end

function FakeEHILeftDeployableList:SetTimeFormat()
end

---@param color_index integer
function FakeEHILeftDeployableList:UpdateItemsColor(color_index)
    self._selected_color = tweak_data.ehi:GetBuffColorFromIndex(color_index)
    FakeEHILeftDeployableList.super.UpdateItemsColor(self, color_index)
end

---@class FakeEHILeftMinionItem : FakeEHILeftListBase
---@field super FakeEHILeftListBase
FakeEHILeftMinionList = class(FakeEHILeftListBase)
FakeEHILeftMinionList._ICON_SKULL = { ehi = EHI:GetAchievementIconString("trk_a_0") }
function FakeEHILeftMinionList:init(panel, params, ...)
    FakeEHILeftMinionList.super.init(self, panel, params, ...)
    self._selected_color = tweak_data.ehi:GetBuffColorFromIndex(params.color_index)
    self:SetOtherMinionsVisible(params.minion_option)
    self:SetMinionHealthCircle(params.health_circle, true)
end

---@param visibility boolean
---@param from_start boolean?
function FakeEHILeftMinionList:SetMinionHealthCircle(visibility, from_start)
    if from_start and not visibility then
        return
    end
    self._health_circles = visibility
    self:SetProgress(visibility and 3 or self._params.progress_original)
end

function FakeEHILeftMinionList:_AddItem(data, panel, y, progress_bar, scale, bg_alpha, progress_alpha, color_string)
    local w = 32 * scale
    local progress = {} ---@type Bitmap[]
    progress[1] = panel:bitmap({
        render_template = "VertexColorTexturedRadial",
        layer = 10,
        y = y,
        w = w,
        h = w,
        texture = "guis/textures/pd2/hud_health",
        texture_rect = self._PROGRESS_RECT[2],
        color = progress_bar,
        visible = false
    })
    progress[2] = panel:bitmap({
        alpha = progress_alpha,
        layer = 11,
        y = y,
        w = w,
        h = w,
        texture = string.format("guis/textures/pd2_mod_ehi/buffs/buff_cframe_%s", color_string),
        texture_rect = self._PROGRESS_RECT[2],
        visible = false
    })
    progress[3] = panel:bitmap({
        alpha = bg_alpha,
        layer = -1,
        y = y,
        w = w,
        h = w,
        texture = "guis/textures/pd2_mod_ehi/buffs/buff_cframe_bg_white",
        color = self._params.bg_color:with_alpha(0.2),
        visible = false
    })
    local texture, texture_rect = tweak_data.ehi.default.hudlist.get_icon(self._ICON_SKULL)
    local skull = panel:bitmap({
        name = "skull",
        layer = 12,
        w = 16 * scale,
        h = 16 * scale,
        texture = texture,
        texture_rect = texture_rect,
        visible = false
    })
    skull:set_center(progress[1]:center())
    table.insert(data.progress, progress)
    table.insert(data.progress_bg, progress[3])
    table.insert(data.progress_only, progress[2])
end

function FakeEHILeftMinionList:SetProgress(progress, ...)
    if self._health_circles and progress == 3 then
        self._params.progress_original = self._params.progress
    elseif self._health_circles then
        self._params.progress_original = progress
        return
    end
    FakeEHILeftMinionList.super.SetProgress(self, progress, ...)
end

function FakeEHILeftMinionList:_SetProgress(progress)
    local health_circle = progress == 3
    for _, item in ipairs(self._items) do
        local icon = item.panel:child("icon") --[[@as Bitmap]]
        local skull = item.panel:child("skull") --[[@as Bitmap]]
        icon:set_visible(progress ~= 3)
        skull:set_visible(health_circle and not self._params.top_text_enabled)
        item.panel:child("top_text"):set_color(health_circle and icon:color():with_alpha(1) or self._selected_color) ---@diagnostic disable-line
        skull:set_color(health_circle and icon:color():with_alpha(1) or self._selected_color)
    end
end

---@param option integer
function FakeEHILeftMinionList:SetOtherMinionsVisible(option)
    self._items[2].panel:set_visible(option == 1)
end

---@param i integer
---@param bitmap Bitmap
---@param color Color
function FakeEHILeftMinionList:_UpdateBGColor(i, bitmap, color)
    bitmap:set_color(color:with_alpha(0.2))
end

---@param visible boolean
function FakeEHILeftMinionList:_UpdateTopText(visible)
    for _, item in ipairs(self._items) do
        item.panel:child("skull"):set_visible(self._params.progress == 3 and not visible)
    end
end

---@param color_index integer
function FakeEHILeftMinionList:UpdateItemsColor(color_index)
    self._selected_color = tweak_data.ehi:GetBuffColorFromIndex(color_index)
    FakeEHILeftMinionList.super.UpdateItemsColor(self, color_index)
end

---@class FakeEHILeftJammerItem : FakeEHILeftListBase
---@field super FakeEHILeftListBase
FakeEHILeftJammerList = class(FakeEHILeftListBase)
FakeEHILeftJammerList._COLOR_CHANGE_AFFECTS_WHOLE_ITEM = false
function FakeEHILeftJammerList:init(panel, params, ...)
    FakeEHILeftJammerList.super.init(self, panel, params, ...)
    self._items[2].allow_color_change = false
    self._selected_color = tweak_data.ehi:GetBuffColorFromIndex(params.color_index)
    if self._params.progress_visibility then
        self:SetItemProgressColor(2, params.affects_pager_color_index)
    else
        self._affects_pager_color = tweak_data.ehi:GetBuffColorFromIndex(params.affects_pager_color_index)
        self._items[2].panel:child("bottom_text"):set_color(self._affects_pager_color) ---@diagnostic disable-line
    end
end

function FakeEHILeftJammerList:SetProgressVisibility(visibility, ...)
    local color = visibility and self._selected_color or self._affects_pager_color
    self._items[2].panel:child("bottom_text"):set_color(color) ---@diagnostic disable-line
    FakeEHILeftJammerList.super.SetProgressVisibility(self, visibility, ...)
end

function FakeEHILeftJammerList:SetItemProgressColor(pos, clr)
    FakeEHILeftJammerList.super.SetItemProgressColor(self, pos, clr)
    if pos == 2 then
        local color, _ = tweak_data.ehi:GetBuffColorFromIndex(clr)
        self._affects_pager_color = color
        if not self._params.progress_visibility then
            self._items[pos].panel:child("bottom_text"):set_color(color) ---@diagnostic disable-line
        end
    end
end

---@param color_index integer
function FakeEHILeftJammerList:UpdateItemsColor(color_index)
    self._selected_color = tweak_data.ehi:GetBuffColorFromIndex(color_index)
    FakeEHILeftJammerList.super.UpdateItemsColor(self, color_index)
end