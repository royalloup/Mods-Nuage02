---@class Drill
---@field _autorepair_clbk_id string?
---@field _autorepair_chance number
---@field _disable_upgrades boolean
---@field _unit UnitTimer
---@field EVENT_IDS table<string, number>
---@field is_drill boolean
---@field is_hacking_device boolean
---@field is_saw boolean
---@field get_skill_upgrades fun(self: self): table

if EHI:CheckLoadHook("Drill") then
    return
end
local highest_id = 0
for _, id in pairs(Drill.EVENT_IDS) do
    highest_id = math.max(highest_id, id)
end
local HasAutorepair = highest_id + 1
local NoAutorepair = highest_id + 2

local original = {}

---@param unit_key string
---@param autorepair boolean
local function SetAutorepair(unit_key, autorepair)
    if managers.ehi_timer then
        managers.ehi_timer:SetAutorepair(unit_key, autorepair)
    end
    managers.ehi_hudlist:CallLeftListItemFunction("Timer", "SetAutorepair", unit_key, autorepair)
end

if EHI.IsHost then
    original.set_autorepair = Drill.set_autorepair
    function Drill:set_autorepair(...)
        original.set_autorepair(self, ...)
        SetAutorepair(tostring(self._unit:key()), self._autorepair_clbk_id --[[@as boolean]])
        managers.network:session():send_to_peers_synched("sync_unit_event_id_16", self._unit, "base", self._autorepair_clbk_id and HasAutorepair or NoAutorepair)
    end
    original.on_autorepair = Drill.on_autorepair
    function Drill:on_autorepair(...)
        original.on_autorepair(self, ...)
        managers.network:session():send_to_peers_synched("sync_unit_event_id_16", self._unit, "base", NoAutorepair)
        SetAutorepair(tostring(self._unit:key()), false)
    end
    original.set_jammed = Drill.set_jammed
    function Drill:set_jammed(...)
        original.set_jammed(self, ...)
        if self._autorepair_chance then
            SetAutorepair(tostring(self._unit:key()), self._autorepair_clbk_id --[[@as boolean]])
            managers.network:session():send_to_peers_synched("sync_unit_event_id_16", self._unit, "base", self._autorepair_clbk_id and HasAutorepair or NoAutorepair)
        end
    end
else
    original.sync_net_event = Drill.sync_net_event
    function Drill:sync_net_event(event_id, ...)
        if math.within(event_id, HasAutorepair, NoAutorepair) then
            SetAutorepair(tostring(self._unit:key()), event_id == HasAutorepair)
        end
        original.sync_net_event(self, event_id, ...)
    end
end