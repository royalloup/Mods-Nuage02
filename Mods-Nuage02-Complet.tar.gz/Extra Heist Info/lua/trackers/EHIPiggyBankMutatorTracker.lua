local Color = Color
---@class EHIPiggyBankMutatorTracker : EHIProgressTracker
---@field super EHIProgressTracker
EHIPiggyBankMutatorTracker = class(EHIProgressTracker)
EHIPiggyBankMutatorTracker._forced_icons = { { icon = "piggy", color = Color.yellow } }
EHIPiggyBankMutatorTracker._forced_hint_text = "piggy"
function EHIPiggyBankMutatorTracker:init(panel, params)
    self._current_level = 1
    self._max_levels = 7
    params.flash_times = 1
    if params.id == "pda10_event" then
        self._piggy_tweak_data = tweak_data.mutators.piggyrevenge.pig_levels
    else
        self._piggy_tweak_data = tweak_data.mutators.piggybank.pig_levels
    end
    EHIPiggyBankMutatorTracker.super.init(self, panel, params)
    self:SetNewMax()
end

function EHIPiggyBankMutatorTracker:OverridePanel()
    self:SetBGSize()
    self._levels_text = self:CreateText({
        text = self:Format(self._current_level, self._max_levels),
        w = self._bg_box:w() / 2,
        left = self._text:right(),
        FitTheText = true
    })
end

function EHIPiggyBankMutatorTracker:SetNewMax()
    local level = self._piggy_tweak_data[self._current_level]
    local new_max = level and level.bag_requirement or 0
    if self._current_level <= 2 then
        new_max = new_max + 1
    end
    self._max = new_max
    self:SetAndFitTheText()
end

function EHIPiggyBankMutatorTracker:SetCompleted(force)
    self._current_level = self._current_level + 1
    if self._current_level == self._max_levels then
        self._disable_counting = true
        self:SetAndFitTheText("MAX")
        self:SetTextColor(Color.green)
    else
        self:SetNewMax()
        self:AnimateNewLevel()
    end
    self._levels_text:set_text(self:Format(self._current_level, self._max_levels))
end

function EHIPiggyBankMutatorTracker:SyncLoad(data)
    self._progress = data.pig_fed_count
    if self._progress == 0 then -- The game has not started yet or players haven't secured bags yet
        return
    end
    local n = table.size(self._piggy_tweak_data)
    local offset = { 1, 1 }
    local done = false
    for i = 1, n, 1 do
        local max = (self._piggy_tweak_data[i].bag_requirement or 0) + (offset[i] or 0)
        if max > self._progress then
            self._current_level = i
            self._max = max
            self:SetAndFitTheText()
            done = true
            break
        end
    end
    if not done and self._progress >= (self._piggy_tweak_data[n].bag_requirement or 0) then
        self._current_level = 6
        self:SetCompleted()
    end
end

function EHIPiggyBankMutatorTracker:AnimateNewLevel()
    if self._text and alive(self._text) then
        self._text:stop()
        self._text:animate(function(o)
            local spins = 1
            while spins <= 3 do
                local t = 0
                while t < 1 do
                    t = t + coroutine.yield()
                    local n = 1 - math.sin(t * 180)
                    --local r = lerp(1, 0, n)
                    local g = math.lerp(1, 0, n)
                    local c = Color(g, 1, g)
                    self:SetTextColor(c)
                end
                spins = spins + 1
            end
            self:SetTextColor(Color.white)
        end)
    end
end

function EHIPiggyBankMutatorTracker:SetTextColor(color)
    self._levels_text:set_color(color)
    EHIPiggyBankMutatorTracker.super.SetTextColor(self, color)
end