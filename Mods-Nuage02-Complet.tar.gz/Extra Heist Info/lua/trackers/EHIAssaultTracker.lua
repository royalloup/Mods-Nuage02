local Color = Color
local Captain = Color(255, 255, 128, 0) / 255
local Control = Color.white
local Anticipation = Color(255, 186, 204, 28) / 255
local Build = Color.yellow
local Sustain = Color(255, 237, 127, 127) / 255
local Fade = Color(255, 0, 255, 255) / 255
local State =
{
    control = 1,
    anticipation = 2,
    build = 3,
    sustain = 4,
    fade = 5,
    endless = 6,
    captain = 7
}
local assault_values = tweak_data.group_ai[tweak_data.levels:GetGroupAIState()].assault
local tweak_values = assault_values.delay
local hostage_values = assault_values.hostage_hesitation_delay
---@class EHIAssaultTracker : EHIWarningTracker, EHIChanceTracker, EHIProgressTracker, EHICountTracker
---@field super EHIWarningTracker
EHIAssaultTracker = class(EHIWarningTracker)
EHIAssaultTracker._forced_icons = { { icon = "assaultbox", color = Control } }
EHIAssaultTracker._is_client = EHI.IsClient
EHIAssaultTracker._inaccurate_text_color = EHI:GetColorFromOption("tracker_waypoint", "inaccurate")
EHIAssaultTracker._paused_color = EHIPausableTracker._paused_color
if EHI:GetOption("show_assault_diff_in_assault_trackers") then
    if tweak_data.levels:IsLevelSkirmish() then
        EHIAssaultTracker._SHOW_ASSAULT_DIFF_SKIRMISH = true
        EHIAssaultTracker._SKIRMISH_WAVE_DATA = tweak_data.skirmish:GetWaveData()
        EHIAssaultTracker.IncreaseProgress = EHIProgressTracker.IncreaseProgress
    else
        EHIAssaultTracker._SHOW_ASSAULT_DIFF = true
        EHIAssaultTracker.FormatChance = EHIChanceTracker.Format
        EHIAssaultTracker.SetChance = EHIChanceTracker.SetChance
        EHIAssaultTracker.SetChancePercent = EHIChanceTracker.SetChancePercent
        EHIAssaultTracker._anim_chance = EHIChanceTracker._anim_chance
    end
end
if EHI:GetOption("show_assault_enemy_count") and (EHI:CombineAssaultDelayAndAssaultTime() or EHI:GetOption("show_assault_time_tracker")) then
    EHIAssaultTracker._SHOW_AMOUNT_OF_ENEMIES = true
    EHIAssaultTracker.SetCount = EHICountTracker.SetCount
    EHIAssaultTracker.AlarmEnemyRegistered = EHICountTracker.IncreaseCount
    EHIAssaultTracker.NormalEnemyRegistered = EHICountTracker.IncreaseCount
    EHIAssaultTracker.AlarmEnemyUnregistered = EHICountTracker.DecreaseCount
    EHIAssaultTracker.NormalEnemyUnregistered = EHICountTracker.DecreaseCount
    EHIAssaultTracker.FormatCount = EHICountTracker.FormatCount
end
if type(tweak_values) == "table" then
    local first_value = tweak_values[1] or 0
    if table.true_for_all(tweak_values, function(value, key)
        return value == first_value
    end) then -- All numbers the same, use it and avoid computation because it is expensive
        EHIAssaultTracker._ASSAULT_DELAY = first_value
    end
else -- If for some reason the assault delay is not a table, use the value directly
    EHIAssaultTracker._ASSAULT_DELAY = tonumber(tweak_values) or tweak_data.levels:IsLevelSkirmish() and 25 or 30
end
if type(hostage_values) == "table"  then
    local first_value = hostage_values[1] or 0
    if table.true_for_all(hostage_values, function(value, key)
        return value == first_value
    end) then -- All numbers the same, use it and avoid computation because it is expensive
        EHIAssaultTracker._PRECOMPUTED_HOSTAGE_DELAY = true
        EHIAssaultTracker._HOSTAGE_DELAY = first_value
    end
else -- If for some reason the hesitation delay is not a table, use the value directly
    EHIAssaultTracker._PRECOMPUTED_HOSTAGE_DELAY = true
    EHIAssaultTracker._HOSTAGE_DELAY = tonumber(hostage_values) or 30
end
EHIAssaultTracker._ANTICIPATION_DELAY = tweak_data.levels:IsLevelSkirmish() and 15 or 30
if EHI.IsHost and EHI:IsModInstalled("Hostages Extend Break Time", "Pat") then
    EHIAssaultTracker._ANTICIPATION_DELAY_PER_HOSTAGE = 5
end
EHIAssaultTracker._SHOW_ASSAULT_DELAY = EHI:GetOption("show_assault_delay_tracker")
function EHIAssaultTracker:init(panel, params)
    self._refresh_on_delete = true
    self:CalculateDifficultyRamp(params.diff or 0)
    self.update_break = self.update
    if params.assault then
        self._assault = true
        params.time = self:CalculateAssaultTime()
        self._forced_icons[1].color = Build
        self.update = self.update_assault
    else
        self._forced_icons[1].color = Control
        params.time = params.time or self:CalculateBreakTime() + (2 * math.random())
        self:ComputeHostageDelay()
        self:CheckIfHostageIsPresent()
        if self._t_diff then
            params.time = params.time + self._t_diff
            self._t_diff = nil
        end
    end
    if params.random_time and not params.assault then
        self.old_SyncAnticipationColor = self.SyncAnticipationColor
        self.SyncAnticipationColor = self.SyncAnticipationColorInaccurate
        self._text_color = self._inaccurate_text_color
    end
    EHIAssaultTracker.super.init(self, panel, params)
    self._needs_update = not params.endless_assault
    if params.endless_assault then
        self:SetEndlessAssault(true)
    end
end

function EHIAssaultTracker:post_init(params)
    if self._SHOW_ASSAULT_DIFF then
        local corrected_diff = math.ehi_round_chance(params.diff_visual or managers.ehi_assault._diff or self._diff)
        self._anim_flash_set_chance = 0
        self._chance = corrected_diff
        self._anim_static_chance = corrected_diff
        self:SetBGSize()
        self._chance_text = self:CreateText({
            text = self:FormatChance(corrected_diff),
            left = self._text:right(),
            w = self._bg_box:w() / 2,
            color = Color.white
        })
    elseif self._SHOW_ASSAULT_DIFF_SKIRMISH then
        self._progress = params.assault_number or 0
        self:SetBGSize()
        self._progress_text = self:CreateText({
            text = self:FormatWaveDiff(),
            left = self._text:right(),
            w = self._bg_box:w() / 2,
            color = Color.white,
            FitTheText = true
        })
        managers.ehi_assault:AddAssaultNumberSyncCallback(callback(self, self, "SetProgress"))
    end
    if self._SHOW_AMOUNT_OF_ENEMIES then
        self._anim_flash_set_count = 0
        self._count = managers.enemy:GetNumberOfEnemies()
        self:SetBGSize(self._default_bg_size)
        self._count_text = self:CreateText({
            text = self:FormatCount(),
            left = (self._chance_text or self._progress_text or self._text):right(),
            w = self._default_bg_size,
            color = Color.white,
            FitTheText = true
        })
        EHI:CallCallbackOnce("AssaultTracker_Enemies")
    end
end

if EHIAssaultTracker._SHOW_ASSAULT_DIFF_SKIRMISH then
    function EHIAssaultTracker:SetProgress(progress)
        self._progress = progress
        self._progress_text:set_text(self:FormatWaveDiff())
        self:FitTheText(self._progress_text)
    end

    function EHIAssaultTracker:FormatWaveDiff()
        local wave
        if self._progress <= 0 then
            wave = { damage = 1, health = 1 }
        else
            wave = self._SKIRMISH_WAVE_DATA[math.min(self._progress, managers.job:current_level_wave_count())]
        end
        if wave and wave.damage and wave.health then
            return string.format("%gx|%gx", wave.damage, wave.health)
        elseif wave then
            if wave.damage then
                return string.format("%gx|?x", wave.damage)
            end
            return string.format("?x|%gx", wave.health)
        end
        return "?x|?x"
    end
end

---@param dt number
function EHIAssaultTracker:update_negative(dt)
    self._time = self._time + dt
    self._text:set_text("+" .. self:Format())
end

---@param dt number
function EHIAssaultTracker:update_assault(dt)
    EHIAssaultTracker.super.update(self, dt)
    if self._to_next_state_t then
        self._to_next_state_t = self._to_next_state_t - dt
        if self._to_next_state_t <= 0 then
            if self._next_state == State.sustain then
                self:SetState(State.sustain)
                if self._recalculate_on_sustain then
                    self:RecalculateAssaultTime()
                    self._recalculate_on_sustain = nil
                end
                self._next_state = State.fade
                self._to_next_state_t = self._to_next_state_t + self._next_state_t
            else -- Fade
                self._to_next_state_t = nil
                self:SetState(State.fade)
            end
        end
    end
end

---@param assault_delay_bonus boolean?
function EHIAssaultTracker:AnimateColor(assault_delay_bonus)
    EHIAssaultTracker.super.AnimateColor(self, self._check_anim_progress, (self._assault or assault_delay_bonus) and self._completion_color or self._warning_color)
    self._check_anim_progress = nil
end

---@param diff number
function EHIAssaultTracker:CalculateDifficultyRamp(diff)
    local ramp = tweak_data.group_ai.difficulty_curve_points
    local i = 1
    while (ramp[i] or 1) < diff do
        i = i + 1
    end
    self._diff = diff
    self._difficulty_point_index = i
    self._difficulty_ramp = (diff - (ramp[i - 1] or 0)) / ((ramp[i] or 1) - (ramp[i - 1] or 0))
    if self._chance_text then
        self:SetChancePercent(diff)
    end
end

function EHIAssaultTracker:ComputeHostageDelay()
    if self._PRECOMPUTED_HOSTAGE_DELAY then
        return
    end
    self._HOSTAGE_DELAY = math.lerp(hostage_values[self._difficulty_point_index], hostage_values[self._difficulty_point_index + 1], self._difficulty_ramp) --[[@as number]]
end

function EHIAssaultTracker:SyncAnticipationColorInaccurate()
    self._text_color = Color.white
    self.SyncAnticipationColor = self.old_SyncAnticipationColor
    self.old_SyncAnticipationColor = nil
    self:SyncAnticipationColor()
end

function EHIAssaultTracker:SyncAnticipationColor()
    self:StopAndSetTextColor()
    self:SetState(State.anticipation)
    self._time_warning = nil
    self.update = self.update_break
    self._hostage_delay_disabled = true
end

---@param t number
function EHIAssaultTracker:SyncAnticipation(t)
    self._time = t - (2 * math.random())
    self:SyncAnticipationColor()
end

function EHIAssaultTracker:CheckIfHostageIsPresent()
    self._hostages_count = managers.groupai:state()._hostage_headcount
    if self._hostages_count == 0 then
        self._hostages_found = false
        return
    end
    self:UpdateTime(self._HOSTAGE_DELAY)
    self._hostages_found = true
    if self._ANTICIPATION_DELAY_PER_HOSTAGE then
        self:UpdateTime(self._hostages_count * self._ANTICIPATION_DELAY_PER_HOSTAGE)
    end
end

function EHIAssaultTracker:CalculateBreakTime()
    if self._ASSAULT_DELAY then
        return self._ASSAULT_DELAY + self._ANTICIPATION_DELAY
    end
    local base_delay = math.lerp(tweak_values[self._difficulty_point_index], tweak_values[self._difficulty_point_index + 1], self._difficulty_ramp)
    return base_delay + self._ANTICIPATION_DELAY
end

---@param nr_hostages number
function EHIAssaultTracker:SetHostages(nr_hostages)
    local has_hostages = nr_hostages > 0
    if self._hostage_delay_disabled then
        return
    elseif has_hostages and not self._hostages_found then
        self._hostages_found = true
        self:UpdateTime(self._HOSTAGE_DELAY)
    elseif self._hostages_found and not has_hostages then
        self._hostages_found = false
        self:UpdateTime(-self._HOSTAGE_DELAY)
    end
    if self._ANTICIPATION_DELAY_PER_HOSTAGE then
        local t = math.abs(self._hostages_count - nr_hostages) * self._ANTICIPATION_DELAY_PER_HOSTAGE
        if self._hostages_count > nr_hostages then
            self:UpdateTime(-t)
        elseif self._hostages_count < nr_hostages then
            self:UpdateTime(t)
        end
        self._hostages_count = nr_hostages
    end
end

---@param t number
function EHIAssaultTracker:UpdateTime(t)
    if self._time then
        self._time = self._time + t
        if not self._needs_update then
            self._text:set_text(self:Format())
        end
    else
        self._t_diff = (self._t_diff or 0) + t
    end
end

---@param t number
function EHIAssaultTracker:StartAnticipation(t)
    self:StopAndSetTextColor(Color.yellow)
    self._hostage_delay_disabled = true
    self._time = t
    if self.update == self.update_negative then
        self.update = self.update_break
    end
    if not self._needs_update then
        self:AddTrackerToUpdate()
    end
end

---@param block boolean
---@param t number
function EHIAssaultTracker:SetControlStateBlock(block, t)
    if not self._SHOW_ASSAULT_DELAY then
        return
    elseif block then
        if self._state == State.control and not self._hostage_delay_disabled then
            self:RemoveTrackerFromUpdate()
            self:SetStatusText("break")
            self._control_state_block = true
        end
    elseif self._control_state_block and not block then
        self._control_state_block = nil
        self:SetTimeNoAnim(t)
        self:AddTrackerToUpdate()
    end
end

---@param time number
function EHIAssaultTracker:SetTime(time)
    if self._hostage_delay_disabled or self._assault then
        return
    end
    self._hostages_found = false
    EHIAssaultTracker.super.SetTime(self, time)
    self:CheckIfHostageIsPresent()
end

---@param time number
function EHIAssaultTracker:SetTimeIfLower(time)
    if self._time >= time then
        self:SetTime(time)
    end
end

---@param diff number
function EHIAssaultTracker:UpdateDiff(diff)
    if self._diff == diff then
        return
    end
    self:CalculateDifficultyRamp(diff)
    if self._assault then
        if self._is_client and self._state == State.build then
            self._recalculate_on_sustain = true
        end
    elseif self._hostage_delay_disabled or self._PRECOMPUTED_HOSTAGE_DELAY then
        return
    else
        self:SetHostages(0)
        self:ComputeHostageDelay()
        self:CheckIfHostageIsPresent()
    end
end

---@param diff number
function EHIAssaultTracker:AssaultStart(diff)
    if self._SHOW_ASSAULT_DIFF_SKIRMISH then
        self:IncreaseProgress()
    end
    if self._diff ~= diff then
        self:CalculateDifficultyRamp(diff)
    end
    self:AnimateBG()
    self:StopAndSetTextColor()
    self._time = self:CalculateAssaultTime()
    self._time_warning = nil
    self:SetState(State.build)
    self._assault = true
    self.update = self.update_assault
    if self._CRIME_SPREE then
        self:SetHook()
    end
    if self._control_state_block then
        self._control_state_block = nil
        self:AddTrackerToUpdate()
    end
end

---@param values table
function EHIAssaultTracker:CalculateDifficultyDependentValue(values)
    return math.lerp(values[self._difficulty_point_index], values[self._difficulty_point_index + 1], self._difficulty_ramp) --[[@as number]]
end

---@return number
function EHIAssaultTracker:CalculateAssaultTime()
    local build = assault_values.build_duration
    local sustain = math.lerp(self:CalculateDifficultyDependentValue(assault_values.sustain_duration_min), self:CalculateDifficultyDependentValue(assault_values.sustain_duration_max), math.random()) * managers.groupai:state():_get_balancing_multiplier(assault_values.sustain_duration_balance_mul)
    local fade = assault_values.fade_duration
    self._assault_t = build + sustain
    self._sustain_original_t = sustain
    if self._CRIME_SPREE then
        sustain = self:CalculateCSSustainTime(sustain)
    end
    if self._is_client then
        self._to_next_state_t = build
        self._next_state = State.sustain
        self._next_state_t = sustain
        managers.ehi_assault._internal.sustain_t = self._assault_t
        managers.ehi_assault._internal.sustain_app_t = managers.game_play_central:get_heist_timer()
    else
        self._to_next_state_t = build + sustain
        self._next_state = State.fade
    end
    return build + sustain + fade
end

function EHIAssaultTracker:RecalculateAssaultTime()
    local t = self:CalculateAssaultTime()
    local build = assault_values.build_duration
    local fade = assault_values.fade_duration
    self._assault_t = t - build - fade
    self._to_next_state_t = t - build - fade
    self._time = t - build
end

---@param sustain number
---@param n_of_hostages number?
function EHIAssaultTracker:CalculateCSSustainTime(sustain, n_of_hostages)
    n_of_hostages = n_of_hostages or managers.groupai:state():hostage_count()
    local n_of_jokers = managers.groupai:state():get_amount_enemies_converted_to_criminals()
    local n = math.min(n_of_hostages + n_of_jokers, self._CRIME_SPREE.max_hostages)
    local new_sustain = sustain + self._sustain_original_t * (self._CRIME_SPREE.duration - (self._CRIME_SPREE.deduction * n))
    return new_sustain
end

function EHIAssaultTracker:OnMinionCountChanged()
    if self._state == State.sustain then
        self:UpdateSustainTime(self:CalculateCSSustainTime(self._assault_t))
    end
end

---@param new_sustain number
function EHIAssaultTracker:UpdateSustainTime(new_sustain)
    if new_sustain ~= self._time then
        local time_diff = new_sustain - self._time
        self._to_next_state_t = self._to_next_state_t + time_diff
        self._time = self._time + time_diff
    end
end

---@param t number
---@param sustain_t number?
---@param already_extended boolean?
function EHIAssaultTracker:OnEnterSustain(t, sustain_t, already_extended)
    if self._captain_arrived or self._endless_assault then
        return
    end
    sustain_t = sustain_t or t
    self._to_next_state_t = sustain_t
    self._assault_t = sustain_t
    self._sustain_original_t = t
    self._time = sustain_t + assault_values.fade_duration
    self:SetState(State.sustain)
    self._next_state = State.fade
    if self._CRIME_SPREE and not already_extended then
        self:UpdateSustainTime(self:CalculateCSSustainTime(self._assault_t))
    end
    if self.update == self.update_negative then
        self.update = self.update_assault
    end
end

function EHIAssaultTracker:SetHook()
    self._hook_f = self._hook_f or function(_, data)
        if self._state == State.sustain then
            self:UpdateSustainTime(self:CalculateCSSustainTime(self._assault_t, data.nr_hostages))
        end
    end
    Hooks:PostHook(HUDManager, "set_control_info", "EHI_Assault_set_control_info", self._hook_f)
end

---@param diff number
function EHIAssaultTracker:AssaultEnd(diff)
    if self._diff ~= diff then
        self:CalculateDifficultyRamp(diff)
    end
    self:AnimateBG()
    self:StopAndSetTextColor()
    self._hostage_delay_disabled = nil
    self._assault = nil
    self:SetState(State.control)
    Hooks:RemovePostHook("EHI_Assault_set_control_info")
    if self._SHOW_ASSAULT_DELAY then
        self._time = self:CalculateBreakTime() + (2 * math.random())
        self:ComputeHostageDelay()
        self:CheckIfHostageIsPresent()
        self.update = self.update_break
    else
        self._text:set_text("")
        self._control_state_block = true
        self:RemoveTrackerFromUpdate()
    end
end

---@param diff number
function EHIAssaultTracker:AssaultEndWithBlock(diff)
    self:AssaultEnd(diff)
    self:SetControlStateBlock(true, 0)
end

---@param state number
function EHIAssaultTracker:SetState(state)
    if self._state == state then
        return
    end
    self._state = state
    if state == State.control then
        self:SetIconColor(Control)
    elseif state == State.anticipation then
        self:SetIconColor(Anticipation)
    elseif state == State.build then
        self:SetIconColor(Build)
    elseif state == State.sustain then
        self:SetIconColor(Sustain)
    elseif state == State.fade then
        self:SetIconColor(Fade)
    elseif state == State.endless then
        self:RemoveTrackerFromUpdate()
        self:StopAndSetTextColor(Color.red)
        self:SetIconColor(Color.red)
        self:SetStatusText("endless")
        self._time_warning = nil
        self._assault = true
        self._control_state_block = nil
        self:AnimateBG()
    else
        self:SetIconColor(Captain)
        self._time_warning = nil
        self._endless_assault = nil
    end
end

function EHIAssaultTracker:CaptainArrived()
    self._captain_arrived = true
    self:RemoveTrackerFromUpdate()
    if self._endless_assault then
        self:SetAndFitTheText()
        self:SetTextColor(self._paused_color)
    else
        self:StopAndSetTextColor(self._paused_color)
    end
    self:SetState(State.captain)
end

function EHIAssaultTracker:CaptainDefeated()
    self._captain_arrived = nil
    self._time = 5
    self:SetTextColor()
    self:SetState(State.fade)
    self:AddTrackerToUpdate()
end

---@param state boolean?
---@param new_state_data table?
function EHIAssaultTracker:SetEndlessAssault(state, new_state_data)
    if self._endless_assault == state or self._captain_arrived then
        return
    end
    self._endless_assault = state
    if state then
        self:SetState(State.endless)
    elseif new_state_data then
        if new_state_data.state == "build" then
            local t_correction = new_state_data.t_correction
            self._time = self:CalculateAssaultTime() - t_correction
            self._assault_t = self._assault_t - t_correction
            self._to_next_state_t = self._to_next_state_t - t_correction
            self:SetAndFitTheText()
            self:SetTextColor()
            self:SetState(State.build)
            self:AddTrackerToUpdate()
            self:AnimateBG()
        elseif new_state_data.state == "sustain" then
            self:OnEnterSustain(new_state_data.sustain_original_t, new_state_data.sustain_t, true)
            self:SetAndFitTheText()
            if self._time <= 10 then
                self._check_anim_progress = true
                if self._time > 0 then
                    if self._time > assault_values.fade_duration then
                        self._to_next_state_t = self._time - assault_values.fade_duration
                    else
                        self._to_next_state_t = nil
                        self:SetState(State.fade)
                    end
                else
                    self:StartNegativeUpdate()
                    self:SetState(State.fade)
                end
                self:AnimateColor()
            else
                self:SetTextColor()
            end
            self:AddTrackerToUpdate()
            self:AnimateBG()
        elseif new_state_data.state == "fade" then
            self:CaptainDefeated() -- Faster than retyping it here
            self:SetAndFitTheText()
            self:AnimateBG()
        else
            self:PoliceActivityBlocked() -- Current phase is not an assault phase, refresh at the next Control state
        end
    else
        self:PoliceActivityBlocked() -- Refresh at the next Control state
    end
end

function EHIAssaultTracker:PoliceActivityBlocked()
    self._refresh_on_delete = nil
    self:delete()
end

function EHIAssaultTracker:StartNegativeUpdate()
    self.update = self.update_negative
    self._time = -self._time
end

function EHIAssaultTracker:Refresh()
    self:StartNegativeUpdate()
    if not self._assault then
        self:StopAndSetTextColor()
        self:AnimateColor(true)
    end
end

function EHIAssaultTracker:Hide()
    self:StopPanelAnims()
    self:SetPanelAlpha(0)
    self._parent_class:HideTracker(self._id)
    self:CleanupOnHide()
end

function EHIAssaultTracker:Run(params)
    if params.control_block then
        self:AssaultEndWithBlock(params.diff)
    else
        self:AssaultEnd(params.diff)
        self:AddTrackerToUpdate()
    end
end