---@class EHINeededValueTracker : EHIProgressTracker
---@field super EHIProgressTracker
EHINeededValueTracker = class(EHIProgressTracker)
function EHINeededValueTracker:pre_init(params)
    EHINeededValueTracker.super.pre_init(self, params)
    if params.small_loot_listener then
        managers.ehi_loot:AddSmallLootListener(params.id, function(amount)
            self:IncreaseProgress(amount)
        end)
        self._remove_small_loot_listener = true
    end
    if params.short_format then
        self.FormatNumber = self.FormatNumberShort
        self._cash_sign = managers.localization:text("cash_sign")
    end
    self._progress_formatted = "0"
    self._max_formatted = self:FormatNumber(self._max)
end

function EHINeededValueTracker:OverridePanel()
    self:SetBGSize()
    self._text:set_w(self._bg_box:w())
    self:FitTheText()
end

function EHINeededValueTracker:Format()
    return self._progress_formatted .. "/" .. self._max_formatted
end

---@param n number
function EHINeededValueTracker:FormatNumber(n)
    return managers.experience:cash_string(n)
end

---@param n number
function EHINeededValueTracker:FormatNumberShort(n)
    local divisor = 1
    local post_fix = ""
    if n >= 1000000000 then
        divisor = 1000000000
        post_fix = "B"
    elseif n >= 1000000 then
        divisor = 1000000
        post_fix = "M"
    elseif n >= 1000 then
        divisor = 1000
        post_fix = "K"
    end
    return string.format("%s%s%s", self._cash_sign, tostring(n / divisor), post_fix)
end

function EHINeededValueTracker:SetProgress(progress)
    if self._progress ~= progress and not self._disable_counting then
        self._progress = progress
        self._progress_formatted = self:FormatNumber(progress)
        self:SetAndFitTheText()
        self:AnimateBG()
        if self._progress >= self._max then
            self:SetCompleted()
        end
    end
end

function EHINeededValueTracker:Completed()
    if self._remove_small_loot_listener then
        managers.ehi_loot:RemoveSmallLootListener(self._id)
        self._remove_small_loot_listener = nil
    end
end

function EHINeededValueTracker:RemoveTrackerIfProgressNotMet()
    if self._progress < self._max then
        self:delete()
        return true
    end
end

function EHINeededValueTracker:pre_destroy()
    self:Completed()
end
EHINeededValueTracker.FormatProgress = EHINeededValueTracker.Format