if EHI:CheckLoadHook("SecurityCamera") or not EHI:GetTrackerWaypointHudlistOption("show_camera_loop", "show_waypoints_cameras", "show_camera_loop") or _G.ch_settings then
    return
end

local show_tracker, show_waypoint, show_hudlist = EHI:GetShowTrackerWaypointAndHudlist("show_camera_loop", "show_waypoints_cameras", "show_camera_loop")

local original =
{
    init = SecurityCamera.init,
    _start_tape_loop = SecurityCamera._start_tape_loop,
    _deactivate_tape_loop = SecurityCamera._deactivate_tape_loop,
    destroy = SecurityCamera.destroy
}

function SecurityCamera:init(unit, ...)
    original.init(self, unit, ...)
    self._ehi_key = tostring(unit:key())
end

---@param tape_loop_t number
function SecurityCamera:_start_tape_loop(tape_loop_t, ...)
    original._start_tape_loop(self, tape_loop_t, ...)
    local t = tape_loop_t + 5
    if show_tracker and managers.ehi_tracker:CallFunction2(self._ehi_key, "SetTime", t) then
        managers.ehi_tracker:AddTracker({
            id = self._ehi_key,
            time = t,
            icons = { "camera_loop" },
            hint = "looped_camera",
            remove_on_alarm = true,
            class = EHI.Trackers.Warning
        })
    end
    if show_waypoint and managers.ehi_waypoint:CallFunction2(self._ehi_key, "SetTime", t) then
        managers.ehi_waypoint:AddWaypoint(self._ehi_key, {
            time = t,
            icon = "camera_loop",
            unit = self._unit,
            remove_on_alarm = true,
            class = EHI.Waypoints.Warning
        })
    end
    if show_hudlist then
        managers.ehi_hudlist:CallLeftListItemFunction("Camera", "AddCameraLoop", self._ehi_key, t)
    end
end

function SecurityCamera:_deactivate_tape_loop(...)
    original._deactivate_tape_loop(self, ...)
    managers.ehi_tracking:Remove(self._ehi_key)
    managers.ehi_hudlist:CallLeftListItemFunction("Camera", "RemoveCameraLoop", self._ehi_key)
end

function SecurityCamera:destroy(...)
    managers.ehi_tracking:Remove(self._ehi_key)
    managers.ehi_hudlist:CallLeftListItemFunction("Camera", "RemoveCameraLoop", self._ehi_key)
    original.destroy(self, ...)
end