local EHI = EHI
local Icon = EHI.Icons
local SF = EHI.SpecialFunctions
local TT = EHI.Trackers
local Hints = EHI.Hints
---@type ParseTriggerTable
local triggers = {
    [100915] = { time = 4640/30, id = "CraneMoveGas", icons = { Icon.Winch, Icon.Fire, Icon.Goto }, waypoint = { position_from_element = 100836 }, hint = Hints.des_Crane },
    [100967] = { time = 3660/30, id = "CraneMoveGold", icons = { Icon.Escape }, waypoint_f = function(self, trigger)
        self._waypoints:AddWaypoint(trigger.id, {
            time = trigger.time,
            icon = Icon.Interact,
            position = self._SyncedSFF.dinner_EscapePos or self._mission:GetElementPositionOrDefault(100836)
        })
    end, hint = Hints.Escape },
    -- C4 (Doors)
    [100985] = { time = 5, id = "C4", icons = { Icon.C4 }, hint = Hints.Explosion, waypoint = { position_from_unit = 100831 } },
    -- C4 (GenSec Truck)
    [100830] = { time = 5, id = "C4", icons = { Icon.C4 }, hint = Hints.Explosion, waypoint = { position_from_unit = 100825 } },
    [100961] = { time = 5, id = "C4", icons = { Icon.C4 }, hint = Hints.Explosion, waypoint = { position_from_unit = 100844 } }
}

local ovk_and_up = EHI:IsDifficultyOrAbove(EHI.Difficulties.OVERKILL)
---@type ParseAchievementTable
local achievements =
{
    farm_2 =
    {
        elements =
        {
            [100484] = { time = 300, class = TT.Achievement.Unlock },
            [101881] = { special_function = SF.SetAchievementFailed }
        }
    },
    farm_3 =
    {
        difficulty_pass = ovk_and_up,
        elements =
        {
            [101179] = { class = TT.Achievement.Status },
            [103394] = { special_function = SF.SetAchievementFailed },
            [102880] = { special_function = SF.SetAchievementComplete }
        }
    },
    farm_4 =
    {
        elements =
        {
            [100485] = { time = 30, class = TT.Achievement.Base },
            [102841] = { special_function = SF.SetAchievementComplete }
        }
    }
}

local other =
{
    [101346] = EHI:AddAssaultDelay({ control = 45 })
}
if EHI:GetLoadSniperTrackers(true) then
    other[101179] = { chance = 15, id = "Snipers", class = TT.Sniper.Chance, flash_times = 1 }
    other[101227] = { id = "Snipers", special_function = SF.DecreaseCounter }
    other[101228] = { id = "Snipers", special_function = SF.IncreaseCounter }
    other[101233] = { special_function = EHI.Trigger:RegisterCustomSF(function(self, trigger, element, ...)
        if EHI.IsHost and not element:_values_ok() then
            return
        end
        self._trackers:CallFunction("Snipers", "SnipersKilled")
    end) }
    other[101956] = { id = "Snipers", special_function = SF.IncreaseChanceFromElement } -- +15%
    other[101957] = { special_function = EHI.Trigger:RegisterCustomSF(function(self, trigger, element, ...) ---@param element ElementLogicChanceOperator
        if self._trackers:CallFunction2("Snipers", "SniperSpawnsSuccess", element._values.chance) then -- 0%
            self._trackers:AddTracker({
                id = "Snipers",
                flash_times = 1,
                chance_success = true,
                class = TT.Sniper.Chance
            })
        end
    end) }
end
local CacheEscapePos = EHI.Trigger:RegisterCustomSyncedSF(function(self, trigger, ...)
    self._SyncedSFF.dinner_EscapePos = self._mission:GetElementPosition(EHI:GetInstanceElementID(100034, trigger.index))
end)
for i = 2850, 3050, 100 do
    other[EHI:GetInstanceElementID(100028, i)] = { special_function = CacheEscapePos, index = i }
end
managers.ehi_hudlist:CallRightListItemFunction("Unit", "EnablePersistentSniperItem")

EHI.Mission:ParseTriggers({
    mission = triggers,
    achievement = achievements,
    other = other
})

local max, pig = 8, 0
if ovk_and_up then
    max, pig = 10, 1
    EHI:ShowAchievementLootCounter({
        achievement = "farm_6",
        job_pass = managers.job:current_job_id() == "dinner",
        max = 1,
        show_finish_after_reaching_target = true,
        counter =
        {
            loot_type = "din_pig"
        }
    })
    if EHI:CanShowAchievement("farm_1") then
        managers.ehi_assault:AddAssaultModeChangedCallback(function(mode)
            if mode == "phalanx" then
                managers.ehi_unlockable:AddAchievementStatusTracker("farm_1", "finish")
            else
                managers.ehi_unlockable:SetAchievementFailed("farm_1")
            end
        end)
        EHI:AddCallback(EHI.CallbackMessage.MissionEnd, function(success)
            if success then
                managers.ehi_unlockable:SetAchievementComplete("farm_1")
            end
        end)
    end
end

EHI:ShowLootCounter({ max = max + pig }, { element = 100787 })
EHI.Unit:UpdateUnits({
    -- Drills
    [100035] = { remove_vanilla_waypoint = 103175 },
    [100949] = { remove_vanilla_waypoint = 103174 }
})
local required_bags = EHI:GetValueBasedOnDifficulty({
    normal = 2,
    hard = 4,
    veryhard = 4,
    overkill = 6,
    mayhem_or_above = 8
})
EHI:AddXPBreakdown({
    objectives =
    {
        { amount = 4000, name = "slaughterhouse_entered" },
        { amount = 6000, name = "vault_drill_done" },
        { amount = 4000, name = "slaughterhouse_tires_burn" },
        { amount = 6000, name = "slaughterhouse_trap_lifted" },
        { amount = 6000, name = "slaughterhouse_gold_lifted" },
        { escape = 6000 }
    },
    loot =
    {
        gold = ovk_and_up and 800 or 1000
    },
    total_xp_override =
    {
        params =
        {
            min_max =
            {
                loot =
                {
                    gold = { min = required_bags, max = max }
                }
            }
        }
    }
})