local EHI = EHI
local SF = EHI.SpecialFunctions
local TT = EHI.Trackers

---@type ParseAchievementTable
local achievements = nil
local other = {}
---@param self EHIMissionElementTrigger
local function LootCounterSyncFunction(self)
    local max_reduction = 0
    if self._utils:IsMissionElementDisabled(104285) then
        max_reduction = max_reduction + 1
    end
    if self._utils:IsMissionElementDisabled(104286) then
        max_reduction = max_reduction + 1
    end
    self._loot:DecreaseLootCounterProgressMax(max_reduction)
    self._loot:SyncSecuredLoot()
end
local LootCounterTriggers =
{
    [102860] = EHI:AddCustomCode(function(self)
        self._loot:DecreaseLootCounterProgressMax() -- Painting flushed
    end)
}

local min_bags = 4
if Global.game_settings.level_id == "gallery" then
    achievements =
    {
        cac_19 =
        {
            elements =
            {
                [100789] = { class = TT.Achievement.Status },
                [104288] = { special_function = SF.SetAchievementComplete },
                [104290] = { special_function = SF.SetAchievementFailed }, -- Alarm
                [102860] = { special_function = SF.SetAchievementFailed } -- Painting flushed
            }
        }
    }
    if TheFixes then
        local Preventer = TheFixesPreventer or {}
        if not Preventer.achi_masterpiece then -- Fixed
            achievements.cac_19.cleanup_callback = managers.ehi_unlockable:AddTFCallback("cac_19", "EHI_ArtGallery_TheFixes")
        end
    end

    EHI:ShowLootCounter({
        max = 9,
        triggers = LootCounterTriggers,
        load_sync = LootCounterSyncFunction
    }, { element = 100995 })

    min_bags = 6
else -- Framing Frame Day 1
    EHI:ShowAchievementLootCounter({
        achievement = "pink_panther",
        job_pass = managers.job:current_job_id() == "framing_frame",
        max = 9,
        show_finish_after_reaching_target = true,
        silent_failed_on_alarm = true,
        start_silent = true,
        triggers =
        {
            [100559] = { special_function = SF.CallCustomFunction, f = "SetStarted" },
            [102860] = { special_function = SF.Trigger, data = { 1, 2 } },
            [1] = EHI:AddCustomCode(function(self)
                self._unlockable:SetAchievementFailed("pink_panther") -- Painting flushed
            end),
            [2] = EHI:AddCustomCode(function(self)
                self._trackers:DecreaseProgressMax("pink_panther")
                self._loot:DecreaseLootCounterProgressMax()
            end)
        },
        loot_counter_triggers = LootCounterTriggers,
        load_sync = function(self)
            if self.ConditionFunctions.IsLoud() then
                return
            elseif self._utils:IsMissionElementDisabled(104285) or self._utils:IsMissionElementDisabled(104286) then
                self._trackers:CallFunction("pink_panther", "SetFailed2")
                return
            end
            self._trackers:CallFunction("pink_panther", "SetStarted")
            self._loot:SyncSecuredLootInAchievement("pink_panther")
        end,
        loot_counter_load_sync = LootCounterSyncFunction,
        add_to_counter = true,
        show_loot_counter = true,
        loot_counter_on_fail = true,
        waypoint_loot_counter = { element = 100995 }
    })

    if EHI:IsEscapeChanceEnabled() then
        other[102437] = managers.ehi_escape:IncreaseChanceFromTrigger() -- +5%
        other[103884] = managers.ehi_escape:SetChanceFromTrigger() -- 100%
        other[100905] = managers.ehi_escape:AddTrigger(25, true)
        if EHI.IsClient then
            EHI:AddOnAlarmCallback(function(dropin)
                managers.ehi_escape:AddEscapeChanceTrackerAndCheckPreplanning(dropin, 25, 104159)
            end)
        end
    end
end

if EHI:GetLoadSniperTrackers(true) then
    other[103331] = { id = "Snipers", chance = 10, time = 15, recheck_t = 30, class = TT.Sniper.TimedChanceOnce }
    other[103829] = { id = "Snipers", special_function = SF.CallCustomFunction, f = "SniperSpawnsSuccess", arg = { 2 } }
    other[103828] = { id = "Snipers", special_function = SF.IncreaseChanceFromElement } -- +5%
    other[103785] = { id = "Snipers", special_function = SF.DecreaseCounter }
    other[103761] = { id = "Snipers", special_function = SF.DecreaseCounter }
end
managers.ehi_hudlist:CallRightListItemFunction("Unit", "EnablePersistentSniperItem")

other[100788] = EHI:AddAssaultDelay({ time = 30 + 1 + 20 + 1 }) -- Game forces endless assault and then kills it a second later

EHI.Mission:ParseTriggers({ achievement = achievements, other = other, assault = { wave_mode_elements_block = { 100352, 100353 } } })

EHI:SetMissionDoorData({
    -- Security doors
    [100937] = 103191,
    [100259] = 103188,
    [100233] = 103202
})
local xp_override =
{
    params =
    {
        min_max =
        {
            loot_all = { min = min_bags, max = 9 }
        }
    }
}
EHI:AddXPBreakdown({
    plan =
    {
        stealth =
        {
            objectives =
            {
                { escape = 2000 }
            },
            loot_all = 500,
            total_xp_override = xp_override
        },
        loud =
        {
            objectives =
            {
                { amount = 6000, name = "pc_hack" },
                { escape = 2000, escape_chance = { start_chance = 25, kill_add_chance = 5 } }
            },
            loot_all = 500,
            total_xp_override = xp_override
        }
    }
})
local jobs = deep_clone(tweak_data.achievement.complete_heist_achievements.trophy_framing_frame.jobs)
if _G.ch_settings then
    table.insert(jobs, "framing_frame_prof")
end
if table.contains(jobs, managers.job:current_job_id()) then -- Check if we are playing the Vanilla Framing Frame job
    managers.ehi_loot:AddListener("ehi_ff_saved_bags", function(loot)
        managers.job:set_memory("ehi_ff_saved_bags", loot:GetSecuredBagsAmount())
    end)
    managers.ehi_loot:AddSyncListener(function(loot)
        local amount = loot:GetSecuredBagsAmount()
        if amount > 0 then
            managers.job:set_memory("ehi_ff_saved_bags", amount)
        end
    end)
end