local EHI = EHI
local Icon = EHI.Icons
local SF = EHI.SpecialFunctions
local CF = EHI.ConditionFunctions
local TT = EHI.Trackers
local Hints = EHI.Hints
local element_sync_triggers =
{
    -- Time before the tear gas is removed
    [102074] = { time = 3 + 2, id = "TearGasPEOC", icons = { Icon.Teargas }, special_function = SF.AddTrackerIfDoesNotExist, hook_element = 102073, hint = Hints.Teargas }
}
---@type ParseTriggerTable
local triggers = {
    [102949] = { time = 17, id = "HeliDropWait", icons = { Icon.Wait }, hint = Hints.Wait },

    [102335] = { time = 60, id = "Thermite", icons = { Icon.Fire }, waypoint = { position_from_element = EHI:GetInstanceElementID(100029, 16950) }, hint = Hints.Thermite }, -- units/pd2_dlc_vit/props/security_shutter/vit_prop_branch_security_shutter

    [100246] = { time = 31, id = "TearGasOffice", icons = { Icon.Teargas }, special_function = SF.ReplaceTrackerWithTracker, data = { id = "TearGasOfficeChance" }, hint = Hints.Teargas, waypoint = { position_from_element = 101263 } },

    [102544] = { time = 8.3, id = "HumveeWestWingCrash", icons = { Icon.Car, Icon.Fire }, class = TT.Warning, hint = Hints.hox_1_Car },

    [101504] = { time = 12 + 11, id = "AirlockOpenInside", icons = { Icon.Door }, hint = Hints.Wait },

    [EHI:GetInstanceElementID(100015, 22250)] = { id = "MaxHacks", max = 3, icons = { Icon.PCHack }, show_progress_on_finish = true, class = TT.Timer.Progress, hint = Hints.Hack },
    [EHI:GetInstanceElementID(100017, 22250)] = { id = "MaxHacks", special_function = SF.IncreaseProgress },
    [104055] = { id = "MaxHacks", special_function = SF.RemoveTracker },

    [102095] = { special_function = SF.Trigger, data = { 1020951, 1020952 } },
    [1020951] = { time = 26, id = "AirlockOpenOutside", icons = { Icon.Door }, condition_function = CF.IsStealth, hint = Hints.Wait },
    [1020952] = EHI:AddEndlessAssault(26, "AirlockOpenOutsideEndlessAssault", true),

    [102104] = { time = 30 + 26, id = "LockeHeliEscapeLoud", icons = Icon.HeliEscapeNoLoot, condition_function = CF.IsLoud, waypoint = { data_from_element = 101914 }, hint = Hints.Escape }, -- 30s delay + 26s escape zone delay
    [104036] = { time = 26, id = "LockeHeliEscapeStealth", icons = Icon.HeliEscapeNoLoot, condition_function = CF.IsStealth, waypoint = { data_from_element_and_remove_vanilla_waypoint = 101914, restore_on_done = true }, hint = Hints.Escape }
}
if EHI:IsDifficultyOrAbove(EHI.Difficulties.VeryHard) then
    triggers[101580] = { chance = 20, id = "TearGasOfficeChance", icons = { Icon.Teargas }, class = TT.Chance, hint = Hints.vit_Teargas }
    -- Disabled in the mission script
    --triggers[101394] = { chance = 20, id = "TearGasOfficeChance", icons = { Icon.Teargas }, class = TT.Chance, special_function = SF.SetChanceWhenTrackerExists }, -- It will not run on Hard and below
    triggers[101377] = { amount = 20, id = "TearGasOfficeChance", special_function = SF.IncreaseChance }
    triggers[101393] = { id = "TearGasOfficeChance", special_function = SF.RemoveTracker }
end
if EHI.Mission._SHOW_MISSION_TRACKERS_TYPE.cheaty then
    EHI.Mission:LoadTracker("EHICorrectCablesTracker")
    triggers[101692] = EHI:AddCustomCode(function(self)
        local gate_box = managers.worlddefinition:get_unit(EHI:GetInstanceUnitID(100018, 4550))
        if not gate_box then -- Oh no, something happened and our required unit does not exist; skip
            return
        end
        self._trackers:AddTracker({
            id = "CorrectCables",
            class = "EHICorrectCablesTracker"
        })
        local colors =
        {
            { color = "r", object = "g_light_01" },
            { color = "g", object = "g_light_02" },
            { color = "b", object = "g_light_03" },
            { color = "y", object = "g_light_04" }
        }
        for _, tbl in ipairs(colors) do
            if gate_box:get_object(Idstring(tbl.object)):visibility() then
                self._trackers:CallFunction("CorrectCables", "SetCode", tbl.color)
            end
        end
    end)
    -- 100076 = Wire cut
    -- 100081 = Hack done
    triggers[EHI:GetInstanceElementID(100076, 4150)] = { id = "CorrectCables", special_function = SF.CallCustomFunction, f = "RemoveCode", arg = { "r" } }
    triggers[EHI:GetInstanceElementID(100081, 4150)] = { id = "CorrectCables", special_function = SF.CallCustomFunction, f = "RemoveCode", arg = { "r" } }
    triggers[EHI:GetInstanceElementID(100076, 4250)] = { id = "CorrectCables", special_function = SF.CallCustomFunction, f = "RemoveCode", arg = { "g" } }
    triggers[EHI:GetInstanceElementID(100081, 4250)] = { id = "CorrectCables", special_function = SF.CallCustomFunction, f = "RemoveCode", arg = { "g" } }
    triggers[EHI:GetInstanceElementID(100076, 4350)] = { id = "CorrectCables", special_function = SF.CallCustomFunction, f = "RemoveCode", arg = { "b" } }
    triggers[EHI:GetInstanceElementID(100081, 4350)] = { id = "CorrectCables", special_function = SF.CallCustomFunction, f = "RemoveCode", arg = { "b" } }
    triggers[EHI:GetInstanceElementID(100076, 4450)] = { id = "CorrectCables", special_function = SF.CallCustomFunction, f = "RemoveCode", arg = { "y" } }
    triggers[EHI:GetInstanceElementID(100081, 4450)] = { id = "CorrectCables", special_function = SF.CallCustomFunction, f = "RemoveCode", arg = { "y" } }
end
if EHI.Mission._SHOW_MISSION_TRIGGERS_TYPE.cheaty then
    for _, index in ipairs({ 5100, 5400, 5700, 15450 }) do
        triggers[EHI:GetInstanceElementID(100139, index)] = { id = "SafeCode", class = TT.Code, remove_on_alarm = true, waypoint = { icon = "code", position_from_unit = EHI:GetInstanceUnitID(100004, index) } }
    end
    triggers[EHI:GetInstanceElementID(100230, 12900)] = { id = "SafeCode", special_function = SF.RemoveTracker }
    ---@param self EHIMissionElementTrigger
    ---@param arg number[]
    local function ShowCodePart(self, arg)
        self._tracking:Call("SafeCode", "SetCodePart", arg[1], arg[2], 4)
    end
    local num, pos = 1, 1
    for i = 102622, 102661, 1 do
        triggers[i] = { special_function = SF.CustomCode2, f = ShowCodePart, arg = { pos, num } }
        if num == 9 then
            num = 0
        elseif num == 0 then
            num = num + 1
            pos = pos + 1
        else
            num = num + 1
        end
    end
end
if EHI.IsClient then
    triggers[102073] = { additional_time = 30 + 3 + 2, random_time = 10, id = "TearGasPEOC", icons = { Icon.Teargas }, special_function = SF.AddTrackerIfDoesNotExist, hint = Hints.Teargas }
    triggers[103500] = EHI:ClientCopyTrigger(triggers[102104], { time = 26 })
end

---@param self EHIMissionElementTrigger
---@param disable boolean
local function ToggleAssaultTracker(self, disable)
    if disable == false and self.ConditionFunctions.IsStealth() then
        return
    end
    self._assault:SetControlStateBlock(disable, 30)
end
local other =
{
    [100109] = EHI:AddAssaultDelay({ control = 30 }),
    [103357] = { special_function = SF.CustomCode2, f = ToggleAssaultTracker, arg = true }, -- Inside an airlock
    [103087] = { special_function = SF.CustomCode2, f = ToggleAssaultTracker, arg = false }, -- Enabled preferreds after looking at the vault
    [103130] = { special_function = SF.CustomCode2, f = ToggleAssaultTracker, arg = true }, -- Left PEOC
    [104056] = EHI:AddCustomCode(function(self)
        managers.ehi_hudlist:CallRightListItemFunction("Unit", "uno")
    end)
}
if EHI:GetLoadSniperTrackers() then
    local sniper_count = EHI:GetValueBasedOnDifficulty({
        veryhard_or_below = 1,
        overkill_or_above = 2
    })
    other[100314] = { special_function = EHI.Trigger:RegisterCustomSF(function(self, trigger, element, ...)
        if EHI.IsHost and element:counter_value() ~= 0 then
            return
        end
        local t = 20 + 10 + 25
        self._trackers:AddTracker({
            id = "Snipers",
            chance = 10,
            time = t,
            on_fail_refresh_t = 25,
            on_success_refresh_t = t,
            sniper_count = trigger.sniper_count,
            single_sniper = trigger.sniper_count == 1,
            class = TT.Sniper.Loop
        })
    end), sniper_count = sniper_count }
    other[100533] = { id = "Snipers", special_function = SF.CallCustomFunction, f = "OnChanceFail" }
    other[100363] = { id = "Snipers", special_function = SF.CallCustomFunction, f = "OnChanceSuccess" }
    other[100537] = { id = "Snipers", special_function = SF.IncreaseChanceFromElement } -- +5%
    other[100565] = { id = "Snipers", special_function = SF.SetChanceFromElement } -- 10%
    other[100574] = { id = "Snipers", special_function = SF.IncreaseChanceFromElement } -- +15%
    other[101324] = { id = "Snipers", special_function = SF.CallCustomFunction, f = "RequestRemoval" }
    -- Enemies killed via "ElementAIRemove" DOES NOT TRIGGER ElementEnemyDummyTrigger if "force_ragdoll" and "true_death" are set to "false" and "use_instigator" is set to "true"
    other[102596] = { id = "Snipers", special_function = SF.RemoveTracker }
end
other[102083] = EHI.TrackerUtils.Deployables:AddDeployablesIgnoreCheck({
    shapes = { 103128 },
    element_area_id = 103128 -- ´peoc_kill_area´ ElementAreaTrigger 103128
})
EHI.Unit:UpdateUnits({
    [EHI:GetInstanceUnitID(100058, 22250)] = { tracker_merge_id = "MaxHacks" },
    [EHI:GetInstanceUnitID(100191, 22250)] = { tracker_merge_id = "MaxHacks" },
    [EHI:GetInstanceUnitID(100192, 22250)] = { tracker_merge_id = "MaxHacks", destroy_tracker_merge_on_done = true }
})
managers.ehi_hudlist:CallRightListItemFunction("Unit", "EnablePersistentSniperItem")
if EHI:GetHudlistAndListOption("right_list", "show_units") and EHI:IsDifficultyOrAbove(EHI.Difficulties.Hard) then -- Normal diff has active turret element, but it is never called
    other[102092] = EHI:AddCustomCode(function(self)
        for _, turret in ipairs({ 103911, 103912 }) do
            local unit = managers.worlddefinition:get_unit(turret)
            local base = unit and unit:base() --[[@as AnimatedVehicleBase?]]
            if base and base._modules and base._modules.turret1 then
                managers.ehi_hudlist:CallRightListItemFunction("Unit", "EnemyTurretDespawned")
            end
        end
    end)
    other[102092].load_sync = function(self) ---@param self EHIMissionElementTrigger
        if managers.groupai:state()._hunt_mode then
            self:Trigger()
        end
    end
end

EHI.Mission:ParseTriggers({
    mission = triggers,
    other = other,
    pre_parse = { filter_out_not_loaded_trackers = "show_timers" },
    sync_triggers = { element = element_sync_triggers }
})

local stealth_objectives =
{
    { amount = 1000, name = "twh_entered" },
    { amount = 2000, name = "twh_wireboxes_cut" },
    { amount = 2000, name = "twh_enter_west_wing" },
    { amount = 2000, name = "twh_enter_oval_office" },
    { amount = 8000, name = "twh_safe_open" },
    { amount = 4000, name = "twh_access_peoc" },
    { amount = 8000, name = "twh_mainframe_hacked" },
    { amount = 2000, name = "twh_pardons_stolen" },
    { amount = 2000, name = "twh_left_peoc" },
    { amount = 2000, name = "heli_arrival" },
    { escape_ghost_bonus_only = tweak_data.levels:GetLevelStealthBonus() }
}
local loud_objectives =
{
    { amount = 1000, name = "twh_entered" },
    { amount = 4000, name = "twh_wireboxes_hacked" },
    { amount = 2000, name = "twh_enter_west_wing" },
    { amount = 2000, name = "twh_found_thermite" },
    { amount = 1000, name = "thermite_done" },
    { amount = 2000, name = "twh_enter_oval_office" },
    { amount = 8000, name = "twh_safe_open" },
    { amount = 4000, name = "twh_access_peoc" },
    { amount = 8000, name = "twh_mainframe_hacked" },
    { amount = 2000, name = "twh_pardons_stolen" },
    { amount = 2000, name = "twh_left_peoc" },
    { amount = 4000, name = "twh_disable_aa" },
    { amount = 2000, name = "heli_arrival" }
}
local xp_breakdown = {}
if EHI:IsDifficultyOrAbove(EHI.Difficulties.OVERKILL) and managers.custom_safehouse:uno_achievement_challenge():challenge_completed() then
    local secret_objectives =
    {
        stop_at_inclusive = "twh_pardons_stolen",
        mark_optional = { twh_mainframe_hacked = true, twh_pardons_stolen = true }
    }
    xp_breakdown.plan = {
        custom =
        {
            {
                name = "stealth",
                plan =
                {
                    objectives = stealth_objectives
                }
            },
            {
                name = "stealth",
                additional_name = "twh_secret",
                plan =
                {
                    objectives = deep_clone(stealth_objectives),
                    total_xp_override = { params = { min_max = {} } }
                },
                objectives_override = secret_objectives
            },
            {
                name = "loud",
                plan =
                {
                    objectives = loud_objectives,
                }
            },
            {
                name = "loud",
                additional_name = "twh_secret",
                plan =
                {
                    objectives = deep_clone(loud_objectives),
                    total_xp_override = { params = { min_max = {} } }
                },
                objectives_override = secret_objectives
            }
        }
    }
else
    xp_breakdown.plan = {
        stealth =
        {
            objectives = stealth_objectives
        },
        loud =
        {
            objectives = loud_objectives
        }
    }
end
EHI:AddXPBreakdown(xp_breakdown)