local EHI = EHI
local Icon = EHI.Icons
local SF = EHI.SpecialFunctions
local TT = EHI.Trackers
local Hints = EHI.Hints
local Status = EHI.Const.Trackers.Achievement.Status
local triggers = {}
---@type ParseAchievementTable
local achievements = {}
local other = {}
local escape_chance
local EscapeXP = 16000
if Global.game_settings.level_id == "firestarter_3" then
    triggers[102144] = { time = 90, id = "MoneyBurn", icons = { Icon.Fire }, hint = Hints.Fire, waypoint = { data_from_element = 104465 } }
    achievements.slakt_5 =
    {
        difficulty_pass = EHI:IsDifficultyOrAbove(EHI.Difficulties.DeathWish),
        elements =
        {
            [102144] = { class = TT.Achievement.Status },
            [102146] = { status = Status.Finish, special_function = SF.SetAchievementStatus },
            [105237] = { special_function = SF.SetAchievementComplete },
            [105235] = { special_function = SF.SetAchievementFailed }
        }
    }
else
    -- Branchbank: Random, Branchbank: Gold, Branchbank: Cash, Branchbank: Deposit
    tweak_data.ehi.functions.achievements.uno_1()
    EscapeXP = 12000
    escape_chance =
    {
        start_chance = (managers.mission:check_mission_filter(2) or managers.mission:check_mission_filter(3)) and 15 or 5, -- Cash or Gold starts at 15% (10% + 5%), others at 5%
        kill_add_chance = 5
    }
    if EHI:IsEscapeChanceEnabled() then
        other[103306] = managers.ehi_escape:IncreaseChanceFromTrigger() -- +5%
        EHI:AddOnAlarmCallback(function(dropin)
            managers.ehi_escape:AddEscapeChanceTrackerAndCheckPreplanning(dropin, escape_chance.start_chance, 104825)
        end)
    end
    triggers[104637] = EHI:AddCustomCode(function(self)
        self._trackers:AddTracker({
            id = "ObjectiveSteal",
            max = 25000,
            icons = { Icon.Escape },
            flash_times = 1,
            hint = "loot_escape",
            class = self.Trackers.NeededValue
        })
        self._loot:AddListener("branchbank_deposit", function(loot)
            local progress = loot:get_real_total_small_loot_value()
            self._trackers:SetProgress("ObjectiveSteal", progress)
            if progress >= 25000 then
                self._loot:RemoveListener("branchbank_deposit")
            end
        end)
    end)
    triggers[105426] = EHI:AddCustomCode(function(self)
        if self._trackers:ReturnValue("ObjectiveSteal", "RemoveTrackerIfProgressNotMet") then
            self._loot:RemoveListener("branchbank_deposit")
        end
    end)
end
triggers[101425] = { time = 24 + 7, id = "TeargasIncoming1", icons = { Icon.Teargas, Icon.ExclamationMark }, class = TT.Warning, hint = Hints.Teargas }
triggers[105611] = { time = 24 + 7, id = "TeargasIncoming2", icons = { Icon.Teargas, Icon.ExclamationMark }, class = TT.Warning, hint = Hints.Teargas }
triggers[104736] = EHI:AddIncomingTurret(616/30, Vector3(-420.226, -1011.89, 225.056), "SWATTurretArrival2", true, _G.ch_settings == nil)
triggers[104737] = EHI:AddIncomingTurret(752/30, Vector3(805.013, 2253.48, 224.916), "SWATTurretArrival1", true, _G.ch_settings == nil)

achievements.voff_1 =
{
    difficulty_pass = EHI:IsDifficultyOrAbove(EHI.Difficulties.OVERKILL),
    elements =
    {
        [105665] = { status = Status.Move, class = TT.Achievement.Status },
        [105686] = { special_function = SF.SetAchievementComplete },
        [105691] = { status = Status.Finish, special_function = SF.SetAchievementStatus }, -- Entered area again
        [105694] = { status = Status.Finish, special_function = SF.SetAchievementStatus }, -- Both secured
        [105698] = { status = Status.Move, special_function = SF.SetAchievementStatus }, -- Left the area
        [105704] = { special_function = SF.SetAchievementFailed } -- Killed
    }
}
tweak_data.ehi.functions.achievements.eng_X("eng_1") -- "The only one that is true" achievement

other[105364] = EHI:AddAssaultDelay({ control = 10 + 60, special_function = SF.AddTimeByPreplanning, data = { id = 104875, yes = 30, no = 15 } })
if EHI:GetLoadSniperTrackers() then
    other[100438] = { chance = 10, time = 30 + 60, id = "Snipers", class = TT.Sniper.Loop, single_sniper = true, special_function = SF.Snipers_CheckIfTrackerExists }
    other[105327] = { id = "Snipers", special_function = SF.IncreaseChanceFromElement } -- +15%
    other[101481] = { id = "Snipers", special_function = EHI.Trigger:RegisterCustomSF(function(self, trigger, element, ...) ---@param element ElementLogicChanceOperator
        local id = trigger.id
        self._trackers:SetChance(id, element._values.chance) -- 20%
        self._trackers:SetTimeNoAnim(id, 60)
        self._trackers:CallFunction(id, "AnnounceSniperSpawn")
    end)}
    other[101446] = { special_function = SF.CallTrackerManagerFunction, f = "SetTimeNoAnim", arg = { "Snipers", 60 } }
    if EHI.IsClient then
        EHI.Trigger:AddLoadSyncFunction(function(self)
            if managers.groupai:state():whisper_mode() then
                return
            end
            self._trackers:AddTracker({
                id = "Snipers",
                count = EHISniperBase._alive_count,
                from_sync = true,
                single_sniper = true,
                class = TT.Sniper.Loop
            })
        end)
    end
end
if EHI:IsLootCounterVisible() then
    local deposit_boxes = {
        104218, 104188, 103939, 100663, 101241, 104247, 104219, 104217, 104189, 104187,
        103940, 101390, 100664, 104261, 101247, 104244, 104220, 104214, 104190, 104184,
        103986, 101388, 101094, 104256, 101252, 104245, 104222, 104215, 104192, 104185,
        103988, 101389, 101240, 104251, 101257, 104243, 104223, 104213, 104193, 104183,
        104036, 101263, 101242, 104246, 101262, 104242, 104224, 104212, 104194, 104182,
        104038, 101261, 101243, 104241, 104146, 104240, 104225, 104210, 104195, 104180,
        104086, 101260, 101244, 104236, 104176, 104239, 104227, 104209, 104197, 104179,
        104088, 101259, 101245, 104231, 104181, 104238, 104228, 104208, 104198, 104178,
        104136, 101258, 101248, 104226, 104186, 104237, 104229, 104207, 104199, 104177,
        104138, 101256, 101249, 104221, 104191, 104235, 104230, 104205, 104200, 104175,
        104147, 101255, 101250, 104216, 104196, 104234, 104232, 104204, 104202, 104150,
        104148, 101254, 101251, 104211, 104201, 104233, 104203, 104149, 101253, 104206
    }
    -- Standalone branchbank level uses the same level id `branchbank`. There is no way to distinguish between them if played from custom heists, only the mission filter differs  
    -- In Vanilla, the job id will be different
    local has_random_bags = Global.game_settings.level_id ~= "firestarter_3" and not managers.mission:check_mission_filter(1)
    other[105762] = EHI:AddLootCounter2(function()
        EHI:ShowLootCounterNoChecks({
            max = tweak_data.ehi.functions.GetNumberOfDepositBoxesWithLoot2(deposit_boxes),
            unknown_random = has_random_bags
        })
    end, { element = { 101060, 100510, 101065 } })
    other[101129] = EHI:AddCustomCode(function(self)
        if not self._loot:IsMasterActive() then
            self:RunTrigger(105762) --- You had your last chance here, son.
        end
    end)
    other[103372] = EHI:AddCustomCode(function(self) -- Money
        self._loot:SetUnknownRandomLoot()
    end)
    other[104647] = other[103372] -- Gold
    other[104651] = other[103372] -- Deposit
    if has_random_bags then
        local LootVisible = EHI:AddCustomCode(function(self)
            self._loot:IncreaseLootCounterProgressMax()
        end)
        for i = 104543, 104553, 1 do
            other[i] = LootVisible
        end
        other[104577] = LootVisible
        other[104578] = LootVisible
        other[104579] = LootVisible
        other[104594] = LootVisible
    end
end
managers.ehi_hudlist:CallRightListItemFunction("Unit", "EnablePersistentSniperItem")

EHI.Mission:ParseTriggers({
    mission = triggers,
    achievement = achievements,
    other = other,
    assault =
    {
        diff_load_sync = function(self, assault_number, in_assault)
            if self.ConditionFunctions.IsStealth() then
                return
            elseif assault_number <= 0 or (assault_number == 1 and in_assault) then
                self._assault:SetDiff(0.5)
            elseif assault_number <= 2 or (assault_number == 3 and in_assault) then
                self._assault:SetDiff(0.75)
            else
                self._assault:SetDiff(1)
            end
        end
    }
})

EHI.Unit:UpdateUnits({
    --units/payday2/equipment/gen_interactable_lance_large/gen_interactable_lance_large
    [104674] = { remove_vanilla_waypoint = 102633 },
    [104466] = { remove_vanilla_waypoint = 102752 }
})
EHI:AddXPBreakdown({
    objective =
    {
        escape =
        {
            { amount = EscapeXP, stealth = true },
            { amount = EscapeXP, loud = true, escape_chance = escape_chance }
        }
    },
    loot_all = 500,
    total_xp_override =
    {
        params =
        {
            min_max =
            {
                loot_all = {
                    min = Global.game_settings.level_id ~= "firestarter_3" and not managers.mission:check_mission_filter(1) and 1 or 0,
                    max = 5 + (EscapeXP == 12000 and 8 or 0)
                },
                bonus_xp = { min_max = EscapeXP }
            }
        }
    }
})

if not EHI:CanShowAchievement("voff_1") then
    return
end
local dog_haters =
{
    [Idstring("units/payday2/characters/civ_male_dog_abuser_1/civ_male_dog_abuser_1"):key()] = true,
    [Idstring("units/payday2/characters/civ_male_dog_abuser_2/civ_male_dog_abuser_2"):key()] = true
}
EHI.Trigger:AddLoadSyncFunction(function(self)
    local dog_haters_unit = {} ---@type UnitCivilian[]
    local count = 0
    for _, data in pairs(managers.enemy:all_civilians()) do
        local unit = data.unit
        local name_key = unit:name():key()
        if dog_haters[name_key] then
            count = count + 1
            dog_haters_unit[count] = unit
            dog_haters[name_key] = nil
        end
        if count == 2 then
            break
        end
    end
    dog_haters = nil
    if count ~= 2 then
        return
    end
    -- Exit areas share the same space
    local secure_area_1 = managers.mission:get_element_by_id(105674) --[[@as ElementAreaTrigger?]] -- ´dog_abuse_trigger_enter_001´ ElementAreaTrigger 105674
    local secure_area_2 = managers.mission:get_element_by_id(105678) --[[@as ElementAreaTrigger?]] -- ´dog_abuse_trigger_enter_002´ ElementAreaTrigger 105678
    local secure_area_3 = managers.mission:get_element_by_id(105679) --[[@as ElementAreaTrigger?]] -- ´dog_abuse_trigger_enter_003´ ElementAreaTrigger 105679
    if not (secure_area_1 and secure_area_2 and secure_area_3) then
        return
    end
    local trigger_notification = true
    local function fail(...)
        if trigger_notification then
            managers.ehi_unlockable:SetAchievementFailed("voff_1")
        end
    end
    EHI:AddEndGameCallback(function()
        trigger_notification = false
    end)
    for _, dog_hater in ipairs(dog_haters_unit) do
        dog_hater:base():add_destroy_listener("EHIDestroy", fail)
    end
    self:RunTrigger(105665)
    local pos_1 = dog_haters_unit[1]:position()
    local pos_2 = dog_haters_unit[2]:position()
    if (secure_area_1:_is_inside(pos_1) and secure_area_1:_is_inside(pos_2)) or
        (secure_area_2:_is_inside(pos_1) and secure_area_2:_is_inside(pos_2)) or
        (secure_area_3:_is_inside(pos_1) and secure_area_3:_is_inside(pos_2)) then
        self._unlockable:SetAchievementStatus("voff_1", "finish")
    end
end)
EHI:AddOnSpawnedCallback(function()
    if EHI:IsPlayingFromStart() then
        local trigger_notification = true
        local function fail(...)
            if trigger_notification then
                managers.ehi_unlockable:SetAchievementFailed("voff_1")
            end
        end
        EHI:AddEndGameCallback(function()
            trigger_notification = false
        end)
        local count = 0
        for _, data in pairs(managers.enemy:all_civilians()) do
            local unit = data.unit
            local name_key = unit:name():key()
            if dog_haters[name_key] then
                unit:base():add_destroy_listener("EHIDestroy", fail)
                count = count + 1
                if count == 2 then
                    break
                end
            end
        end
        dog_haters = nil
        if count ~= 2 or EHI.IsHost or managers.ehi_tracker:Exists("voff_1") then
            return
        end
        EHI.Trigger:RunTrigger(105665)
    end
end)