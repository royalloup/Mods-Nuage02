local EHI = EHI
local SF = EHI.SpecialFunctions
---@type ParseAchievementTable
local achievements =
{
    bilbo_baggin =
    {
        elements =
        {
            [104263] = { special_function = SF.CustomCode2, f = function(self)
                self._cache.bilbo_baggin_bags = (self._cache.bilbo_baggin_bags or 0) + 1
                if self._cache.bilbo_baggin_bags == 8 then
                    self._unlockable:AddAchievementProgressTracker("bilbo_baggin", 8, 0, true)
                    self._loot:AddAchievementListener({ achievement = "bilbo_baggin" }, 8)
                end
            end }
        }
    }
}

local other = {}
if EHI.TrackerUtils:IsLootCounterVisible({ element = { 101999, 102000, 101442 } }) then
    other[104263] = EHI:AddLootCounter4(function(self, ...)
        if not self._cache.CreateCounter then
            EHI:ShowLootCounterNoChecks({})
            self._cache.CreateCounter = true
        end
        self._loot:IncreaseLootCounterProgressMax()
    end, { element = { 101999, 102000, 101442 } })
end

managers.ehi_hudlist:CallRightListItemFunction("Unit", "EnablePersistentSniperItem")
tweak_data.ehi.functions.achievements.armored_4()
EHI.Mission:ParseTriggers({
    achievement = achievements,
    other = other
})
EHI:AddXPBreakdown({
    objective =
    {
        escape = 4000
    },
    no_total_xp = true
})