local EHI = EHI
local Icon = EHI.Icons
local SF = EHI.SpecialFunctions
local TT = EHI.Trackers
local Hints = EHI.Hints
local triggers = {
    [101176] = { time = 67 + 400/30, id = "WinchInteract", icons = { Icon.Heli, Icon.Winch }, hint = Hints.Winch, waypoint = { icon = Icon.Winch, position_from_element = 106868 } },
    [106390] = { time = 6 + 30 + 25 + 15 + 2.5, id = "C4", icons = Icon.HeliDropC4, hint = Hints.C4Delivery, waypoint = { icon = Icon.C4, position_from_element = 100715 } },
    -- 6s delay before Bile speaks
    -- 30s delay before random logic
    -- 25s delay to execute random logic
    -- Random logic has defined 2 heli fly ins
    -- First is shorter (6.5 + 76/30) 76/30 => 2.533333 (rounded to 2.5 in Mission Script)
    -- Second is longer (15 + 76/30)
    -- Second animation is counted in this trigger, the first is in trigger 100578.
    -- If the first fly-in is selected, the tracker is updated to reflect that

    [101310] = { time = 10, id = "SantaTalk", icons = { "pd2_talk" }, hint = Hints.Wait, waypoint = { position_from_element = EHI:GetInstanceElementID(100034, 7200) } },
    [100159] = { time = 5 + 7 + 7.3, id = "Escape", icons = { Icon.Escape }, special_function = SF.ExecuteIfElementIsEnabled, hint = Hints.Escape, waypoint = { data_from_element = 106868 } },

    [100578] = { time = 9, id = "C4", icons = { Icon.Heli, Icon.C4, Icon.Goto }, special_function = SF.SetTimeOrCreateTracker, hint = Hints.C4Delivery, waypoint = { icon = Icon.C4, position_from_element = 100715 } }
}

---@type ParseAchievementTable
local achievements =
{
    moon_4 =
    {
        elements =
        {
            [100107] = { max = 2, class = TT.Achievement.Progress, trigger_once = true },
            [104219] = { special_function = SF.IncreaseProgress }, -- Chains
            [104220] = { special_function = SF.IncreaseProgress } -- Dallas
        }
    }
}

local other =
{
    [100109] = EHI:AddAssaultDelay({ control = 45 })
}
if EHI:GetLoadSniperTrackers() then
    local sniper_count = EHI:GetValueBasedOnDifficulty({
        veryhard_or_below = 1,
        overkill_or_above = 2
    })
    other[100015] = { time = 1 + 10 + 35, on_fail_refresh_t = 35, on_success_refresh_t = 20 + 10 + 35, id = "Snipers", class = TT.Sniper.Loop, trigger_once = true, single_sniper = sniper_count == 1, sniper_count = sniper_count, special_function = SF.Snipers_CheckIfTrackerExists }
    other[100574] = { id = "Snipers", special_function = SF.IncreaseChanceFromElement } -- +15%
    other[100537] = { id = "Snipers", special_function = SF.IncreaseChanceFromElement } -- +5%
    other[100565] = { id = "Snipers", special_function = SF.SetChanceFromElement } -- 10%
    other[100363] = { id = "Snipers", special_function = SF.CallCustomFunction, f = "OnChanceSuccess" }
    other[100533] = { id = "Snipers", special_function = SF.CallCustomFunction, f = "OnChanceFail" }
    if EHI.IsClient then
        EHI.Trigger:AddLoadSyncFunction(function(self)
            self._trackers:AddTracker({
                id = "Snipers",
                count = EHISniperBase._alive_count,
                from_sync = true,
                single_sniper = sniper_count == 1,
                sniper_count = sniper_count,
                on_fail_refresh_t = 35,
                on_success_refresh_t = 20 + 10 + 35,
                class = TT.Sniper.Loop
            })
        end)
    end
end
managers.ehi_hudlist:CallRightListItemFunction("Unit", "EnablePersistentSniperItem")

EHI.Mission:ParseTriggers({
    mission = triggers,
    achievement = achievements,
    other = other
})
EHI.Waypoint:DisableTimerWaypoints({
    -- Drill WP in the tech store
    [100241] = true,

    -- Fix Jewelry Store PC hack WP
    [100828] = true,

    -- Drill WP in the cage (shoe objective)
    [100664] = true
})
EHI:ShowAchievementLootCounter({
    achievement = "moon_5",
    job_pass = managers.job:current_job_id() == "moon",
    max = 9,
    counter =
    {
        loot_type = { "money", "diamonds" }
    },
    difficulty_pass = EHI:IsDifficultyOrAbove(EHI.Difficulties.OVERKILL)
})
EHI:ShowLootCounter({ max = 12 }, { element = 101120 })

EHI.Unit:UpdateUnits({
    --units/payday2/equipment/gen_interactable_hack_computer/gen_interactable_hack_computer_b
    --Jewelry Store
    [105874] = { remove_vanilla_waypoint = 100776 }
})
EHI:AddXPBreakdown({
    objectives =
    {
        {
            random =
            {
                max = 3,
                shoe_storage =
                {
                    { amount = 1000, name = "shoe_storage_enter" },
                    { amount = 500, name = "shoe_collected" }
                },
                shoe_backroom =
                {
                    { amount = 4000, name = "shoe_backroom_enter" },
                    { amount = 500, name = "shoe_collected" }
                },
                jewelry =
                {
                    { amount = 1500, name = "pc_hack" },
                    { amount = 500, name = "necklace_collected" }
                },
                toy =
                {
                    { amount = 4000, name = "toy_found" },
                    { amount = 800, name = "toy_collected" }
                },
                vr =
                {
                    { amount = 6000, name = "vault_drill_done" },
                    { amount = 500, name = "vr_collected" }
                },
                wine =
                {
                    { amount = 800, name = "wine_collected" }
                }
            }
        },
        { amount = 500, name = "flare" },
        { amount = 1000, name = "c4_drop" },
        { amount = 1000, name = "c4_set_up" },
        { amount = 1000, name = "heli_arrival" },
        { amount = 500, name = "wires_attached" }
    },
    loot =
    {
        money = 1000,
        diamonds = 1000
    },
    total_xp_override =
    {
        params =
        {
            min_max =
            {
                objectives =
                {
                    random =
                    {
                        min =
                        {
                            shoe_storage = true,
                            jewelry = true,
                            wine = true
                        },
                        max =
                        {
                            shoe_backroom = true,
                            toy = true,
                            vr = true
                        }
                    }
                },
                loot =
                {
                    money = { max = 3 },
                    diamonds = { max = 6 }
                }
            }
        }
    }
})