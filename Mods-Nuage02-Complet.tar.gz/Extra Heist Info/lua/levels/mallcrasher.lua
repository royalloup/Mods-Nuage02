local EHI = EHI
local Icon = EHI.Icons
local SF = EHI.SpecialFunctions
local TT = EHI.Trackers
local Hints = EHI.Hints
local MoneyTrigger = { id = "MallDestruction", special_function = EHI.Trigger:RegisterCustomSF(function(self, trigger, element, ...)
    self._trackers:IncreaseProgress(trigger.id, element._values.amount)
end) }
local OverkillOrBelow = EHI:IsDifficultyOrBelow(EHI.Difficulties.OVERKILL)
local triggers =
{
    -- Time before escape vehicle arrives
    [300248] = { time = (OverkillOrBelow and 120 or 300) + 25, id = "EscapeHeli", icons = Icon.HeliEscapeNoLoot, waypoint = { data_from_element = 300322 }, hint = Hints.Escape },
    -- 120: Base Delay on OVK or below
    -- 300: Base Delay on Mayhem or above
    -- 25: Escape zone activation delay

    [300043] = { max = 50000, id = "MallDestruction", class = TT.NeededValue, icons = { Icon.Destruction }, flash_times = 1, hint = Hints.mallcrasher_Destruction },
    [300843] = MoneyTrigger, -- +40
    [300844] = MoneyTrigger, -- +80
    [300845] = MoneyTrigger, -- +250
    [300846] = MoneyTrigger, -- +500
    [300847] = MoneyTrigger, -- +800
    [300848] = MoneyTrigger, -- +2000
    [300850] = MoneyTrigger, -- +2800
    [300849] = MoneyTrigger, -- +4000
    [300872] = MoneyTrigger, -- +5600
    [300851] = MoneyTrigger -- +8000, appears to be unused
}

if EHI.IsClient then
    triggers[302287] = EHI:ClientCopyTrigger(triggers[300248], { time = (OverkillOrBelow and 115 or 120) + 25 })
    triggers[300223] = EHI:ClientCopyTrigger(triggers[300248], { time = 60 + 25 })
    triggers[302289] = EHI:ClientCopyTrigger(triggers[300248], { time = 30 + 25 })
    triggers[300246] = EHI:ClientCopyTrigger(triggers[300248], { time = 25 })
end

---@type ParseAchievementTable
local achievements =
{
    window_cleaner =
    {
        elements =
        {
            [301056] = { max = 171, flash_times = 1, class = TT.Achievement.Progress },
            [300791] = { special_function = SF.IncreaseProgress }
        }
    },
    ameno_3 =
    {
        difficulty_pass = EHI:IsDifficulty(EHI.Difficulties.OVERKILL),
        elements =
        {
            [301148] = { time = 50, class = "EHIameno_3Tracker" },
        },
        load_sync = function(self)
            local t = 50 - math.max(self._trackers._t, self._tracking._t)
            local progress = managers.loot:get_real_total_small_loot_value()
            if t > 0 and progress < 1800000 then
                self._trackers:AddTracker({
                    time = t,
                    id = "ameno_3",
                    progress = progress,
                    icons = EHI:GetAchievementIcon("ameno_3"),
                    class = "EHIameno_3Tracker"
                })
            end
        end,
        parsed_callback = function()
            ---@class EHIameno_3Tracker : EHIAchievementTracker, EHINeededValueTracker
            ---@field super EHIAchievementTracker
            EHIameno_3Tracker = class(EHIAchievementTracker)
            EHIameno_3Tracker.FormatNumber = EHINeededValueTracker.Format
            EHIameno_3Tracker.FormatNumber2 = EHINeededValueTracker.FormatNumberShort
            EHIameno_3Tracker.IncreaseProgress = EHIProgressTracker.IncreaseProgress
            EHIameno_3Tracker.Completed = EHINeededValueTracker.Completed
            ---@param class EHIameno_3Tracker
            EHIameno_3Tracker._anim_warning = function(o, old_color, color, start_t, class)
                local c = Color(old_color.r, old_color.g, old_color.b)
                local money = class._money_text
                while true do
                    local t = 1
                    while t > 0 do
                        t = t - coroutine.yield()
                        local n = math.sin(t * 180)
                        c.r = math.lerp(old_color.r, color.r, n)
                        c.g = math.lerp(old_color.g, color.g, n)
                        c.b = math.lerp(old_color.b, color.b, n)
                        o:set_color(c)
                        money:set_color(c)
                    end
                    t = 1
                end
            end
            function EHIameno_3Tracker:pre_init(params)
                self._cash_sign = managers.localization:text("cash_sign")
                self._max = 1800000
                self._progress = params.progress or 0
                self._progress_formatted = self:FormatNumber2(self._progress)
                self._max_formatted = self:FormatNumber2(self._max)
            end
            function EHIameno_3Tracker:OverridePanel()
                self:SetBGSize()
                self._money_text = self:CreateText({
                    text = self:FormatNumber(),
                    w = self._bg_box:w() / 2,
                    left = 0,
                    FitTheText = true
                })
                self._text:set_left(self._money_text:right())
                managers.ehi_loot:AddSmallLootListener(self._id, function(amount)
                    self:IncreaseProgress(amount)
                end)
                self._remove_small_loot_listener = true
            end
            function EHIameno_3Tracker:SetProgress(progress)
                if self._progress ~= progress and not self._disable_counting then
                    self._progress = progress
                    self._progress_formatted = self:FormatNumber2(progress)
                    self._money_text:set_text(self:FormatNumber())
                    self:FitTheText(self._money_text)
                    self:AnimateBG()
                    self:SetCompleted()
                end
            end
            function EHIameno_3Tracker:SetCompleted()
                if self._progress >= self._max and not self._status then
                    self._status = "completed"
                    self._disable_counting = true
                    self._achieved_popup_showed = true
                    self:delete_with_delay(true)
                end
            end
            function EHIameno_3Tracker:SetTextColor(color)
                EHINeededValueTracker.super.SetTextColor(self, color)
                self._money_text:set_color(color)
            end
            function EHIameno_3Tracker:pre_destroy()
                EHIameno_3Tracker.super.pre_destroy(self)
                self:Completed()
            end
        end
    },
    uno_3 =
    {
        difficulty_pass = OverkillOrBelow, -- Can be achieved on any difficulty but the heli takes 5:25 to arrive on Mayhem or above
        elements =
        {
            [301148] = { time = 180, class = TT.Achievement.Base },
            [300241] = { special_function = SF.SetAchievementComplete }
        }
    }
}

local FirstAssaultDelay = 10
local other = {}
if EHI:IsMayhemOrAbove() then
    other[301049] = EHI:AddAssaultDelay({ control = FirstAssaultDelay })
else
    other[301138] = EHI:AddAssaultDelay({ control = 50 + FirstAssaultDelay })
    other[301766] = EHI:AddAssaultDelay({ control = 40 + FirstAssaultDelay })
    other[301771] = EHI:AddAssaultDelay({ control = 30 + FirstAssaultDelay })
    other[301772] = EHI:AddAssaultDelay({ control = 20 + FirstAssaultDelay })
    other[301773] = EHI:AddAssaultDelay({ control = 10 + FirstAssaultDelay })
end
if EHI:GetLoadSniperTrackers(true) then
    ---@class EHIMallcrasherSniperTracker : EHITracker, EHISniperBaseTracker
    local EHIMallcrasherSniperTracker = ehi_sniper_class(EHITracker, { hint = "enemy_snipers_loop" })
    function EHIMallcrasherSniperTracker:post_init(params)
        self._single_sniper = true
        self._refresh_on_delete = true
        self._count_text = self:CreateText({
            text = "1",
            x = 0,
            color = self._sniper_text_color,
            FitTheText = true,
            visible = false
        })
        if not params.from_sync then
            self:SniperLogicStarted()
        end
    end
    ---@param t number
    function EHIMallcrasherSniperTracker:StartLoop(t)
        self._time = t
        self:AddTrackerToUpdate()
        self._text:show()
        self._count_text:hide()
        self:AnimateBG()
    end
    function EHIMallcrasherSniperTracker:Refresh()
        self._text:hide()
        self._count_text:show()
        self:RemoveTrackerFromUpdate()
        self:AnimateBG()
        self:SniperSpawned()
    end
    other[301804] = { id = "Snipers", time = 25, class_table = EHIMallcrasherSniperTracker, special_function = SF.ExecuteIfElementIsEnabled }
    other[301805] = { id = "Snipers", time = 21, class_table = EHIMallcrasherSniperTracker, special_function = SF.ExecuteIfElementIsEnabled }
    -- Respawn
    local StartLoop = EHI.Trigger:RegisterCustomSF(function(self, trigger, ...)
        local t = trigger.time
        if self._trackers:CallFunction2("Snipers", "StartLoop", t) then
            self._trackers:AddTracker({
                id = "Snipers",
                time = t,
                class_table = EHIMallcrasherSniperTracker
            })
        end
    end)
    other[301794] = { time = 51, special_function = StartLoop }
    other[301795] = { time = 71, special_function = StartLoop }
    other[301796] = { time = 91, special_function = StartLoop }
    other[301787] = { time = 80, special_function = StartLoop }
    other[301788] = { time = 60, special_function = StartLoop }
    other[301789] = { time = 40, special_function = StartLoop }
end
managers.ehi_hudlist:CallRightListItemFunction("Unit", "EnablePersistentSniperItem")

EHI.Mission:ParseTriggers({
    mission = triggers,
    achievement = achievements,
    other = other
})
EHI:AddXPBreakdown({
    objective =
    {
        mallcrasher = { amount = 1000, times = 6 }
    }
})