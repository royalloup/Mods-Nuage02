local EHI = EHI
local Icon = EHI.Icons
local Hints = EHI.Hints
if EHI:GetTrackerOrWaypointOption("show_mission_trackers", "show_waypoints_mission") then
    local show_tracker, show_waypoint = EHI:GetShowTrackerAndWaypoint("show_mission_trackers", "show_waypoints_mission")
    for _, unit_id in ipairs({ 100098, 102897, 102899, 102900 }) do
        managers.mission:add_runned_unit_sequence_trigger(unit_id, "interact", function(unit)
            if show_tracker then
                managers.ehi_tracker:AddTracker({
                    id = tostring(unit_id),
                    time = 10,
                    icons = { Icon.Fire },
                    hint = Hints.Thermite
                })
            end
            if show_waypoint then
                managers.ehi_waypoint:AddWaypoint(tostring(unit_id), {
                    time = 10,
                    icon = Icon.Fire,
                    position = EHI.Mission:GetUnitPositionOrDefault(unit_id)
                })
            end
        end)
    end
end

local SF = EHI.SpecialFunctions
local TT = EHI.Trackers
local DisableTriggerAndExecute = EHI.Trigger:RegisterCustomSF(function(self, trigger, ...)
    self:UnhookTrigger(trigger.data.id)
    self:CreateTracking()
end)
local triggers = {
    [103492] = { time = 300, id = "Blackhawk", icons = { Icon.Heli, Icon.Goto }, hint = Hints.kosugi_Heli, trigger_once = true },
    [101219] = { time = 27, id = "BlackhawkDropLoot", icons = { Icon.Heli, Icon.Loot, Icon.Goto }, hint = Hints.kosugi_Loot },
    [100303] = { time = 30, id = "BlackhawkDropGuards", icons = { Icon.Heli, "pager_icon", Icon.Goto }, class = TT.Warning, hint = Hints.kosugi_Guards },

    [100955] = { time = 10, id = "KeycardLeft", icons = { Icon.Keycard }, class = TT.Warning, special_function = DisableTriggerAndExecute, data = { id = 100957 }, hint = Hints.kosugi_Keycard },
    [100957] = { time = 10, id = "KeycardRight", icons = { Icon.Keycard }, class = TT.Warning, special_function = DisableTriggerAndExecute, data = { id = 100955 }, hint = Hints.kosugi_Keycard },
    [100967] = { special_function = SF.RemoveTracker, data = { "KeycardLeft", "KeycardRight" } }
}

---@type ParseAchievementTable
local achievements =
{
    kosugi_2 =
    {
        elements =
        {
            [102700] = { max = 6, class = TT.Achievement.Progress, status_is_overridable = true, show_finish_after_reaching_target = true },
            [102796] = { special_function = SF.SetAchievementFailed },
            [100311] = { special_function = SF.IncreaseProgress }
        }
    },
    kosugi_3 =
    {
        elements =
        {
            [102700] = { max = 7, class = TT.Achievement.Progress }
        },
        load_sync = function(self)
            local counter = 0
            for _, loot_type in ipairs({ "artifact_statue", "money", "coke", "gold", "circuit", "weapon", "painting" }) do
                local amount = managers.loot:GetSecuredBagsTypeAmount(loot_type)
                counter = counter + math.min(amount, 1)
            end
            if counter < 7 then
                self._unlockable:AddAchievementProgressTracker("kosugi_3", 7, counter)
            end
        end,
        preparse_callback = function(data)
            local trigger = { special_function = SF.IncreaseProgress }
            -- Artifact, Money, Coke, Server, Gold, Weapon, Painting
            for _, id in ipairs({ 104040, 104041, 104042, 104044, 104047, 104048, 104049 }) do
                data.elements[id] = trigger
            end
        end
    },
    kosugi_5 =
    {
        elements =
        {
            [102700] = { counter = {
                { max = 16, id = "bags" },
                { max = 4, id = "armor" }
            } }
        },
        load_sync = function(self)
            local counter_armor = managers.loot:GetSecuredBagsTypeAmount("samurai_suit")
            local counter_loot = managers.loot:GetSecuredBagsAmount()
            if counter_loot < 16 or counter_armor < 4 then
                local kosugi_5
                local spawn = self._all_triggers[102700]
                if spawn then
                    if spawn._params.id == "kosugi_5" then
                        kosugi_5 = spawn._params.class_table
                    elseif spawn:GetSpecialFunction() == self.SF.Trigger then
                        for _, i in ipairs(spawn._params.data or {}) do
                            local trigger = self._all_triggers[i]
                            if trigger and trigger._params.id == "kosugi_5" then
                                kosugi_5 = trigger._params.class_table
                                break
                            end
                        end
                    end
                end
                if kosugi_5 then
                    self._unlockable:AddAchievementProgressTracker("kosugi_5", 0, 0, nil, kosugi_5)
                    self._trackers:CallFunction("kosugi_5", "AddFromSync", {
                        { progress = math.min(counter_loot, 16), max = 16, id = "bags" },
                        { progress = math.min(counter_armor, 4), max = 4, id = "armor" }
                    })
                end
            end
        end,
        preparse_callback = function(data)
            ---@class kosugi_5 : EHIAchievementProgressGroupTracker
            ---@field super EHIAchievementProgressGroupTracker
            local kosugi_5 = class(EHIAchievementProgressGroupTracker)
            function kosugi_5:post_init(...)
                kosugi_5.super.post_init(self, ...)
                self:AddLootListener({
                    counter =
                    {
                        f = function(loot)
                            self:SetProgress(loot:GetSecuredBagsTypeAmount("samurai_suit"), "armor")
                            self:SetProgress(loot:GetSecuredBagsAmount(), "bags")
                        end
                    }
                })
            end
            data.elements[102700].class_table = kosugi_5
        end
    }
}

local sidejob = {}
if EHI:IsBetweenDifficulties(EHI.Difficulties.VeryHard, EHI.Difficulties.OVERKILL) then
    local IncreaseProgress = { special_function = SF.IncreaseProgress }
    local elements = {
        [103427] = { max = 9, icons = { "daily_secret_identity" }, class = TT.SideJob.Progress, show_finish_after_reaching_target = true },
        [100484] = IncreaseProgress,
        [100515] = IncreaseProgress,
        [100534] = IncreaseProgress,
        [100536] = IncreaseProgress
    }
    for i = 100491, 100509, 2 do
        elements[i] = IncreaseProgress
    end
    for i = 100519, 100531, 2 do
        elements[i] = IncreaseProgress
    end
    for i = 100539, 100555, 2 do
        elements[i] = IncreaseProgress
    end
    tweak_data.hud_icons.daily_secret_identity = tweak_data.ehi.icons.daily_secret_identity
    sidejob.daily_secret_identity = { elements = elements }
end

local other = {}
if EHI:IsLootCounterVisible() then
    local function CheckForBrokenWeapons()
        local table_of_weapons = { 100863, 100864, 100865, 100866, 100867, 100372 }
        return tweak_data.ehi.functions.GetNumberOfVisibleWeapons(table_of_weapons)
    end
    local function CheckForBrokenCocaine()
        local table_of_coke = { 100686, 100687, 100688, 100689, 100690, 100691, 100692, 100374 }
        return tweak_data.ehi.functions.GetNumberOfVisibleOtherLoot(table_of_coke)
    end
    -- Loot Counter  
    -- 2 cocaine; disabled due to check above  
    -- 1 server  
    -- 2 random money bundles inside the warehouse  
    -- 4 random money bundles outside  
    -- 4 pieces of armor
    local base_amount = 0 + 1 + 2 + 4 + 4
    local random_weapons = 0 -- Disabled due to check above; should be 2
    local random_paintings = 2
    local crates = 4 -- (Normal + Hard)
    if EHI:IsBetweenDifficulties(EHI.Difficulties.VeryHard, EHI.Difficulties.OVERKILL) then
        crates = 5
    elseif EHI:IsMayhemOrAbove() then
        crates = 6
        --random_weapons = 1
        random_paintings = 1
    end
    other[102700] = EHI:AddLootCounter2(function()
        EHI:ShowLootCounterNoChecks({
            max = base_amount + crates + random_weapons + random_paintings + CheckForBrokenWeapons() + CheckForBrokenCocaine(),
            max_xp_bags = 16,
            triggers =
            {
                [103396] = EHI:AddCustomCode(function(self)
                    self._loot:IncreaseLootCounterProgressMax()
                end)
            },
            hook_triggers = true,
            no_triggers_if_max_xp_bags_gt_max = true
        })
    end, { element = { 100233, 100020, 103764, 103767, 103768, 103769, 103770 } })
    -- Not included bugged loot, this is checked after spawn -> 102700
    -- Reported here:
    -- https://steamcommunity.com/app/218620/discussions/14/5710018482972011532/
end

EHI.Mission:ParseTriggers({
    mission = triggers,
    achievement = achievements,
    sidejob = sidejob,
    other = other
})

EHI:ShowAchievementLootCounter({
    achievement = "kosugi_1",
    job_pass = managers.job:current_job_id() == "kosugi",
    max = 4
})
EHI:ShowAchievementLootCounter({
    achievement = "kosugi_4",
    job_pass = managers.job:current_job_id() == "kosugi",
    max = 4,
    counter =
    {
        loot_type = "samurai_suit"
    }
})
tweak_data.ehi.functions.achievements.eng_X("eng_2") -- "The one that had many names" achievement
local min_bags = EHI:GetValueBasedOnDifficulty({
    normal = 3,
    hard = 5,
    veryhard = 7,
    overkill = 9,
    mayhem_or_above = 12
})
EHI:AddXPBreakdown({
    objective =
    {
        escape =
        {
            { amount = 4000, stealth = true }
        }
    },
    loot =
    {
        samurai_suit = { amount = 6000, to_secure = 4 },
        _else = { amount = 500, times = 16 },
        xp_bonus = { amount = 4000, to_secure = 3, times = 1 }
    },
    total_xp_override =
    {
        params =
        {
            min_max =
            {
                loot =
                {
                    samurai_suit = { max = 1 },
                    _else = { min = min_bags, max = 16 },
                    xp_bonus = { min_max = 1 }
                },
                bonus_xp = { max = 4000 } -- Stealth Escape
            }
        }
    }
})