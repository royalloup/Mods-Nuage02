local EHI = EHI
local Icon = EHI.Icons
local SF = EHI.SpecialFunctions
local TT = EHI.Trackers
local Hints = EHI.Hints
local element_sync_triggers =
{
    [101374] = { id = "VaultTeargas", icons = { Icon.Teargas }, hook_element = 101377, hint = Hints.Teargas }
}
---@type ParseTriggerTable
local triggers = {
    [100903] = { time = 120, id = "LiquidNitrogen", icons = { Icon.LiquidNitrogen }, waypoint = { position_from_element = 100941 }, hint = Hints.rvd2_LiquidNitrogen },

    [100699] = { time = 8 + 25 + 13, id = "ObjectiveWait", icons = { Icon.Wait }, hint = Hints.Wait },

    [100939] = { time = 5, id = "C4Vault", icons = { Icon.C4 }, waypoint = { position_from_element = 100941 }, hint = Hints.Explosion }
}
local other =
{
    [100109] = EHI:AddAssaultDelay({ control = 30 })
}
if EHI.IsHost then
    triggers[101498] = { time = 6 + 4 + 30 + 24 + 3, id = "HeliC4", icons = Icon.HeliDropC4, waypoint = { data_from_element = 100943 }, hint = Hints.C4Delivery }
    ---`mesh_variation "set_level_mia"`  
    ---units/payday2/equipment/gen_interactable_sec_safe_2x05/gen_interactable_sec_safe_2x05 (buggy mesh_variation -> `"set_level_rat_2"` instead)
    ---units/payday2/equipment/gen_interactable_sec_safe_2x05_titan/gen_interactable_sec_safe_2x05_titan
    ---units/payday2/equipment/gen_interactable_sec_safe_05x05_titan/gen_interactable_sec_safe_05x05_titan
    local SafeTriggers =
    {
        loot =
        {
            "spawn_loot_money"
        },
        no_loot =
        {
            "spawn_loot_value_a",
            "spawn_loot_value_d",
            "spawn_loot_value_e",
            "spawn_loot_crap_b", -- titan
            "spawn_loot_crap_c", -- titan
            "spawn_loot_crap_d"
        }
    }
    ---@param self EHIMissionElementTrigger
    ---@param truck_id number
    local function IncreaseMax(self, truck_id)
        self._loot:SyncIncreaseLootCounterMaxRandom(9)
        tweak_data.ehi.functions.HookArmoredTransportUnit(truck_id, { "money" })
    end
    EHI:ShowLootCounterSynced({
        max = 19,
        max_random = 3,
        triggers =
        {
            [101287] = { special_function = SF.CustomCode2, f = IncreaseMax, arg = 101647 },
            [101492] = { special_function = SF.CustomCode2, f = IncreaseMax, arg = 102104 }
        },
        sequence_triggers =
        {
            [300960] = SafeTriggers, -- art_reg continent
            [500001] = SafeTriggers, -- mkp continent
            [501562] = SafeTriggers -- mkp continent
        }
    }, { element = { EHI:GetInstanceElementID(100037, 4650), EHI:GetInstanceElementID(100037, 4850) }, present_timer = 0 })
else
    ---@param self EHIMissionElementTrigger
    ---@param trigger ElementTrigger
    local function WP(self, trigger)
        if self._waypoints:WaypointDoesNotExist("LiquidNitrogen") then
            self._waypoints:AddWaypoint("LiquidNitrogen", {
                time = trigger.time - 10,
                icon = Icon.LiquidNitrogen,
                position = self._mission:GetElementPositionOrDefault(100941)
            })
        end
        if self._waypoints:WaypointDoesNotExist("HeliC4") then
            self._waypoints:AddWaypoint("HeliC4", {
                time = trigger.time,
                icon = Icon.C4,
                position = self._mission:GetElementPositionOrDefault(100943)
            })
        end
    end
    triggers[101366] = { additional_time = 5 + 40, random_time = 10, id = "VaultTeargas", icons = { Icon.Teargas }, hint = Hints.Teargas }
    local LiquidNitrogen = EHI.Trigger:RegisterCustomSF(function(self, trigger, ...)
        if self._trackers:DoesNotExist("LiquidNitrogen") then
            self._trackers:AddTracker({
                id = "LiquidNitrogen",
                time = trigger.time - 10,
                icons = { Icon.LiquidNitrogen },
                hint = Hints.rvd2_LiquidNitrogen
            })
        end
        if self._trackers:DoesNotExist("HeliC4") then
            self._trackers:AddTracker({
                id = "HeliC4",
                time = trigger.time,
                icons = Icon.HeliDropC4,
                hint = Hints.C4Delivery
            })
        end
    end)
    triggers[101498] = { time = 6 + 4 + 30 + 24 + 3, special_function = LiquidNitrogen, waypoint_f = WP }
    triggers[100035] = { time = 4 + 30 + 24 + 3, special_function = LiquidNitrogen, waypoint_f = WP }
    triggers[101630] = { time = 30 + 24 + 3, special_function = LiquidNitrogen, waypoint_f = WP }
    triggers[101629] = { time = 24 + 3, special_function = LiquidNitrogen, waypoint_f = WP }
    EHI:ShowLootCounterWaypoint({ element = { EHI:GetInstanceElementID(100037, 4650), EHI:GetInstanceElementID(100037, 4850) }, present_timer = 0 })
end
if EHI:GetLoadSniperTrackers() then
    other[100358] = { chance = 10, time = 1 + 10 + 25, on_fail_refresh_t = 25, on_success_refresh_t = 20 + 10 + 25, id = "Snipers", class = TT.Sniper.Loop, sniper_count = 2 }
    other[100359] = EHI:CopyTrigger(other[100358], { sniper_count = 3 })
    other[100533] = { id = "Snipers", special_function = SF.CallCustomFunction, f = "OnChanceFail" }
    other[100363] = { id = "Snipers", special_function = SF.CallCustomFunction, f = "OnChanceSuccess" }
    other[100537] = { id = "Snipers", special_function = SF.IncreaseChanceFromElement } -- +5%
    other[100565] = { id = "Snipers", special_function = SF.SetChanceFromElement } -- 10%
    other[100574] = { id = "Snipers", special_function = SF.IncreaseChanceFromElement } -- +15%
    if EHI.IsClient then
        local sniper_count = EHI:IsDifficultyOrBelow(EHI.Difficulties.VeryHard) and 3 or 2 -- They swapped max sniper count for some reason
        managers.ehi_assault:AddAssaultNumberSyncCallback(function(assault_number, in_assault)
            if assault_number <= 1 then -- 2 assaults
                return
            end
            managers.ehi_tracker:AddTracker({
                id = "Snipers",
                from_sync = true,
                count = EHISniperBase._alive_count,
                on_fail_refresh_t = 25,
                on_success_refresh_t = 20 + 10 + 25,
                sniper_count = sniper_count,
                class = TT.Sniper.Loop
            })
        end)
    end
end
if EHI:IsDifficultyOrAbove(EHI.Difficulties.OVERKILL) then
    if EHI:CanShowAchievement2("rvd_8", "show_achievements_weapon") then -- "United We Heist" achievement
        EHI:AddOnSpawnedExtendedCallback(function(self, job, level, from_beginning)
            if job == "rvd" and self:EHIHasPrimaryWeaponTypeEquipped("assault_rifle") and managers.job:get_memory("ehi_rvd_8") then
                managers.ehi_unlockable:AddAchievementStatusTracker("rvd_8")
                local function fail()
                    managers.ehi_unlockable:SetAchievementFailed("rvd_8")
                    Hooks:RemovePostHook("EHI_rvd_8_shot_fired")
                    Hooks:RemovePostHook("EHI_rvd_8_register_melee_hit")
                end
                Hooks:PostHook(StatisticsManager, "shot_fired", "EHI_rvd_8_shot_fired", function(sm, data)
                    local name_id = data.name_id or data.weapon_unit:base():get_name_id()
                    if tweak_data:get_raw_value("weapon", name_id, "categories", 1) ~= "assault_rifle" then
                        fail()
                    end
                end)
                Hooks:PostHook(StatisticsManager, "register_melee_hit", "EHI_rvd_8_register_melee_hit", fail)
            end
        end)
    end
    if EHI:CanShowAchievement2("rvd_12", "show_achievements_melee") then -- "Close Shave" achievement
        EHI:AddOnSpawnedExtendedCallback(function(self, job, level, from_beginning)
            if job == "rvd" then
                self:EHIAddAchievementTrackerFromStat("rvd_12")
            end
        end)
    end
    EHI:ShowAchievementLootCounter({
        achievement = "rvd_11",
        job_pass = managers.job:current_job_id() == "rvd",
        max = 19,
        counter =
        {
            loot_type = { "diamonds_dah", "diamonds" }
        }
    })
end
EHI.TrackerUtils.Hudlist:AddAssaultCallbackForSniperItem(2, "start", "rvd2")
EHI.Unit:IgnoreCarryInHudlist(100296) -- Unobtainable money pile near sniper pos
EHI.Unit:IgnoreInteractInHudlist(100277, 100278, 100279, 100280) -- Small loot near the money pile
EHI.Mission:ParseTriggers({
    mission = triggers,
    other = other,
    sync_triggers = { element = element_sync_triggers },
    assault =
    {
        diff_load_sync = function(self, assault_number, in_assault)
            if assault_number <= 0 or (assault_number == 1 and in_assault) then
                self._assault:SetDiff(0.5)
            elseif (assault_number == 1 and not in_assault) or (assault_number == 2 and in_assault) then
                self._assault:SetDiff(0.75)
            else
                self._assault:SetDiff(1)
            end
        end
    }
})

local DisableWaypoints =
{
    [101768] = true, -- Defend PC
    [101765] = true -- Fix PC

    -- levels/instances/unique/rvd/rvd_hackbox/world
    -- Handled in CoreWorldInstanceManager.lua
}
EHI.Waypoint:DisableTimerWaypoints(DisableWaypoints)
EHI:AddXPBreakdown({
    objectives =
    {
        { amount = 6000, name = "rvd2_hacking_done" },
        { amount = 2000, name = "vault_drills_done" },
        { amount = 4000, name = "rvd2_vault_frozen" },
        { amount = 2000, name = "c4_set_up" },
        { escape = 1000 }
    },
    loot_all = 500,
    total_xp_override =
    {
        params =
        {
            min_max =
            {
                -- max = 19 diamond bags, 3 money bags in the safes (random), 3 bags in GenSec transport (random)
                loot_all = { min = 6, max = 25 }
            }
        }
    }
})