local EHI = EHI
local Icon = EHI.Icons
local SF = EHI.SpecialFunctions
local TT = EHI.Trackers
local Hints = EHI.Hints
local ovk_and_up = EHI:IsDifficultyOrAbove(EHI.Difficulties.OVERKILL)
local triggers = {
    [100109] = { max = (ovk_and_up and 40 or 30), id = "EnemyDeathShowers", icons = { Icon.Kill }, flash_times = 1, class = TT.Progress, hint = Hints.Kills },
    [101339] = { id = "EnemyDeathShowers", special_function = SF.IncreaseProgress },

    [101285] = { time = 11, id = "Thermite1", icons = { Icon.Fire }, hint = Hints.Thermite, waypoint = { position_from_unit = EHI:GetInstanceUnitID(100069, 2850) } },
    [101277] = { time = 11, id = "Thermite2", icons = { Icon.Fire }, hint = Hints.Thermite, waypoint = { position_from_unit = EHI:GetInstanceUnitID(100069, 4200) } },
    [101286] = { time = 11, id = "Thermite3", icons = { Icon.Fire }, hint = Hints.Thermite, waypoint = { position_from_unit = EHI:GetInstanceUnitID(100069, 4350) } },
    [101284] = { time = 11, id = "Thermite4", icons = { Icon.Fire }, hint = Hints.Thermite, waypoint = { position_from_unit = EHI:GetInstanceUnitID(100069, 4500) } },

    [102606] = { time = 10, id = "MoveWalkway", icons = { Icon.Wait }, hint = Hints.Wait, waypoint = { position_from_unit = 101353 } },

    [101137] = { max = 10, id = "EnemyDeathOutside", icons = { Icon.Kill }, flash_times = 1, class = TT.Progress, hint = Hints.Kills, waypoint = { data_from_element_and_remove_vanilla_waypoint = 101793 } },
    [101412] = { id = "EnemyDeathOutside", special_function = SF.IncreaseProgress }
}

---@type ParseAchievementTable
local achievements =
{
    bph_10 =
    {
        difficulty_pass = ovk_and_up,
        elements =
        {
            [101742] = { max = 3, class = TT.Achievement.Progress, trigger_once = true },
            [101885] = { special_function = SF.SetAchievementFailed },
            [102171] = { special_function = SF.IncreaseProgress }
        }
    }
}
if EHI:CanShowAchievement2("bph_9", "show_achievements_melee") and ovk_and_up then -- Prison Rules, Bitch!
    EHI:AddOnSpawnedExtendedCallback(function(self, job, level, from_beginning)
        if job == "bph" and self:EHIHasMeleeEquipped("toothbrush") then
            self:EHIAddAchievementTrackerFromStat("bph_9_stat")
        end
    end)
end

local other =
{
    [100109] = EHI:AddAssaultDelay({ control = 1 })
}
if EHI:GetLoadSniperTrackers() then
    local sniper_count = EHI:GetValueBasedOnDifficulty({
        veryhard_or_below = 2, -- ???
        overkill_or_above = 1
    })
    other[100015] = { chance = 10, time = 1 + 15, on_fail_refresh_t = 15, on_success_refresh_t = 20 + 15, id = "Snipers", class = TT.Sniper.Loop, single_sniper = sniper_count == 1, sniper_count = sniper_count }
    other[100533] = { id = "Snipers", special_function = SF.CallCustomFunction, f = "OnChanceFail" }
    other[100363] = { id = "Snipers", special_function = SF.CallCustomFunction, f = "OnChanceSuccess" }
    other[100537] = { id = "Snipers", special_function = SF.IncreaseChanceFromElement } -- +5%
    other[100565] = { id = "Snipers", special_function = SF.SetChanceFromElement } -- 10%
    other[100574] = { id = "Snipers", special_function = SF.IncreaseChanceFromElement } -- +15%
end
if EHI:GetHudlistAndListOption("right_list", "show_units") then
    local function unit(self)
        managers.ehi_hudlist:CallRightListItemFunction("Unit", "IgnoreEnemyTurret")
        managers.ehi_hudlist:CallRightListItemFunction("Unit", "EnablePersistentSniperItem", true)
    end
    other[100995] = EHI:AddCustomCode(unit) -- After opening the door and meeting up with Bain
    other[100995].load_sync = function(self) ---@param self EHIMissionElementTrigger
        if managers.groupai:state()._hunt_mode then
            unit()
        end
    end
end

-- 101399 units/pd2_indiana/props/gen_prop_security_timer/gen_prop_security_timer/001 (2050, -10250, 639.67)
EHI.Unit:UpdateUnits({ [101399] = { icons = { "C_Locke_H_HellsIsland_Another" }, hint = Hints.Wait } })

EHI.Mission:ParseTriggers({
    mission = triggers,
    achievement = achievements,
    other = other,
    assault = {
        ignore_assault_start_count = 1,
        wave_mode_elements_block = { 101325, 100115 },
        fake_assault_block = true
    }
})
EHI:AddXPBreakdown({
    objectives =
    {
        { amount = 2000, name = "bph_found_control_room" },
        { amount = 3000, name = "bph_opening_correct_cell" },
        { amount = 5000, name = "bph_follow_bain" },
        { amount = 1000, name = "bph_met_on_rooftop" },
        { amount = 3000, name = "bph_extended_bridge" },
        { amount = ovk_and_up and 4000 or 3000, name = "bph_helipad_is_accessible" }
    }
})