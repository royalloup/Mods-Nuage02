local EHI = EHI
local Icon = EHI.Icons
local TT = EHI.Trackers
local SF = EHI.SpecialFunctions
local Hints = EHI.Hints
local truck_delay = 524/30
local boat_delay = 450/30
---@type ParseTriggerTable
local triggers = {
    [104082] = { time = 30 + 24 + 3, id = "HeliThermalDrill", icons = Icon.HeliDropDrill, hint = Hints.DrillDelivery },

    -- Boat
    [103273] = { time = boat_delay, id = "BoatSecureTurret", icons = Icon.BoatLootDrop, hint = Hints.Loot },
    [103041] = { time = 30 + boat_delay, id = "BoatSecureAmmo", icons = Icon.BoatLootDrop, hint = Hints.Loot },

    -- Truck
    [105055] = { time = 15 + truck_delay, id = "TruckSecureTurret", icons = Icon.CarLootDrop, hint = Hints.Loot },
    [105183] = { time = 30 + 524/30, id = "TruckSecureAmmo", icons = Icon.CarLootDrop, hint = Hints.Loot }
}
---@type ParseAchievementTable
local achievements =
{
    armored_6 =
    {
        elements =
        {
            -- Achievement bugged, can be earned in stealth
            -- Reported in: https://steamcommunity.com/app/218620/discussions/14/3048357185566603324/
            [104716] = { class = TT.Achievement.Status },
            [103311] = { special_function = SF.SetAchievementFailed }
        },
        load_sync = function(self)
            if self.ConditionFunctions.IsStealth() then
                self._unlockable:AddAchievementStatusTracker("armored_6")
            end
        end
    }
}

local other =
{
    [100109] = EHI:AddAssaultDelay({ control = 30 })
}
if EHI:GetLoadSniperTrackers() then
    other[100358] = { chance = 10, time = 1 + 10 + 25, on_fail_refresh_t = 25, on_success_refresh_t = 20 + 10 + 25, id = "Snipers", class = TT.Sniper.Loop, trigger_once = true, sniper_count = 2 }
    other[100362] = EHI:CopyTrigger(other[100358], { single_sniper = true, sniper_count = 1 })
    other[100533] = { id = "Snipers", special_function = SF.CallCustomFunction, f = "OnChanceFail" }
    other[100363] = { id = "Snipers", special_function = SF.CallCustomFunction, f = "OnChanceSuccess" }
    other[100537] = { id = "Snipers", special_function = SF.IncreaseChanceFromElement } -- +5%
    other[100565] = { id = "Snipers", special_function = SF.SetChanceFromElement } -- 10%
    other[100574] = { id = "Snipers", special_function = SF.IncreaseChanceFromElement } -- +15%
end
managers.ehi_hudlist:CallRightListItemFunction("Unit", "EnablePersistentSniperItem")

EHI.Mission:ParseTriggers({
    mission = triggers,
    achievement = achievements,
    other = other,
    assault =
    {
        diff_load_sync = function(self, assault_number, in_assault)
            if self.ConditionFunctions.IsStealth() then -- Skip if dropped-in in stealth
                return
            elseif assault_number <= 0 or (assault_number == 1 and in_assault) then
                self._assault:SetDiff(0.8)
            else
                self._assault:SetDiff(1)
            end
        end
    }
})
EHI:ShowAchievementLootCounter({
    achievement = "armored_1",
    job_pass = managers.job:current_job_id() == "arm_for",
    max = 20,
    counter =
    {
        loot_type = "ammo"
    }
})
EHI:ShowLootCounter({ max = 23 }, { element = { 100233, 100008, 100020, 102685, 103048, 104072, 103275 } })

local tbl = {}
for i = 0, 500, 100 do
    --levels/instances/unique/train_cam_computer
    --units/pd2_indiana/props/gen_prop_security_timer/gen_prop_security_timer
    tbl[EHI:GetInstanceUnitID(100022, i)] = { icons = { Icon.Vault }, remove_on_alarm = true }
end
EHI.Unit:UpdateUnits(tbl)
EHI:SetMissionDoorData({
    -- Vaults
    [101850] = 100835,
    [102433] = 100253,
    [102431] = 100838,
    [102434] = 100840,
    [102432] = 102288,
    [102435] = 102593
})
EHI:AddXPBreakdown({
    objectives =
    {
        { amount = 3000, name = "vault_open", times = 3 },
        { amount = 7000, name = "turret_secured" },
        { escape = 4000 }
    },
    loot =
    {
        ammo = { amount = 800, times = 20 }
    }
})