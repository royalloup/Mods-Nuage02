local EHI = EHI
local SF = EHI.SpecialFunctions
local TT = EHI.Trackers
local other =
{
    [100116] = EHI:AddAssaultDelay({ control = 60 })
}
if EHI:IsLootCounterVisible() then
    other[100107] = EHI:AddLootCounter2(function()
        EHI:ShowLootCounterNoChecks({
            max = 6,
            max_random = 7
        })
    end, { element = 100008 }, nil, true)
    other[100109] = EHI:AddCustomCode(function(self)
        self._loot:RandomLootDeclined(7)
    end)
    other[107260] = EHI:AddCustomCode(function(self)
        self._loot:RandomLootSpawned(7)
    end)
end

if EHI:GetLoadSniperTrackers() then
    other[100358] = { chance = 10, time = 1 + 10 + 25, on_fail_refresh_t = 25, on_success_refresh_t = 20 + 10 + 25, id = "Snipers", class = TT.Sniper.Loop, trigger_once = true, sniper_count = 2 }
    other[100359] = EHI:CopyTrigger(other[100358], { sniper_count = 3 })
    other[100533] = { id = "Snipers", special_function = SF.CallCustomFunction, f = "OnChanceFail" }
    other[100363] = { id = "Snipers", special_function = SF.CallCustomFunction, f = "OnChanceSuccess" }
    other[100537] = { id = "Snipers", special_function = SF.IncreaseChanceFromElement } -- +5%
    other[100565] = { id = "Snipers", special_function = SF.SetChanceFromElement } -- 10%
    other[100574] = { id = "Snipers", special_function = SF.IncreaseChanceFromElement } -- +15%
end
managers.ehi_hudlist:CallRightListItemFunction("Unit", "EnablePersistentSniperItem")
EHI.Mission:ParseTriggers({
    other = other,
    assault =
    {
        diff_load_sync = function(self, assault_number, in_assault)
            if self.ConditionFunctions.IsStealth() then -- Skip if dropped-in in stealth
                return
            elseif assault_number <= 0 or (assault_number == 1 and in_assault) then
                self._assault:SetDiff(0.5)
            elseif (assault_number == 1 and not in_assault) or (assault_number == 2 and in_assault) then
                self._assault:SetDiff(0.75)
            else
                self._assault:SetDiff(1)
            end
        end
    }
})

EHI.Unit:UpdateUnits({
    --units/payday2/equipment/gen_interactable_hack_computer/gen_interactable_hack_computer_b
    [103064] = { remove_vanilla_waypoint = 103082 },
    [103065] = { remove_vanilla_waypoint = 103083 },
    [103066] = { remove_vanilla_waypoint = 103084 }
})
EHI:ShowAchievementLootCounter({
    achievement = "bob_4",
    job_pass = managers.job:current_job_id() == "election_day",
    max = 6,
    counter =
    {
        loot_type = "money"
    }
})
EHI:AddXPBreakdown({
    objective =
    {
        escape =
        {
            { amount = 8000, stealth = true, timer = 300 },
            { amount = 14000, stealth = true },
            { amount = 18000, loud = true }
        }
    },
    loot =
    {
        money = 500,
        gold = 1000
    },
    total_xp_override =
    {
        params =
        {
            escape =
            {
                loot =
                {
                    money = { max = 6 },
                    gold = { max = 7, no_loud_xp = true }
                }
            }
        }
    }
})