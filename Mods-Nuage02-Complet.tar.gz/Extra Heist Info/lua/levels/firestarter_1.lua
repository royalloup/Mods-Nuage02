local EHI = EHI
local SF = EHI.SpecialFunctions
local TT = EHI.Trackers
local Weapons = { 100817, 100818, 100657, 100659, 100663, 100664, 100673, 100715, 100712, 100704, 100705, 100749, 100751, 100681, 100819, 100821, 100823, 100950, 100962, 100967, 101193 } -- Hangar 01 + Hangar 4 (bag 03)
local n = 22
-- Hangar 2, Hangar 3 + Hangar 4 (First half)
for i = 102126, 102175, 1 do
    Weapons[n] = i
    n = n + 1
end
-- Hangar 4 (Second half)
for i = 103797, 103806, 1 do
    Weapons[n] = i
    n = n + 1
end

local other =
{
    -- This needs to be delayed because the number of required weapons is decided upon spawn
    [103240] = { special_function = SF.CustomCodeDelayed, t = 5, f = function()
        local is_playing_firestarter = managers.job:current_job_id() == "firestarter"
        local n_of_weapons = tweak_data.ehi.functions.GetNumberOfVisibleWeapons(Weapons)
        EHI:ShowAchievementLootCounter({
            achievement = "lord_of_war",
            job_pass = is_playing_firestarter,
            max = n_of_weapons,
            triggers =
            {
                [103427] = { special_function = SF.SetAchievementFailed, trigger_once = true } -- Weapons destroyed
            },
            hook_triggers = true,
            add_to_counter = true
        })
        EHI:ShowAchievementLootCounter({
            achievement = "ovk_10",
            job_pass = is_playing_firestarter,
            max = n_of_weapons,
            triggers =
            {
                [103427] = { special_function = SF.IncreaseProgress } -- Weapons destroyed
            },
            hook_triggers = true,
            show_finish_after_reaching_target = true,
            difficulty_pass = EHI:IsDifficultyOrAbove(EHI.Difficulties.DeathWish)
        })
        local function DecreaseLootCounterProgressMax()
            managers.ehi_loot:DecreaseLootCounterProgressMax()
        end
        EHI:ShowLootCounter({
            max = n_of_weapons + 1, -- 1 bag of money
            triggers =
            {
                [103427] = { special_function = SF.CustomCode, f = DecreaseLootCounterProgressMax }, -- Weapons destroyed
                -- Why make 1 ElementCarry (remove) element when you can make 4...
                [104470] = { special_function = SF.CustomCode, f = DecreaseLootCounterProgressMax }, -- Money destroyed
                [104471] = { special_function = SF.CustomCode, f = DecreaseLootCounterProgressMax }, -- Money destroyed
                [104472] = { special_function = SF.CustomCode, f = DecreaseLootCounterProgressMax }, -- Money destroyed
                [104473] = { special_function = SF.CustomCode, f = DecreaseLootCounterProgressMax } -- Money destroyed
            },
            hook_triggers = true
        })
    end },

    [100531] = EHI:AddAssaultDelay({}) -- 30s
}
if EHI:IsLootCounterVisible() then
    EHI:ShowLootCounterWaypoint({ element = 103215, 103218 })
end

EHI.Mission:ParseTriggers({
    other = other
})
EHI:AddXPBreakdown({
    objectives =
    {
        { amount = 8000, name = "fs_burned_required_bags" },
        { _or = true },
        { amount = 10000, name = "fs_secured_required_bags" },
        { amount = 6000, name = "all_bags_secured", optional = true }
    },
    total_xp_override =
    {
        params =
        {
            min =
            {
                objectives =
                {
                    fs_burned_required_bags = true
                }
            },
            max =
            {
                objectives =
                {
                    fs_secured_required_bags = true,
                    all_bags_secured = true
                }
            }
        }
    }
})