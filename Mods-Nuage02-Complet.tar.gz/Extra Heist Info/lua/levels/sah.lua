local EHI = EHI
local Icon = EHI.Icons
local SF = EHI.SpecialFunctions
local TT = EHI.Trackers
local Hints = EHI.Hints
---@type ParseTriggerTable
local triggers = {
    [100643] = { time = 30, id = "CrowdAlert", icons = { Icon.Alarm }, class = TT.Warning, hint = Hints.Alarm, remove_on_alarm = true },
    [100645] = { id = "CrowdAlert", special_function = SF.RemoveTracker }

    -- Heli Escape is in CoreWorldInstanceManager
}
if EHI.Mission._SHOW_MISSION_TRIGGERS_TYPE.cheaty then
    triggers[EHI:GetInstanceElementID(100088, 18200)] = { id = "VaultCode", class = TT.Code, waypoint = { icon = "code", position_from_element = EHI:GetInstanceElementID(100084, 18200) } }
    ---@param self EHIMissionElementTrigger
    local function ShowCodePart(self, arg)
        self._tracking:Call("VaultCode", "SetCodePart", arg[1] + 1, arg[2], 4)
    end
    local num, pos = 0, 0
    for i = 100169, 100208, 1 do
        num = num + 1
        if num == 10 then
            num = 0
        end
        triggers[EHI:GetInstanceElementID(i, 18200)] = { special_function = SF.CustomCode2, f = ShowCodePart, arg = { pos, num } }
        if num == 0 then
            pos = pos + 1
        end
    end
    triggers[EHI:GetInstanceElementID(100281, 20000)] = { id = "VaultCode", special_function = SF.RemoveTracker }
end

---@type ParseAchievementTable
local achievements =
{
    sah_9 =
    {
        difficulty_pass = EHI:IsDifficultyOrAbove(EHI.Difficulties.OVERKILL),
        elements =
        {
            [100107] = { time = 300, class = TT.Achievement.Base },
            [101878] = { special_function = SF.SetAchievementComplete },
            [101400] = { special_function = SF.SetAchievementFailed, trigger_once = true }
        }
    }
}

local other =
{
    [100109] = EHI:AddAssaultDelay({ control = 1 }) -- Diff 0.5 is applied at start -> ´delay´ MissionScriptElement 100018
}
EHI.Unit:IgnoreCarryInHudlist(400791, 400792) -- 2x un-baggable artifacts near the vault

EHI.Mission:ParseTriggers({
    mission = triggers,
    achievement = achievements,
    other = other
})

EHI.Unit:UpdateUnitsNoCheck({
    -- Unused Grenade case
    [400178] = { f = "IgnoreDeployable" }
})
local xp_override =
{
    params =
    {
        min =
        {
            objectives = true,
            loot =
            {
                black_tablet = { times = 1 }
            }
        },
        no_max = true
    }
}
EHI:AddXPBreakdown({
    plan =
    {
        stealth =
        {
            objectives =
            {
                { amount = 4000, name = "vault_found" },
                { amount = 6000, name = "sah_entered_vault_code" },
                { amount = 4000, name = "sah_retrieved_tablet" },
                { escape = 1000 }
            },
            loot_all = 1000,
            total_xp_override = xp_override
        },
        loud =
        {
            objectives =
            {
                { amount = 6000, name = "vault_found" },
                { amount = 10000, name = "sah_entered_vault_code" },
                { amount = 6000, name = "sah_retrieved_tablet" },
                { escape = 4000 }
            },
            loot_all = 1000,
            total_xp_override = xp_override
        }
    }
})