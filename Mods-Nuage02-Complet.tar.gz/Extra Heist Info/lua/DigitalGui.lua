local EHI = EHI
if EHI:CheckLoadHook("DigitalGui") or not EHI:GetTrackerWaypointHudlistOption("show_timers", "show_waypoints_timers", "show_timers") then
    return
end

---@class DigitalGui
---@field _unit UnitDigitalTimer
---@field _visible boolean
---@field _timer number
---@field _timer_count_down boolean
---@field _timer_paused boolean
---@field is_timer fun(self: self): boolean

local Icon = EHI.Icons

DigitalGui.__EHI_SHOW_TRACKER, DigitalGui.__EHI_SHOW_WAYPOINT, DigitalGui.__EHI_SHOW_HUDLIST = EHI:GetShowTrackerWaypointAndHudlist("show_timers", "show_waypoints_timers", "show_timers")

local original =
{
    init = DigitalGui.init,
    _update_timer_text = DigitalGui._update_timer_text,
    timer_start_count_down = DigitalGui.timer_start_count_down,
    timer_pause = DigitalGui.timer_pause,
    timer_resume = DigitalGui.timer_resume,
    _timer_stop = DigitalGui._timer_stop,
    set_visible = DigitalGui.set_visible,
    timer_set = DigitalGui.timer_set,
    load = DigitalGui.load
}
local level_id = Global.game_settings.level_id

---@param unit UnitDigitalTimer
function DigitalGui:init(unit, ...)
    original.init(self, unit, ...)
    self._ehi_key = tostring(unit:key())
    if self:is_timer() then
        if self.__EHI_SHOW_TRACKER then
            EHI:OptionAndLoadTracker("show_timers")
        end
        if self.__EHI_SHOW_WAYPOINT then
            EHI:OptionAndLoadWaypoint("show_timers")
        end
    end
end

function DigitalGui:TimerStartCountDown()
    if (self._ignore or not self._visible) and not self._ignore_visibility or self._timer <= 0 then
        return
    elseif managers.ehi_timer:TimerExists(self._ehi_key) or managers.ehi_hudlist:ReturnLeftListItemValue("Timer", "TimerExists", self._ehi_key) then
        managers.ehi_timer:SetJammed(self._ehi_key, false)
        managers.ehi_hudlist:CallLeftListItemFunction("Timer", "SetJammed", self._ehi_key, false)
        return
    end
    if self.__EHI_SHOW_TRACKER then
        managers.ehi_timer:StartTimer({
            id = self._ehi_key,
            key = self._ehi_key,
            time = self._timer,
            icons = self._icons or { Icon.PCHack },
            warning = self._warning,
            completion = self._completion,
            hint = self._ehi_hint or "timelock",
            group = "timer",
            class = EHI.Trackers.Timer.Base
        })
    end
    if self.__EHI_SHOW_WAYPOINT and not self._ignore_waypoint then
        managers.ehi_waypoint:AddWaypoint(self._ehi_key, {
            time = self._timer,
            icon = self._icons or Icon.PCHack,
            position = self._unit:position(),
            warning = self._warning,
            completion = self._completion,
            class = "EHITimerWaypoint"
        })
    end
    if self.__EHI_SHOW_HUDLIST then
        managers.ehi_hudlist:CallLeftListItemFunction("Timer", "AddTimer", {
            id = self._ehi_key,
            time = self._timer,
            icon = self._icons or Icon.PCHack,
            hint = self._ehi_hint or "timelock"
        })
    end
    self:HideWaypoint()
end

function DigitalGui:HideWaypoint()
    if self._remove_vanilla_waypoint and self.__EHI_SHOW_WAYPOINT then
        managers.hud:RemoveTimerWaypoint(self._remove_vanilla_waypoint)
    end
end

function DigitalGui:timer_start_count_down(...)
    original.timer_start_count_down(self, ...)
    self:TimerStartCountDown()
end

if level_id == "shoutout_raid" then
    local old_time = 0
    ---@param timer number
    function DigitalGui:timer_set(timer, ...)
        original.timer_set(self, timer, ...)
        if old_time == timer then
            return
        elseif old_time == 0 then
            if self.__EHI_SHOW_TRACKER then
                managers.ehi_tracker:AddTracker({
                    id = self._ehi_key,
                    hint = "timer",
                    class = "EHIVaultTemperatureTracker"
                })
            end
            if self.__EHI_SHOW_WAYPOINT then
                managers.ehi_waypoint:AddWaypoint(self._ehi_key, {
                    time = 500,
                    icon = Icon.Vault,
                    position = self._unit:position(),
                    class = "EHIVaultTemperatureWaypoint"
                })
            end
            if self.__EHI_SHOW_HUDLIST then
                managers.ehi_hudlist:CallLeftListItemFunction("Timer", "AddVaultTimer", self._ehi_key)
            end
        end
        old_time = timer
        local t = math.ehi_round(timer, 0.1)
        managers.ehi_tracking:Call(self._ehi_key, "CheckTime", t)
        managers.ehi_hudlist:CallLeftListItemFunction("Timer", "CheckTime", self._ehi_key, t)
    end
else
    if DigitalGui.__EHI_SHOW_TRACKER and DigitalGui.__EHI_SHOW_WAYPOINT and DigitalGui.__EHI_SHOW_HUDLIST then
        function DigitalGui:_update_timer_text(...)
            managers.ehi_timer:UpdateTimer(self._ehi_key, self._timer)
            managers.ehi_hudlist:CallLeftListItemFunction("Timer", "UpdateTimer", self._ehi_key, self._timer)
            original._update_timer_text(self, ...)
        end
    elseif DigitalGui.__EHI_SHOW_TRACKER and DigitalGui.__EHI_SHOW_WAYPOINT then
        function DigitalGui:_update_timer_text(...)
            managers.ehi_timer:UpdateTimer(self._ehi_key, self._timer)
            original._update_timer_text(self, ...)
        end
    elseif DigitalGui.__EHI_SHOW_TRACKER and DigitalGui.__EHI_SHOW_HUDLIST then
        function DigitalGui:_update_timer_text(...)
            managers.ehi_timer:SetTimerTime(self._ehi_key, self._timer)
            managers.ehi_hudlist:CallLeftListItemFunction("Timer", "UpdateTimer", self._ehi_key, self._timer)
            original._update_timer_text(self, ...)
        end
    elseif DigitalGui.__EHI_SHOW_WAYPOINT and DigitalGui.__EHI_SHOW_HUDLIST then
        function DigitalGui:_update_timer_text(...)
            managers.ehi_waypoint:SetTime(self._ehi_key, self._timer)
            managers.ehi_hudlist:CallLeftListItemFunction("Timer", "UpdateTimer", self._ehi_key, self._timer)
            original._update_timer_text(self, ...)
        end
    elseif DigitalGui.__EHI_SHOW_WAYPOINT then
        function DigitalGui:_update_timer_text(...)
            managers.ehi_waypoint:SetTime(self._ehi_key, self._timer)
            original._update_timer_text(self, ...)
        end
    elseif DigitalGui.__EHI_SHOW_TRACKER then
        function DigitalGui:_update_timer_text(...)
            managers.ehi_timer:SetTimerTime(self._ehi_key, self._timer)
            original._update_timer_text(self, ...)
        end
    else
        function DigitalGui:_update_timer_text(...)
            managers.ehi_hudlist:CallLeftListItemFunction("Timer", "UpdateTimer", self._ehi_key, self._timer)
            original._update_timer_text(self, ...)
        end
    end
    ---@param timer number
    function DigitalGui:timer_set(timer, ...)
        original.timer_set(self, timer, ...)
        managers.ehi_timer:SetTimerTime(self._ehi_key, timer)
        managers.ehi_waypoint:SetTime(self._ehi_key, timer)
        managers.ehi_hudlist:CallLeftListItemFunction("Timer", "UpdateTimer", self._ehi_key, timer)
    end
end

if level_id == "chill" then
    original.timer_start_count_up = DigitalGui.timer_start_count_up
    function DigitalGui:timer_start_count_up(...)
        original.timer_start_count_up(self, ...)
        if managers.ehi_tracker:CallFunction2(self._ehi_key, "Reset") then
            managers.ehi_tracker:AddTracker({
                id = self._ehi_key,
                time = 0,
                class = "EHIStopwatchTracker",
                hint = "timer"
            })
        end
    end

    function DigitalGui:timer_pause(...)
        original.timer_pause(self, ...)
        managers.ehi_tracker:CallFunction(self._ehi_key, "Stop")
    end
else
    function DigitalGui:timer_pause(...)
        original.timer_pause(self, ...)
        if self._remove_on_pause then
            self:RemoveTracker()
        else
            managers.ehi_timer:SetJammed(self._ehi_key, true)
            managers.ehi_hudlist:CallLeftListItemFunction("Timer", "SetJammed", self._ehi_key, true)
            if self._icon_on_pause then
                managers.ehi_tracking:SetIcon(self._ehi_key, self._icon_on_pause)
                managers.ehi_hudlist:CallLeftListItemFunction("Timer", "UpdateIcon", self._ehi_key, self._icon_on_pause)
            end
        end
    end
end

function DigitalGui:timer_resume(...)
    original.timer_resume(self, ...)
    managers.ehi_timer:SetJammed(self._ehi_key, false)
    managers.ehi_hudlist:CallLeftListItemFunction("Timer", "SetJammed", self._ehi_key, false)
end

function DigitalGui:_timer_stop(...)
    original._timer_stop(self, ...)
    self:RemoveTracker()
end

---@param visible boolean
function DigitalGui:set_visible(visible, ...)
    original.set_visible(self, visible, ...)
    if not visible then
        self:RemoveTracker()
    elseif self._timer_count_down then
        self:TimerStartCountDown()
    end
end

function DigitalGui:RemoveTracker()
    managers.ehi_timer:RemoveTimer(self._ehi_key)
    managers.ehi_hudlist:CallLeftListItemFunction("Timer", "RemoveTimer", self._ehi_key)
end

---@param data table
function DigitalGui:load(data, ...)
    local state = data.DigitalGui
    if self:is_timer() and state.timer_count_down then
        self:TimerStartCountDown()
        if state.timer_paused then
            managers.ehi_timer:SetJammed(self._ehi_key, true)
        end
    end
    original.load(self, data, ...) -- Timer's time is updated in the Vanilla function
end

function DigitalGui:OnAlarm()
    self._ignore = true
    self:RemoveTracker()
end

---@param icons table?
function DigitalGui:SetIcons(icons)
    if (icons and not self._icons) or icons then
        self._icons = icons
    end
end

---@param icon string
function DigitalGui:SetIconOnPause(icon)
    self._icon_on_pause = icon
end

function DigitalGui:SetIgnore()
    self._ignore = true
end

---@param remove_on_pause boolean
function DigitalGui:SetRemoveOnPause(remove_on_pause)
    self._remove_on_pause = remove_on_pause
end

function DigitalGui:SetOnAlarm()
    EHI:AddOnAlarmCallback(callback(self, self, "OnAlarm"))
end

---@param waypoint_id number
function DigitalGui:RemoveVanillaWaypoint(waypoint_id)
    self._remove_vanilla_waypoint = waypoint_id
    if self._timer_count_down then
        self:HideWaypoint()
    end
end

---@param id number|string
---@param operation string
function DigitalGui:SetCustomCallback(id, operation)
    if operation == "remove" then
        EHI:AddCallback(id, callback(self, self, "OnAlarm"))
    end
end

---@param warning boolean
function DigitalGui:SetWarning(warning)
    self._warning = warning
    if self._timer_count_down and warning then
        managers.ehi_tracker:CallFunction(self._ehi_key, "SetAnimation", false, self._ehi_key)
    end
end

---@param completion boolean
function DigitalGui:SetCompletion(completion)
    self._completion = completion
    if self._timer_count_down and completion then
        managers.ehi_tracker:CallFunction(self._ehi_key, "SetAnimation", true, self._ehi_key)
    end
end

function DigitalGui:SetIgnoreVisibility()
    self._ignore_visibility = true
end

---@param hint string
function DigitalGui:SetHint(hint)
    self._ehi_hint = hint
    managers.ehi_tracker:UpdateHint(self._ehi_key, hint)
    managers.ehi_hudlist:CallLeftListItemFunction("Timer", "UpdateHint", self._ehi_key, hint)
end

function DigitalGui:SetIgnoreWaypoint()
    self._ignore_waypoint = true
    managers.ehi_waypoint:RemoveWaypoint(self._ehi_key)
end

function DigitalGui:Finalize()
    if self._ignore or (self._remove_on_pause and self._timer_paused) then
        self:RemoveTracker()
    elseif self._icon_on_pause and self._timer_paused then
        managers.ehi_tracking:SetIcon(self._ehi_key, self._icon_on_pause)
        managers.ehi_hudlist:CallLeftListItemFunction("Timer", "UpdateIcon", self._ehi_key, self._icon_on_pause)
    elseif self._icons then
        managers.ehi_tracking:SetIcon(self._ehi_key, self._icons[1])
        managers.ehi_hudlist:CallLeftListItemFunction("Timer", "UpdateIcon", self._ehi_key, self._icons[1])
    end
end