local EHI = EHI
if EHI:CheckHook("MenuManager") then
    return
end

---@type FakeEHITrackerManager, FakeEHIBuffsManager, FakeEHIHudlistManager, Panel
local tracker_preview, buff_preview, hudlist_preview, ehi_panel
local cache = {}
---@param show boolean
local function ShowOrHideMenuStuff(show)
    local menu_component = managers.menu_component
    local blt_notifications = menu_component:blt_notifications_gui()
    if blt_notifications then
        blt_notifications._panel:set_visible(show)
        if blt_notifications._beardlib_panel then
            blt_notifications._beardlib_panel:set_visible(show)
        end
    end
    local player_profile_gui = menu_component._player_profile_gui
    if player_profile_gui and player_profile_gui._panel then
        player_profile_gui._panel:set_visible(show)
    end
    if PocoHud3 and PocoHud3.dbgLbl and (not cache._poco_time_lock or (cache._poco_time_lock and show)) then
        if show then
            PocoHud3.dbgLbl:set_visible(cache._poco_time_visibility)
            cache._poco_time_visibility = nil
            cache._poco_time_lock = nil
        else
            cache._poco_time_lock = true
            cache._poco_time_visibility = PocoHud3.dbgLbl:visible()
            PocoHud3.dbgLbl:hide()
        end
    end
    local contract_gui = menu_component._contract_gui -- Lobby
    if contract_gui then
        contract_gui._panel:set_visible(show)
        contract_gui._fullscreen_panel:set_visible(show)
    end
    local game_chat_gui = menu_component._game_chat_gui -- Lobby
    if game_chat_gui then
        game_chat_gui._hud_panel:set_visible(show)
    end
    local crime_spree_missions = menu_component._crime_spree_missions -- Lobby
    if crime_spree_missions then
        crime_spree_missions._panel:set_visible(show)
        crime_spree_missions._fullscreen_panel:set_visible(show)
    end
    local crime_spree_details = menu_component._crime_spree_details -- Lobby
    if crime_spree_details then
        crime_spree_details._panel:set_visible(show)
        crime_spree_details._fullscreen_panel:set_visible(show)
        crime_spree_details._ws:panel():set_visible(show) -- WalletGuiObject
    end
    local ingame_contract = menu_component._ingame_contract_gui
    if ingame_contract then
        -- If the ingame contract gui exists, hide the entire Workspace because the panel gets recreated everytime player visits a menu/sub-menu
        if show then
            menu_component._ws:show()
        else
            menu_component._ws:hide()
        end
    end
    ehi_panel:set_visible(not show)
end

---@param compare { comparator: string, value: integer }
---@param value boolean|integer|"on"|"off"
---@param type string?
local function check_value(compare, value, type)
    if type == "toggle" then
        value = value == "on"
    end
    local result = true
    local comparator = compare.comparator or "=="
    local value_to_compare = compare.value
    if comparator == "==" then
        result = value == value_to_compare
    elseif comparator == "<" then
        result = value < value_to_compare
    elseif comparator == "<=" then
        result = value <= value_to_compare
    elseif comparator == ">" then
        result = value > value_to_compare
    elseif comparator == ">=" then
        result = value >= value_to_compare
    elseif comparator == "<>" then
        result = value ~= value_to_compare
    end
    return result
end

---Copy of BLT's MenuHelper with EHI specific changes  
---Loads a json-formatted text file and automatically parses and converts into a usable menu
---@param content table Path of the file to load and convert into a menu
---@param data_table table? Table containing the data keys which various menu items can load their value from
local function CreateMenuFromJson(content, data_table)
    local menu_id = content.menu_id
    local parent_menu = content.parent_menu_id
    local items = content.items
    local menu_priority = content.priority or nil

    -- 1.
    Hooks:Add("MenuManagerSetupCustomMenus", "Base_SetupCustomMenus_Json_" .. menu_id, function(menu_manager, nodes)
        MenuHelper:NewMenu(menu_id)
    end)

    -- 3.
    Hooks:Add("MenuManagerBuildCustomMenus","Base_BuildCustomMenus_Json_" .. menu_id, function(menu_manager, nodes)
        local data = {
            focus_changed_callback = content.focus_changed_callback,
            back_callback = content.back_callback,
            area_bg = content.area_bg
        }
        nodes[menu_id] = MenuHelper:BuildMenu(menu_id, data)

        if menu_priority ~= nil then
            for k, v in pairs(nodes[parent_menu]._items) do
                if menu_priority > (v._priority or 0) then
                    menu_priority = k
                    break
                end
            end
        end

        if menu_id == "ehi_menu" then
            MenuHelper:AddMenuItem(nodes[parent_menu], menu_id, content.title, content.description, menu_priority)
        end
    end)

    -- 2.
    Hooks:Add("MenuManagerPopulateCustomMenus","Base_PopulateCustomMenus_Json_" .. menu_id, function(menu_manager, nodes)
        local all_items = #items
        local previous_items = {} ---@type table<string, CoreMenuItemToggle.ItemToggle, CoreMenuItemSlider.ItemSlider, MenuItemMultiChoice>
        for k, item in ipairs(items) do
            local menu_item
            if item.vr then
                item = _G.IS_VR and item.vr[1] or item.vr[2]
            end
            local i_type = item.type
            local id = item.id
            local title = item.title
            local desc = item.description
            local callback = item.callback
            local priority = item.priority or all_items - k
            local value = item.default_value
            local localized = item.localized
            local disabled = item.disabled
            if data_table and data_table[item.value] ~= nil then
                value = data_table[item.value]
            end
            if item.disabled_from_start and MenuCallbackHandler then
                disabled = not _G.callback(MenuCallbackHandler, MenuCallbackHandler, item.disabled_from_start)()
            end
            if i_type == "button" then
                menu_item = MenuHelper:AddButton({
                    id = id,
                    title = title,
                    desc = desc,
                    callback = callback,
                    next_node = item.next_menu or nil,
                    menu_id = menu_id,
                    priority = priority,
                    localized = localized,
                    disabled = disabled
                })
            elseif i_type == "toggle" then
                menu_item = MenuHelper:AddToggle({
                    id = id,
                    title = title,
                    desc = desc,
                    callback = callback,
                    value = value,
                    menu_id = menu_id,
                    priority = priority,
                    localized = localized,
                    disabled = disabled
                })
            elseif i_type == "slider" then
                menu_item = MenuHelper:AddSlider({
                    id = id,
                    title = title,
                    desc = desc,
                    callback = callback,
                    value = value,
                    min = item.min or 0,
                    max = item.max or 1,
                    step = item.step or 0.1,
                    show_value = true,
                    display_precision = item.display_precision,
                    display_scale = item.display_scale,
                    is_percentage = item.is_percentage,
                    menu_id = menu_id,
                    priority = priority,
                    localized = localized,
                    disabled = disabled
                })
            elseif i_type == "divider" then
                menu_item = MenuHelper:AddDivider({
                    id = "",
                    size = item.size,
                    title = title,
                    menu_id = menu_id,
                    priority = priority,
                    no_text = item.no_text
                })
                menu_item:set_parameter("color", Color.white)
            elseif i_type == "keybind" then
                local key = ""
                if item.keybind_id then
                    local mod = BLT.Mods:GetModOwnerOfFile(file_path)
                    if mod then
                        local params = {
                            id = item.keybind_id,
                            allow_menu = item.run_in_menu,
                            allow_game = item.run_in_game,
                            show_in_menu = item.show_in_menu,
                            name = title,
                            desc = desc,
                            localize = true,
                            callback = item.func and MenuCallbackHandler[item.func]
                        }
                        BLT.Keybinds:register_keybind(mod, params)
                    end
                    local bind = BLT.Keybinds:get_keybind(item.keybind_id)
                    key = bind and bind:Key() or ""
                end
                menu_item = MenuHelper:AddKeybinding({
                    id = id,
                    title = title,
                    desc = desc,
                    connection_name = item.keybind_id,
                    button = key,
                    binding = key,
                    menu_id = menu_id,
                    priority = priority,
                    localized = localized,
                    disabled = disabled
                })
            elseif i_type == "multiple_choice" or i_type == "multiple_color_choice" then
                local items_need_color = i_type == "multiple_color_choice"
                local choice_items = item.items
                if items_need_color then
                    if not cache.multiple_color_choice_items then
                        cache.multiple_color_choice_items = {
                            "ehi_buffs_group_color_white",
                            "ehi_buffs_group_color_red",
                            "ehi_buffs_group_color_orange",
                            "ehi_buffs_group_color_green",
                            "ehi_buffs_group_color_yellow",
                            "ehi_buffs_group_color_blue",
                            "ehi_buffs_group_color_cyan",
                            "ehi_buffs_group_color_pink",
                            "ehi_buffs_group_color_purple",
                            "ehi_buffs_group_color_violet",
                            "ehi_buffs_group_color_magenta",
                            "ehi_buffs_group_color_azure",
                            "ehi_buffs_group_color_brown",
                            "ehi_buffs_group_color_crimson",
                            "ehi_buffs_group_color_salmon",
                            "ehi_buffs_group_color_gold",
                            "ehi_buffs_group_color_turquoise"
                        }
                    end
                    choice_items = cache.multiple_color_choice_items
                end
                menu_item = MenuHelper:AddMultipleChoice({
                    id = id,
                    title = title,
                    desc = desc,
                    callback = callback,
                    items = choice_items,
                    item_values = item.item_values,
                    value = value,
                    menu_id = menu_id,
                    priority = priority,
                    localized = localized,
                    localized_items = item.localized_items,
                    disabled = disabled
                })
                if items_need_color then
                    for _, option in ipairs(menu_item._all_options) do
                        local color, _ = tweak_data.ehi:GetBuffColorFromIndex(option:value())
                        option:parameters().color = color
                    end
                end
            elseif i_type == "color" then
                local default_value = item.default_value
                local settings_table = EHI.settings
                if item.params and (item.params.setting or item.params.settings) then
                    if item.params.setting then
                        value = settings_table[item.params.setting]
                    elseif item.params.settings then
                        for _, setting in ipairs(item.params.settings) do
                            settings_table = settings_table[setting]
                        end
                        value = settings_table
                    end
                elseif content.global_params then
                    if content.global_params.setting then
                        value = settings_table[content.global_params.setting]
                    elseif content.global_params.settings then
                        for _, setting in ipairs(content.global_params.settings) do
                            settings_table = settings_table[setting]
                        end
                        value = settings_table
                    end
                else -- If no load params exists
                    value = settings_table
                end
                value = value[item.value] or default_value
                local data =
                {
                    type = "EHIMenuItemColor",
                    {
                        _meta = "option",
                        text_id = "ehi_buffs_group_color_red",
                        name = "r",
                        value = value.r,
                        localize = true
                    },
                    {
                        _meta = "option",
                        text_id = "ehi_buffs_group_color_green",
                        name = "g",
                        value = value.g,
                        localize = true
                    },
                    {
                        _meta = "option",
                        text_id = "ehi_buffs_group_color_blue",
                        name = "b",
                        value = value.b,
                        localize = true
                    }
                }
                local params =
                {
                    name = id,
                    text_id = title,
                    help_id = desc,
                    callback = "ehi_modify_item_color",
                    localize = localized,
                    localize_help = localized,
                    default_color = default_value
                }
                local menu = MenuHelper:GetMenu(menu_id)
                menu_item = menu:create_item(data, params)
                menu_item:set_value(value)
                menu_item._priority = priority
                if disabled then
                    menu_item:set_enabled(false)
                end
                menu._items_list = menu._items_list or {}
                table.insert(menu._items_list, menu_item)
            end
            if menu_item and id then -- Dividers do not have ID assigned
                previous_items[id] = menu_item ---@diagnostic disable-line
                if item.value then
                    menu_item:set_parameter("option", item.value)
                end
                if item.params or content.global_params then
                    for key, param_value in pairs(item.params or content.global_params) do
                        menu_item:set_parameter(key, param_value)
                    end
                end
                if content.global_params then
                    for key, param_value in pairs(content.global_params) do
                        if not menu_item:parameter(key) then
                            menu_item:set_parameter(key, param_value)
                        end
                    end
                end
                if item.child then
                    menu_item:set_parameter("child", item.child)
                elseif item.children then
                    menu_item:set_parameter("children", item.children)
                end
                if item.children_f then
                    menu_item:set_parameter("children_f", item.children_f)
                end
                if item.children_f_or then
                    menu_item:set_parameter("children_f_or", item.children_f_or)
                end
                if item.child_compare then
                    menu_item:set_parameter("child_compare", item.child_compare)
                end
                if item.parent and previous_items[item.parent] then
                    menu_item:set_enabled(previous_items[item.parent]:value() == "on")
                end
                if item.parent_compare and item.parent_compare.id and previous_items[item.parent_compare.id] then
                    local data = item.parent_compare
                    local parent = previous_items[data.id]
                    local result = check_value(data, parent:value(), parent:type())
                    if data.enabled then
                        result = result and parent:enabled()
                    end
                    menu_item:set_enabled(result)
                elseif item.parents_compare then
                    local final_result = true
                    if item.parents_compare.comparator == "and" then
                        for key, data in pairs(item.parents_compare.items) do
                            local parent = previous_items[key]
                            if parent and not check_value(data, parent:value(), parent:type()) then
                                final_result = false
                                break
                            end
                        end
                    else -- or
                        final_result = false
                        for key, data in pairs(item.parents_compare.items) do
                            local parent = previous_items[key]
                            if parent and check_value(data, parent:value(), parent:type()) then
                                final_result = true
                                break
                            end
                        end
                    end
                    menu_item:set_enabled(final_result)
                end
                if item.other_item_compare and item.other_item_compare.id and previous_items[item.other_item_compare.id] then
                    local data = item.other_item_compare
                    previous_items[data.id]:set_enabled(check_value(data, value))
                end
                if item.other_items_compare then
                    for o_id, data in pairs(item.other_items_compare) do
                        previous_items[o_id]:set_enabled(check_value(data, value))
                    end
                end
            end
        end
    end)
end

---@param file_path string Path of the file to load and convert into a menu
---@param data_table table? Table containing the data keys which various menu items can load their value from
local function LoadMenusFromJsonFile(file_path, data_table)
    local file = io.open(file_path, "r")
    if file then
        local file_content = file:read("*all")
        file:close()
        for _, content in ipairs(json.decode(file_content)) do
            local data = data_table
            if content.global_params and (content.global_params.setting or content.global_params.settings) and data then
                if content.global_params.setting then
                    data = data[content.global_params.setting]
                else
                    for _, setting in ipairs(content.global_params.settings) do
                        data = data[setting]
                    end
                end
            end
            CreateMenuFromJson(content, data)
        end
    else
        BLT:Log(LogLevel.ERROR, string.format("Could not load file '%s'", file_path))
    end
end

---@param file_path string Path of the file to load and convert into a menu
---@param data_table table? Table containing the data keys which various menu items can load their value from
local function LoadFromJsonFile(file_path, data_table)
    local file = io.open(file_path, "r")
    if file then
        local file_content = file:read("*all")
        file:close()
        CreateMenuFromJson(json.decode(file_content), data_table)
    else
        BLT:Log(LogLevel.ERROR, string.format("Could not load file '%s'", file_path))
    end
end

local Languages =
{
    [2] = "english",
    [3] = "czech",
    [4] = "french",
    [5] = "italian",
    [6] = "russian",
    [7] = "thai",
    [8] = "schinese",
    [9] = "portuguese", -- Brazil
    [10] = "spanish",
    [11] = "japanese"
}

Hooks:Add("LocalizationManagerPostInit", "LocalizationManagerPostInit_EHI", function(loc) ---@param loc BLTLocalizationManager
    local language_filename = nil
    local lang = EHI:GetOption("mod_language")
    local LocPath = EHI.ModPath .. "loc/"
    if lang == 1 then -- Autodetect
        local LanguageKey =
        {
            ["PAYDAY 2 THAI LANGUAGE Mod"] = "thai",
            --["Ultimate Localization Manager & 正體中文化"] = "tchinese",
            --["Payday 2 Korean patch"] = "korean"
        }
        for _, mod in ipairs(BLT and BLT.Mods and BLT.Mods:Mods() or {}) do
            language_filename = mod:IsEnabled() and LanguageKey[mod:GetName()]
            if language_filename then
                break
            end
        end
        if not language_filename then
            for _, filename in ipairs(file.GetFiles(LocPath)) do
                local str = filename:match('^(.*).json$')
                if str and Idstring(str) and Idstring(str):key() == SystemInfo:language():key() then
                    language_filename = str
                    break
                end
            end
        end
        if language_filename then
            loc:load_localization_file(LocPath .. language_filename .. ".json")
        end
    else
        loc:load_localization_file(LocPath .. Languages[lang] .. ".json")
    end
    if lang ~= 2 or not language_filename then
        loc:load_localization_file(LocPath .. "english.json", false)
    end
    loc:load_localization_file(LocPath .. "languages.json")
    local shared_decks =
    {
        overdog_decks_1 = { "overdog_damage_reduction", "overdog_damage_reduction_persistent" },
        overdog_decks_2 = { "overdog_melee_swings", "overdog_melee_swings_persistent" }
    }
    for deck, perks in pairs(shared_decks) do
        local decks = loc:text(string.format("ehi_buffs_perks_shared_%s", deck))
        for i, perk in ipairs(perks) do
            loc._custom_localizations[string.format("ehi_buffs_perks_shared_%s_final", perk)] = string.format("%s\n%s", loc:text(i % 2 == 0 and "ehi_buffs_skills_permanent" or "ehi_buffs_skills_duration"), decks)
        end
    end
    EHI:RunOnLocalizationLoaded(loc, Languages[lang] or language_filename or "english")
end)

Hooks:Add("MenuManagerInitialize", "MenuManagerInitialize_EHI", function(menu_manager) ---@param menu_manager MenuManager
    LoadFromJsonFile(EHI.MenuPath .. "menu.json", EHI.settings)
    LoadFromJsonFile(EHI.MenuPath .. "trackers.json", EHI.settings)
    LoadFromJsonFile(EHI.MenuPath .. "equipment.json", EHI.settings)
    LoadFromJsonFile(EHI.MenuPath .. "unlockables.json", EHI.settings.unlockables)
    LoadFromJsonFile(EHI.MenuPath .. "visuals.json", EHI.settings)
    LoadFromJsonFile(EHI.MenuPath .. "waypoints.json", EHI.settings)
    LoadFromJsonFile(EHI.MenuPath .. "shared.json", EHI.settings)
    LoadFromJsonFile(EHI.MenuPath .. "buffs.json", EHI.settings)
    LoadMenusFromJsonFile(EHI.MenuPath .. "buff_options/skills.json", EHI.settings)
    LoadMenusFromJsonFile(EHI.MenuPath .. "buff_options/perks.json", EHI.settings)
    LoadFromJsonFile(EHI.MenuPath .. "buff_options/other.json", EHI.settings.buff_option)
    LoadFromJsonFile(EHI.MenuPath .. "buff_options/group.json", EHI.settings.buff_option.group)
    LoadFromJsonFile(EHI.MenuPath .. "hudlist.json", EHI.settings.hudlist)
    LoadFromJsonFile(EHI.MenuPath .. "hudlist_options/left_list.json", EHI.settings.hudlist.left_list)
    LoadFromJsonFile(EHI.MenuPath .. "hudlist_options/right_list.json", EHI.settings.hudlist.right_list)
    LoadFromJsonFile(EHI.MenuPath .. "hudlist_options/right_list_unit_types.json", EHI.settings.hudlist.right_list.unit_types)
    LoadFromJsonFile(EHI.MenuPath .. "hudlist_options/right_list_unit_types_dozer.json", EHI.settings.hudlist.right_list.unit_types)
    LoadFromJsonFile(EHI.MenuPath .. "hudlist_options/right_list_special_types.json", EHI.settings.hudlist.right_list.special_items_type)
    LoadFromJsonFile(EHI.MenuPath .. "inventory.json", EHI.settings)
    LoadFromJsonFile(EHI.MenuPath .. "other.json", EHI.settings)
    local main_menu = menu_manager:get_menu(menu_manager._is_start_menu and "menu_main" or "menu_pause")
    if main_menu then
        local node = CoreMenuNode.MenuNode:new({
            gui_class = "EHIMenuNodeCustomizeGadgetGui",
            modifier = "EHIMenuSetColorInitiator",
            refresh = "EHIMenuSetColorInitiator"
        })
        node:set_callback_handler(MenuCallbackHandler:new())
        main_menu.data._nodes.ehi_color_select = node
    else
        EHI:Log("!!!!!!!!!!!!!!! Main Menu does not exist !!!!!!!!!!!!!!!")
    end
end)

---@param item MenuItemMultiChoice|CoreMenuItemSlider.ItemSlider|CoreMenuItemToggle.ItemToggle
function MenuCallbackHandler:ehi_set_item_value(item)
    local params, type = item:parameters(), item:type()
    local value
    if type == "slider" then ---@cast item CoreMenuItemSlider.ItemSlider
        value = tonumber(item:raw_value_string())
    elseif type == "toggle" then ---@cast item CoreMenuItemToggle.ItemToggle
        value = item:value() == "on"
    else ---@cast item MenuItemMultiChoice
        value = item:value()
    end
    local settings_table = EHI.settings
    if params.setting then
        settings_table = settings_table[params.setting]
    elseif params.settings then
        for _, setting in ipairs(params.settings) do
            settings_table = settings_table[setting]
        end
    end
    settings_table[params.option] = value
    if params.call_tracker_function and (params.call_tracker_function.update_trackers or params.call_tracker_function.custom_f or tracker_preview[params.call_tracker_function.f]) then
        if params.call_tracker_function.update_trackers then
            tracker_preview:UpdateTracker(params.call_tracker_function.update_trackers.id, check_value(params.call_tracker_function.update_trackers.compare, value --[[@as integer]]))
        elseif params.call_tracker_function.custom_f then
            tracker_preview:CallFunction(params.call_tracker_function.id, params.call_tracker_function.custom_f, value)
        elseif params.call_tracker_function.params then
            tracker_preview[params.call_tracker_function.f](tracker_preview, value, unpack(params.call_tracker_function.params))
        else
            tracker_preview[params.call_tracker_function.f](tracker_preview, value)
        end
    end
    if params.call_buff_function and buff_preview[params.call_buff_function.f] then
        if params.call_buff_function.params then
            buff_preview[params.call_buff_function.f](buff_preview, unpack(params.call_buff_function.params), value)
        else
            buff_preview[params.call_buff_function.f](buff_preview, value)
        end
    end
    if params.call_hudlist_function and (params.call_hudlist_function.custom_f or hudlist_preview[params.call_hudlist_function.f]) then
        if params.call_hudlist_function.custom_f then
            local custom_f = params.call_hudlist_function.custom_f
            if custom_f.list == "left" then
                hudlist_preview._left_list:CallItemFunction(custom_f.id, custom_f.f, value, custom_f.arg)
            elseif custom_f.list == "right" then
                hudlist_preview._right_list:CallItemFunction(custom_f.id, custom_f.f, value, custom_f.arg)
            end
        elseif params.call_hudlist_function.params then
            hudlist_preview[params.call_hudlist_function.f](hudlist_preview, value, unpack(params.call_hudlist_function.params))
        else
            hudlist_preview[params.call_hudlist_function.f](hudlist_preview, value)
        end
    end
    if params.child then
        for _, row_item in ipairs(params.gui_node.row_items) do
            if row_item.name == params.child then
                row_item.item:set_enabled(value)
                break
            end
        end
    elseif params.children then
        local children = table.list_to_set(params.children)
        for _, row_item in ipairs(params.gui_node.row_items) do
            if children[row_item.name] then
                row_item.item:set_enabled(value)
            end
        end
    end
    if params.child_compare then
        local compare = params.child_compare
        for _, row_item in ipairs(params.gui_node.row_items) do
            local data = compare[row_item.name]
            if data and data.value then
                row_item.item:set_enabled(check_value(data, value --[[@as integer]]))
            end
        end
    end
    if params.children_f then
        for name, f in pairs(params.children_f) do
            for _, row_item in ipairs(params.gui_node.row_items) do
                if row_item.name == name and MenuCallbackHandler[f] then
                    row_item.item:set_enabled(value and MenuCallbackHandler[f]())
                    break
                end
            end
        end
    end
    if params.children_f_or then
        for name, f in pairs(params.children_f_or) do
            for _, row_item in ipairs(params.gui_node.row_items) do
                if row_item.name == name and MenuCallbackHandler[f] then
                    row_item.item:set_enabled(value or MenuCallbackHandler[f]())
                    break
                end
            end
        end
    end
    cache.setting_changed = true
end

---@param item EHIMenuItemColor
function MenuCallbackHandler:ehi_modify_item_color(item)
    managers.menu:open_node("ehi_color_select", { { item = item } })
    managers.menu_component:post_event("menu_enter")
end

function MenuCallbackHandler:ehi_set_item_color()
    local menu = managers.menu:active_menu()
    if not menu then
        return
    end
    if not menu.logic then
        return
    end
    if not menu.logic:selected_node() then
        return
    end
    local color, item = nil, nil
    local active_node_gui = menu.renderer:active_node_gui()
    if active_node_gui and active_node_gui.update_node_colors then
        color = active_node_gui:update_node_colors()
        item = active_node_gui.node:parameters().menu_component_data.item
    end
    if item and color then
        item:set_value(color)
        local params = item:parameters()
        local settings_table = EHI.settings
        if params.setting then
            settings_table = settings_table[params.setting]
        elseif params.settings then
            for _, setting in ipairs(params.settings) do
                settings_table = settings_table[setting]
            end
        end
        settings_table = settings_table[params.option]
        settings_table.r = color.r
        settings_table.g = color.g
        settings_table.b = color.b
        if params.call_tracker_function then
            tracker_preview:CallFunction(params.call_tracker_function.tracker or params.option, params.call_tracker_function.f, Color(255, color.r, color.g, color.b) / 255)
        elseif params.call_hudlist_function then
            if params.call_hudlist_function.custom_f then
                if params.call_hudlist_function.custom_f.list == "left" then
                    hudlist_preview._left_list:CallItemFunction(params.call_hudlist_function.custom_f.id, params.call_hudlist_function.custom_f.f, EHI:GetColor(color))
                elseif params.call_hudlist_function.custom_f.list == "right" then
                    hudlist_preview._right_list:CallItemFunction(params.call_hudlist_function.custom_f.id, params.call_hudlist_function.custom_f.f, EHI:GetColor(color), params.call_hudlist_function.custom_f.arg)
                end
            else
                hudlist_preview:CallListFunction(color, params.call_hudlist_function.list, params.call_hudlist_function.f)
            end
        end
        cache.setting_changed = true
    end
    managers.menu:back()
end

function MenuCallbackHandler.ehi_changed_focus(node, focus)
    if not ehi_panel then
        local AspectRatio = tweak_data.ehi.shared.AspectRatio
        local aspect_ratio = RenderSettings.resolution.x / RenderSettings.resolution.y
        local _1_33 = 4 / 3
        local AspectRatioEnum, ws, layer
        if aspect_ratio == 1.6 or aspect_ratio == _1_33 then -- 16:10 or 4:3
            AspectRatioEnum = aspect_ratio == 1.6 and AspectRatio._16_10 or AspectRatio._4_3
            ws = managers.gui_data:create_fullscreen_16_9_workspace()
            if not managers.menu._is_start_menu then
                layer = tweak_data.gui.MENU_COMPONENT_LAYER + 1
            end
        else
            AspectRatioEnum = AspectRatio.Other
            ws = managers.gui_data:create_fullscreen_workspace()
            if not managers.menu._is_start_menu then
                layer = tweak_data.gui.MENU_COMPONENT_LAYER + 1
            end
        end
        ehi_panel = ws:panel():panel()
        if layer then
            ehi_panel:set_layer(layer)
        end
        tracker_preview = FakeEHITrackerManager:new(ehi_panel, AspectRatioEnum)
        buff_preview = FakeEHIBuffsManager:new(ehi_panel)
        hudlist_preview = FakeEHIHudlistManager:new(ehi_panel, AspectRatioEnum)
    end
    if focus then
        ShowOrHideMenuStuff(false)
    end
end

function MenuCallbackHandler.ehi_is_classic_heisting_mod_installed()
    return _G.ch_settings == nil
end

---@param item CoreMenuItemToggle.ItemToggle
function MenuCallbackHandler:ehi_update_tracker_visibility(item)
    tracker_preview:Redraw()
end

function MenuCallbackHandler.ehi_is_shared_menu_available()
    return EHI:GetTrackerOrWaypointOption("show_mission_trackers", "show_waypoints_mission")
end

function MenuCallbackHandler.ehi_is_shared_menu_available_1()
    return EHI:GetOption("show_waypoints")
end

function MenuCallbackHandler.ehi_is_shared_menu_available_2()
    return EHI:GetOption("show_trackers")
end

function MenuCallbackHandler.ehi_are_assault_option_items_available()
    return EHI:GetOption("show_assault_delay_tracker") or EHI:GetOption("show_assault_time_tracker")
end

function MenuCallbackHandler.ehi_are_assault_option_items_available_1()
    return EHI:GetOption("show_assault_time_tracker")
end

function MenuCallbackHandler.ehi_are_assault_option_items_available_2()
    return EHI:GetOption("show_assault_delay_tracker")
end

---@param item CoreMenuItemToggle.ItemToggle
function MenuCallbackHandler:ehi_update_assault_tracker(item)
    local value = item:value() == "on"
    tracker_preview:CallFunction("assault", "UpdateInternalFormat", value, true)
    tracker_preview:CallFunction("show_assault_delay_tracker", "UpdateInternalFormat", value, true)
    tracker_preview:CallFunction("show_assault_time_tracker", "UpdateInternalFormat", value, true)
end

---@param item CoreMenuItemToggle.ItemToggle
function MenuCallbackHandler:ehi_update_assault_tracker_2(item)
    local value = item:value() == "on"
    tracker_preview:CallFunction("assault", "UpdateInternalFormat2", value, true)
    tracker_preview:CallFunction("show_assault_delay_tracker", "UpdateInternalFormat2", value, true)
    tracker_preview:CallFunction("show_assault_time_tracker", "UpdateInternalFormat2", value, true)
end

---@param item CoreMenuItemToggle.ItemToggle
function MenuCallbackHandler:ehi_preview_notification(item)
    local params = item:parameters()
    if params.n_class == "HudChallengeNotification" then
        if not HudChallengeNotification then
            require("lib/managers/hud/HudChallengeNotification")
        end
        HudChallengeNotification.queue(params.n_id, managers.localization:text(params.n_desc), params.n_icon) --- HUDManager does not exist in Menu, needs to be called directly
    end
end

function MenuCallbackHandler.ehi_hide_unlocked_achievements_available_1()
    return EHI:GetUnlockableOption("show_achievements_mission")
end

function MenuCallbackHandler.ehi_hide_unlocked_achievements_available_2()
    return EHI:GetUnlockableOption("show_achievements")
end

function MenuCallbackHandler.ehi_show_floating_health_bar_style_poco_blur_available_1()
    return EHI:GetOption("show_floating_health_bar_style") == 1 -- Poco style
end

function MenuCallbackHandler.ehi_show_floating_text_throwables_block_on_abilities_or_no_throwable_choice_1()
    return EHI:GetOption("show_floating_text_throwables")
end

function MenuCallbackHandler.ehi_show_floating_text_equipment_name_1()
    return not EHI:GetOption("show_floating_text_compact_mode")
end

function MenuCallbackHandler.ehi_show_floating_text_icon_and_equipment_name_2()
    return EHI:GetOption("show_floating_text") and not EHI:GetOption("show_floating_text_compact_mode")
end

function MenuCallbackHandler.ehi_show_floating_text_color_peer_equipment_choice_1()
    return EHI:GetOption("show_floating_text_icon")
end

function MenuCallbackHandler.ehi_left_list_progress_static_1()
    return EHI:GetHudlistOption("left_list_progress_visibility")
end

function MenuCallbackHandler.ehi_hudlist_left_list_show_deployables_aggregate_single_grenades_1()
    return EHI:GetHudlistListOption("left_list", "deployable_aggregate")
end

function MenuCallbackHandler.ehi_hudlist_left_list_show_deployables_grenades_block_on_ability_or_no_throwable_1()
    return EHI:GetHudlistListOption("left_list", "deployable_show_grenades")
end

function MenuCallbackHandler.ehi_right_list_progress_static_1()
    return EHI:GetHudlistOption("right_list_progress_visibility")
end

function MenuCallbackHandler:ehi_right_list_units_set_aggregated(item)
    local items_to_disable = {
        ehi_hudlist_right_list_unit_types_dozer_count_choice = true,
        ehi_hudlist_right_list_unit_types_sniper_count_choice = true,
        ehi_hudlist_right_list_unit_types_heavy_sniper_count_choice = true,
        ehi_hudlist_right_list_unit_types_marshal_sniper_count_choice = true,
        ehi_hudlist_right_list_unit_types_taser_count_choice = true,
        ehi_hudlist_right_list_unit_types_medic_count_choice = true,
        ehi_hudlist_right_list_unit_types_cloaker_count_choice = true,
        ehi_hudlist_right_list_unit_types_shield_count_choice = true,
        ehi_hudlist_right_list_unit_types_marshal_shield_count_choice = true,
        ehi_hudlist_right_list_unit_types_captain_count_choice = true,
        ehi_hudlist_right_list_unit_types_phalanx_count_choice = true,
        ehi_hudlist_right_list_unit_types_turret_count_choice = true
    }
    local items_to_enable = {
        ehi_hudlist_right_list_unit_types_converts_count_choice = true,
        ehi_hudlist_right_list_unit_types_enemy_tied_count_choice = true,
        ehi_hudlist_right_list_unit_types_civilian_count_choice = true,
        ehi_hudlist_right_list_unit_types_civilian_tied_count_choice = true
    }
    MenuHelper:ResetItemsToDefaultValue(item, items_to_disable, false)
    MenuHelper:ResetItemsToDefaultValue(item, items_to_enable, true)
end

function MenuCallbackHandler:ehi_right_list_units_set_all_units(item)
    local items_to_enable = {
        ehi_hudlist_right_list_unit_types_converts_count_choice = true,
        ehi_hudlist_right_list_unit_types_enemy_tied_count_choice = true,
        ehi_hudlist_right_list_unit_types_dozer_count_choice = true,
        ehi_hudlist_right_list_unit_types_dozer_count_separate_choice = true,
        ehi_hudlist_right_list_unit_types_sniper_count_choice = true,
        ehi_hudlist_right_list_unit_types_heavy_sniper_count_choice = true,
        ehi_hudlist_right_list_unit_types_marshal_sniper_count_choice = true,
        ehi_hudlist_right_list_unit_types_taser_count_choice = true,
        ehi_hudlist_right_list_unit_types_medic_count_choice = true,
        ehi_hudlist_right_list_unit_types_cloaker_count_choice = true,
        ehi_hudlist_right_list_unit_types_shield_count_choice = true,
        ehi_hudlist_right_list_unit_types_marshal_shield_count_choice = true,
        ehi_hudlist_right_list_unit_types_captain_count_choice = true,
        ehi_hudlist_right_list_unit_types_phalanx_count_choice = true,
        ehi_hudlist_right_list_unit_types_turret_count_choice = true,
        ehi_hudlist_right_list_unit_types_civilian_count_choice = true,
        ehi_hudlist_right_list_unit_types_civilian_tied_count_choice = true
    }
    MenuHelper:ResetItemsToDefaultValue(item, items_to_enable, true)
end

function MenuCallbackHandler.ehi_right_list_units_dozer_count_1()
    return not EHI:GetHudlistListOption("right_list", "unit_types").dozer_count_separate
end

function MenuCallbackHandler.ehi_right_list_units_dozer_count_2()
    return not MenuCallbackHandler.ehi_right_list_units_dozer_count_1()
end

function MenuCallbackHandler.ehi_right_list_loot_color_based_on_weight_1()
    return EHI:GetHudlistListOption("right_list", "loot_color_items_based_on_their_weight")
end

function MenuCallbackHandler:ehi_update_buff_text_color(item)
end

function MenuCallbackHandler:ehi_save(item)
    ShowOrHideMenuStuff(true)
    EHI:SaveOptions()
    if game_state_machine:verify_game_state(GameStateFilters.any_ingame) and cache.setting_changed and not cache.restart_required_acknowledged then
        cache.restart_required_acknowledged = true
        QuickMenu:new(
            managers.localization:text("ehi_mod_title"),
            managers.localization:text("ehi_level_restart_required"),
            {},
            true
        )
    end
end

local function CacheRank(self, ...)
    self.__ehi_rank = managers.experience:current_rank()
end
local function IncreaseRank(self, ...)
    local xp = managers.experience
    local current_rank = xp:current_rank()
    if self.__ehi_rank ~= current_rank then
        managers.ehi_experience:ExperienceReload(xp)
    end
    self.__ehi_rank = nil
end
EHI:PreHookAndHookWithID(MenuCallbackHandler, "_increase_infamous", "EHI_MenuCallbackHandler_increase_infamous", CacheRank, IncreaseRank)
EHI:PreHookAndHookWithID(MenuCallbackHandler, "_increase_infamous_with_prestige", "EHI_MenuCallbackHandler_increase_infamous_with_prestige", CacheRank, IncreaseRank)

if Global.load_level then
    Hooks:PreHook(MenuCallbackHandler, "_dialog_end_game_yes", "EHI_MenuCallbackHandler_dialog_end_game_yes", function(...)
        EHI:RunEndGameCallback(EHI.Const.GameEnd.Abort)
    end)
end