local EHI = EHI

---@class EHIBuffManager
local EHIBuffManager = {}
EHIBuffManager._sync_add_buff = "EHISyncAddBuff"
---@param hud HUDManager
---@param panel Panel
function EHIBuffManager:init_finalize(hud, panel)
    local tweak_data = tweak_data.ehi.default.buff
    self._buffs = {} ---@type table<string, EHIBuffTracker?>
    self._buffs_redirect = {} --- Do not run same functions twice or more times for the same buff from redirects
    self._update_buffs = setmetatable({}, { __mode = "k" }) ---@type table<string, EHIBuffTracker?>
    self._visible_buffs = setmetatable({}, { __mode = "k" }) ---@type table<string, EHIBuffTracker?>
    self._n_visible = 0
    self._x = EHI:GetOption(_G.IS_VR and "buffs_vr_x_offset" or "buffs_x_offset") --[[@as number]]
    local path = EHI.LuaPath .. "buffs/"
    dofile(path .. "EHIBuffTracker.lua")
    dofile(path .. "EHIGaugeBuffTracker.lua")
    dofile(path .. "EHIPermanentBuffTracker.lua")
    dofile(path .. "SimpleBuffEdits.lua")
    EHIBuffTracker._parent_class = self
    hud:AddEHIUpdator("EHI_Buff_Update", self)
    self._panel = panel:panel()
    local scale = EHI:GetOption("buffs_scale") --[[@as number]]
    local text_scale = EHI:GetOption("buffs_text_scale") --[[@as number]]
    local buff_y = EHI:GetOption(_G.IS_VR and "buffs_vr_y_offset" or "buffs_y_offset") --[[@as number]]
    local buff_w = tweak_data.size_w * scale
    local buff_h = tweak_data.size_h * scale
    self:_init_buffs(buff_y, buff_w, buff_h, scale, text_scale)
    self:_init_tag_team_buffs(buff_y, buff_w, buff_h, scale, text_scale)
    self:_init_buff_redirect()
    if EHI:GetOption("buffs_grouping") then
        self:_init_buff_group(buff_y, buff_w, buff_h, scale, text_scale)
    end
    self:_cleanup_unused_buff_classes()
    table.sort(self._skill_check_after_spawn or {}, function(a, b)
        return a._id:lower() < b._id:lower()
    end)
    EHI:AddOnSpawnedCallback(callback(self, self, "ActivateUpdatingBuffs"))
    EHI:AddEndGameCallback(function()
        self._update_buffs = {}
    end)
    local hide_buffs_in_custody = EHI:GetOption("buffs_hide_in_custody")
    EHI:AddOnCustodyCallback(function(custody_state)
        for id, buff in pairs(self._buffs) do
            if not self._buffs_redirect[id] then
                buff:SetCustodyState(custody_state)
            end
        end
        if hide_buffs_in_custody then
            self._panel:set_visible(not custody_state)
        end
    end)
    EHI:AddOnAlarmCallback(function(dropin)
        for id, buff in pairs(self._buffs) do
            if not self._buffs_redirect[id] then
                buff:SwitchToLoudMode()
            end
        end
    end)
    if EHI.IsClient then
        managers.ehi_sync:AddReceiveHook(self._sync_add_buff, function(data, sender)
            local tbl = json.decode(data)
            if tbl and tbl.id and tbl.t then -- Check if the synced data is valid
                self:AddBuff(tbl.id, tbl.t)
            end
        end)
    end
end

---@param buff_y number
---@param buff_w number
---@param buff_h number
---@param scale number
---@param text_scale number
function EHIBuffManager:_init_buffs(buff_y, buff_w, buff_h, scale, text_scale)
    local get_icon = tweak_data.ehi.default.buff.get_icon
    for id, buff in pairs(tweak_data.ehi.buff) do
        if buff.option and not EHI:GetBuffOption(buff.option) then
        elseif buff.deck_option and not EHI:GetBuffDeckOption(buff.deck_option.deck, buff.deck_option.option) then
        else
            local params = {}
            params.id = id
            params.x = self._x
            params.y = buff_y
            params.w = buff_w
            params.h = buff_h
            params.group = buff.group
            params.text = buff.text
            params.text_localize = buff.text_localize
            params.texture, params.texture_rect = get_icon(buff)
            params.format = buff.format
            params.no_progress = buff.no_progress
            params.max = buff.max
            params.scale = scale
            params.text_scale = text_scale
            params.skill_check_after_spawn = buff.skill_check_after_spawn
            params.parent_buff = buff.parent_buff
            params.remove_on_alarm = buff.remove_on_alarm
            params.activate_on_alarm = buff.activate_on_alarm
            if buff.prepopulate_options then
                params.options = {}
                for key, value in pairs(buff.prepopulate_options) do
                    params.options[key] = EHI:GetBuffDeckOption(value.deck_option.deck, value.deck_option.option)
                end
            end
            if buff.prepopulate_options_permanent then
                params.options_permanent = {}
                for key, value in pairs(buff.prepopulate_options_permanent) do
                    params.options_permanent[key] = EHI:GetBuffDeckOption(value.deck_option.deck, value.deck_option.option)
                end
            end
            if buff.permanent then
                if (buff.permanent.option and EHI:GetBuffOption(buff.permanent.option)) or buff.permanent.option_true then
                    params.class = buff.permanent.class or "EHIPermanentBuffTracker"
                    params.stealth_check = buff.permanent.stealth_check
                    params.skill_check = buff.permanent.skill_check
                    params.team_skill_check = buff.permanent.team_skill_check
                    params.team_ai_skill_check = buff.permanent.team_ai_skill_check
                    params.always_show = buff.permanent.always_show
                    params.show_on_trigger = buff.permanent.show_on_trigger
                    params.show_on_trigger_when_synced = buff.permanent.show_on_trigger_when_synced
                    params.class_to_load = buff.permanent.class_to_load
                    params.skill_check_after_spawn = true
                    params.check_buff_on_spawn = true
                elseif buff.permanent.deck_option and EHI:GetBuffDeckOption(buff.permanent.deck_option.deck, buff.permanent.deck_option.option) then
                    params.class = buff.permanent.class or "EHIPermanentBuffTracker"
                    params.skill_check = buff.permanent.skill_check
                    params.team_skill_check = buff.permanent.team_skill_check
                    params.always_show = buff.permanent.always_show
                    params.show_on_trigger = buff.permanent.show_on_trigger
                    params.unhook_on_false_check = buff.permanent.unhook_on_false_checks
                    params.skill_check_after_spawn = true
                    params.check_buff_on_spawn = true
                else
                    params.class = buff.class
                    params.class_to_load = buff.class_to_load
                end
            else
                params.class = buff.class
                params.class_to_load = buff.class_to_load
            end
            self:_create_buff(params, buff.persistent, buff.deck_option)
        end
    end
end

---@param buff_y number
---@param buff_w number
---@param buff_h number
---@param scale number
---@param text_scale number
function EHIBuffManager:_init_tag_team_buffs(buff_y, buff_w, buff_h, scale, text_scale)
    if not EHI:GetBuffDeckOption("tag_team", "tagged") then
        return
    end
    local local_peer_id = EHI.IsHost and 1 or EHI._cache.LocalPeerID
    if Global.game_settings.single_player or not local_peer_id then
        return
    end
    local Tagged = class(EHIAbilityBuffTracker)
    Tagged.SkillCheck = EHIAbilityBuffTracker.super.SkillCheck
    function Tagged:post_init(params)
        if params.permanent then
            self._text:set_text("0")
            self._persistent = true
        end
        self:SetAbilityIcon("tag_team")
    end
    local permanent = EHI:GetBuffDeckOption("tag_team", "tagged_persistent")
    for i = 1, HUDManager.PLAYER_PANEL, 1 do
        if i ~= local_peer_id then -- You cannot tag yourself...
            local params = {}
            params.id = "TagTeamTagged_" .. i .. local_peer_id
            params.x = self._x
            params.y = buff_y
            params.w = buff_w
            params.h = buff_h
            params.text = "Paired"
            params.icon_color = tweak_data.chat_colors[i] or Color.white
            params.scale = scale
            params.text_scale = text_scale
            params.permanent = permanent
            self:_create_buff(params, nil, nil, Tagged)
        end
    end
    EHI.ModUtils:AddCustomNameColorSyncCallback("EHIBuffManager", function(peer_id, color)
        local buff = self._buffs["TagTeamTagged_" .. peer_id .. local_peer_id]
        if buff then
            buff._icon:set_color(color)
        end
    end)
    Hooks:Add("BaseNetworkSessionOnPeerRemoved", "BaseNetworkSessionOnPeerRemoved_EHIBuffManager", function(peer, peer_id, reason)
        local buff = self._buffs["TagTeamTagged_" .. peer_id .. local_peer_id]
        if buff then
            -- CriminalsManager.on_peer_left runs first than our BaseNetworkSession hook
            buff._icon:set_color(tweak_data.chat_colors[peer_id] or Color.white)
            if buff._active then
                buff._persistent = nil -- Flip the persistent state to deactivate the buff
                buff:Deactivate()
                buff._persistent = permanent -- Return it back
                buff._text:set_text("0")
            end
        end
    end)
end

function EHIBuffManager:_init_buff_redirect()
    for key, redirect in pairs(tweak_data.ehi.buff_redirect) do
        self._buffs[key] = self._buffs[redirect]
        self._buffs_redirect[key] = redirect
    end
end

---@param y number
---@param w number
---@param h number
---@param scale number
---@param text_scale number
function EHIBuffManager:_init_buff_group(y, w, h, scale, text_scale)
    ---@class EHIGroupBuffTracker : EHIBuffTracker
    ---@field super EHIBuffTracker
    local Group = class(EHIBuffTracker)
    function Group:Extend(t)
        if t > self._time then
            Group.super.Extend(self, t)
        end
    end
    local PermanentGroup = class(EHIPermanentBuffTracker)
    function PermanentGroup:Extend(t)
        if t > self._time then
            PermanentGroup.super.Extend(self, t)
        end
    end
    local get_icon = tweak_data.ehi.default.buff.get_icon
    for id, buff in pairs(tweak_data.ehi.buff_group) do
        if buff.option and not EHI:GetBuffDeckOption("group", buff.option) then
        else
            local params = {}
            params.id = id
            params.x = self._x
            params.y = y
            params.w = w
            params.h = h
            params.text_localize = buff.text_localize
            params.scale = scale
            params.text_scale = text_scale
            params.group = buff.group
            params.texture, params.texture_rect = get_icon(buff)
            if buff.permanent and EHI:GetBuffDeckOption("group", buff.permanent) then
                params.skill_check_after_spawn = true
                params.check_buff_on_spawn = true
                params.show_on_trigger = true
                self:_create_buff(params, nil, nil, PermanentGroup)
            else
                self:_create_buff(params, nil, nil, Group)
            end
            for _, original in ipairs(buff.redirect) do
                self._buffs[original]:delete()
                self._buffs[original] = self._buffs[id]
                self._buffs_redirect[original] = id
            end
        end
    end
end

---@param params table
---@param persistent string?
---@param deck_option table?
---@param class EHIBuffTracker?
function EHIBuffManager:_create_buff(params, persistent, deck_option, class)
    local buff
    if params.class_to_load then
        if params.class_to_load.prerequisite and not _G[params.class_to_load.prerequisite] then
            EHI:LoadBuff(params.class_to_load.prerequisite)
        end
        if params.class_to_load.load_class then
            EHI:LoadBuff(params.class_to_load.load_class)
        end
        buff = (class or _G[params.class_to_load.class]):new(self._panel, params)
    else
        buff = (class or _G[params.class or "EHIBuffTracker"]):new(self._panel, params)
    end
    self._buffs[params.id] = buff
    if params.skill_check_after_spawn then
        self._skill_check_after_spawn = self._skill_check_after_spawn or {} ---@type EHIBuffTracker[]
        table.insert(self._skill_check_after_spawn, buff)
    end
    if params.check_buff_on_spawn then -- queued
    elseif persistent and EHI:GetBuffOption(persistent) then
        buff:SetPersistent()
    elseif deck_option and EHI:GetBuffDeckOption(deck_option.deck, deck_option.persistent) then
        buff:SetPersistent()
    end
end

function EHIBuffManager:_cleanup_unused_buff_classes()
    for id, buff in pairs(tweak_data.ehi.buff) do
        if buff.class and buff.class ~= "EHIGaugeBuffTracker" and buff.class ~= "EHIForceUpdateParentBuffTracker" then
            local class = buff.class
            if _G[class] and not self._buffs[id] then -- Tracker class exists, but the tracker is not created because it is disabled; remove the class
                _G[class] = nil
            end
        elseif buff.class_to_load and buff.class_to_load.prerequisite then
            local class = buff.class_to_load.class
            if _G[class] and not self._buffs[id] then -- Tracker class exists, but the tracker is not created because it is disabled; remove the class
                _G[class] = nil
            end
        end
    end
end

---@param id string
function EHIBuffManager:_remove_buff_redirect(id)
    for key, value in pairs(self._buffs_redirect) do
        if value == id then
            self._buffs[key] = nil
            self._buffs_redirect[key] = nil
        end
    end
end

---@param id string
---@param f string
function EHIBuffManager:CallFunction(id, f, ...)
    local buff = self._buffs[id]
    if buff and buff[f] then
        buff[f](buff, ...)
    end
end

---@param id string
---@param t number
function EHIBuffManager:SyncAndAddBuff(id, t)
    managers.ehi_sync:SyncTable(self._sync_add_buff, { id = id, t = t })
    self:AddBuff(id, t)
end

function EHIBuffManager:ActivateUpdatingBuffs()
    for _, buff in ipairs(self._skill_check_after_spawn or {}) do
        if buff:SkillCheck() then
            buff:PreUpdate()
        elseif buff:CanDeleteOnFalseSkillCheck() then
            if buff._DELETE_BUFF_ON_FALSE_SKILL_CHECK then
                buff:delete()
            elseif buff._DELETE_BUFF_AND_CLASS_ON_FALSE_SKILL_CHECK then
                buff:delete_with_class()
            else
                buff:unhook()
            end
        end
    end
    self._skill_check_after_spawn = nil
    local pm = managers.player
    if pm._has_primary_reload_secondary or pm._has_secondary_reload_primary then
        local primary_count, secondary_count = 0, 0
        local primary_limit = pm:upgrade_value("player", "primary_reload_secondary", 10)
        local secondary_limit = pm:upgrade_value("player", "secondary_reload_primary", 10)
        ---@param equipped_unit UnitWeapon?
        ---@param variant string
        ---@param killed_unit UnitEnemy?
        pm:register_message(Message.OnEnemyKilled, "EHI_copycat_reload_primary_secondary", function(equipped_unit, variant, killed_unit)
            if variant == "melee" then
                return
            end
            local base = equipped_unit and equipped_unit:base()
            local selection_index = base and base:selection_index() or 0
            local update_secondary_reload_primary = selection_index == 1 and pm._has_secondary_reload_primary
	        local update_primary_reload_secondary = selection_index == 2 and pm._has_primary_reload_secondary
            if update_secondary_reload_primary then
                secondary_count = secondary_count + 1
                if secondary_limit <= secondary_count then
                    secondary_count = 0
                end
                self:AddGauge("secondary_reload_primary", secondary_count / secondary_limit, secondary_count)
            elseif update_primary_reload_secondary then
                primary_count = primary_count + 1
                if primary_limit <= primary_count then
                    primary_count = 0
                end
                self:AddGauge("primary_reload_secondary", primary_count / primary_limit, primary_count)
            end
        end)
    end
end

---@param id string
---@param t number
function EHIBuffManager:AddBuff(id, t)
    local buff = self._buffs[id]
    if buff then
        if buff._active then
            buff:Extend(t)
        else
            buff:Activate(t, self._n_visible)
            self._visible_buffs[buff._id] = buff
            self._n_visible = self._n_visible + 1
            self:ReorganizeFast(self._n_visible, buff)
        end
    end
end

---To stop moving buffs left and right on the screen
---@param id string
---@param t number
function EHIBuffManager:AddBuff2(id, t)
    self:AddBuff(id, t + 0.2)
end

---@param id string
function EHIBuffManager:AddBuffNoUpdate(id)
    local buff = self._buffs[id]
    if buff and not buff._active then
        buff:ActivateNoUpdate(self._n_visible)
        self._visible_buffs[buff._id] = buff
        self._n_visible = self._n_visible + 1
        self:ReorganizeFast(self._n_visible, buff)
    end
end

---@param id string
---@param ratio number
---@param custom_value number?
function EHIBuffManager:AddGauge(id, ratio, custom_value)
    local buff = self._buffs[id] --[[@as EHIGaugeBuffTracker?]]
    if buff then
        if buff._active then
            buff:SetRatio(ratio, custom_value)
        else
            buff:Activate(ratio, custom_value, self._n_visible)
            self._visible_buffs[buff._id] = buff
            self._n_visible = self._n_visible + 1
            self:ReorganizeFast(self._n_visible, buff)
        end
    end
end

---@param id string
function EHIBuffManager:RemoveBuff(id)
    local buff = self._buffs[id]
    if buff and buff._active then
        buff:Deactivate()
    end
end

---@param id string
function EHIBuffManager:RemoveAndResetBuff(id)
    local buff = self._buffs[id]
    if buff and buff._active then
        buff:DeactivateAndReset()
    end
end

---@param buff EHIBuffTracker
function EHIBuffManager:_add_visible_buff(buff)
    local id = buff._id
    if self._visible_buffs[id] then
        return
    end
    self._visible_buffs[id] = buff
    buff._pos = self._n_visible
    self._n_visible = self._n_visible + 1
    self:ReorganizeFast(self._n_visible, buff)
end

---@param buff EHIBuffTracker
function EHIBuffManager:_remove_visible_buff(buff)
    local id = buff._id
    if not self._visible_buffs[id] then
        return
    end
    self._visible_buffs[id] = nil
    self._n_visible = self._n_visible - 1
    self:Reorganize(buff._pos, buff, true)
end

---@param buff EHIBuffTracker
function EHIBuffManager:_add_buff_to_update(buff)
    self._update_buffs[buff._id] = buff
end

---@param id string
function EHIBuffManager:_remove_buff_from_update(id)
    self._update_buffs[id] = nil
end

---@param dt number
function EHIBuffManager:update(t, dt)
    for _, buff in pairs(self._update_buffs) do
        buff:update(dt)
    end
end

if EHI:GetOption("buffs_alignment") == 1 then -- Left
    ---@param pos number?
    ---@param buff EHIBuffTracker
    ---@param removal boolean?
    function EHIBuffManager:Reorganize(pos, buff, removal)
        if self._n_visible == 0 then
            return
        end
        pos = pos or self._n_visible
        for _, v_buff in pairs(self._visible_buffs) do
            v_buff:SetLeftXByPos(self._x, pos)
        end
    end

    ---@param pos number
    ---@param buff EHIBuffTracker
    function EHIBuffManager:ReorganizeFast(pos, buff)
        buff:SetLeftXByPos(self._x, pos)
    end
elseif EHI:GetOption("buffs_alignment") == 2 then -- Center
    ---@param pos number?
    ---@param buff EHIBuffTracker
    ---@param removal boolean?
    function EHIBuffManager:Reorganize(pos, buff, removal)
        if self._n_visible == 0 then
            return
        elseif self._n_visible == 1 then
            local center_x = self._panel:center_x()
            if removal then
                local _, v_buff = next(self._visible_buffs) ---@cast v_buff -?
                v_buff:SetCenterDefaultX(center_x)
            else
                buff:SetCenterDefaultX(center_x)
            end
        else
            local even = self._n_visible % 2 == 0
            local center_pos = even and math.ceil(self._n_visible / 2) or math.floor(self._n_visible / 2)
            local center_x = self._panel:center_x()
            pos = pos or self._n_visible
            for _, v_buff in pairs(self._visible_buffs) do
                v_buff:SetCenterXByPos(center_x, pos, center_pos, even)
            end
        end
    end
    EHIBuffManager.ReorganizeFast = EHIBuffManager.Reorganize
else -- Right
    ---@param pos number?
    ---@param buff EHIBuffTracker
    ---@param removal boolean?
    function EHIBuffManager:Reorganize(pos, buff, removal)
        if self._n_visible == 0 then
            return
        end
        pos = pos or self._n_visible
        for _, v_buff in pairs(self._visible_buffs) do
            v_buff:SetRightXByPos(self._x, pos)
        end
    end

    ---@param pos number
    ---@param buff EHIBuffTracker
    function EHIBuffManager:ReorganizeFast(pos, buff)
        buff:SetRightXByPos(self._x, pos)
    end
end

return EHIBuffManager