local EHI = EHI
local SF = EHI.SpecialFunctions
local TT = EHI.Trackers
local repair = { time = 90, id = "RepairWait", icons = { EHI.Icons.Fix }, hint = EHI.Hints.Wait }
local triggers = {
    [100030] = repair,
    [100065] = repair,
    [100080] = repair,
    [100123] = repair
}

---@type ParseAchievementTable
local achievements =
{
    hunter_loot =
    {
        difficulty_pass = EHI:IsDifficultyOrAbove(EHI.Difficulties.OVERKILL),
        elements =
        {
            [100132] = { special_function = SF.Trigger, data = { 1001321, 1001322 } },
            [1001321] = { max = 21, class = TT.Achievement.Progress, condition_function = EHI.ConditionFunctions.PlayingFromStart },
            [1001322] = EHI:AddCustomCode(function(self)
                EHI:ShowLootCounter({ max = 21 })
                self:UnhookTrigger(100416)
            end),
            [100416] = { special_function = SF.IncreaseProgress }
        }
    }
}
EHI:PreparseBeardlibAchievements(achievements, "hunter_all")

EHI.Mission:ParseTriggers({
    mission = triggers,
    achievement = achievements
})
EHI.Trigger:AddLoadSyncFunction(function(self)
    EHI:ShowLootCounter({ max = 21 })
    self:UnhookTrigger(100416)
    self._loot:SyncSecuredLoot()
end)