# Exorciste HUD

Cree par **Nuage02**.

HUD complet pour PAYDAY 2. Inclut les etiquettes flottantes des ennemis, les pop-ups de degats, la liste des buffs actifs, des polices et icones personnalisees.

## Installation

1. Telechargez l'archive du mod.
2. Glissez le dossier `Exorciste HUD` dans `mods/` de PAYDAY 2 (necessite SuperBLT).
3. Lancez le jeu.

## Credits

- Adaptation Exorciste : **Nuage02**.
