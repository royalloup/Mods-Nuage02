--[[
    Exorciste HUD (WFHud) + Extra Heist Info (EHI) — Patch de compatibilité
    
    Ce patch gère les chevauchements entre les deux mods :
    
    1. BUFFS : WFHud a son propre HUDBuffList. EHI peut aussi afficher des buffs.
       → Par défaut, on garde les buffs WFHud et on désactive l'affichage buff d'EHI.
       
    2. FLOATING HEALTH BARS : WFHud a HUDFloatingUnitLabel. EHI a aussi des barres de vie flottantes.
       → Par défaut, on garde celles de WFHud et on désactive celles d'EHI.
       
    3. DAMAGE HIT MARKERS : WFHud a HUDDamagePop. EHI a aussi des hit markers.
       → Par défaut, on garde ceux de WFHud et on désactive ceux d'EHI.
    
    Modifie les variables ci-dessous selon tes préférences.
--]]

-- ============================================================
--  CONFIGURATION DU PATCH
--  Mets à "true" pour utiliser la version WFHud (Exorciste HUD)
--  Mets à "false" pour utiliser la version EHI (Extra Heist Info)
-- ============================================================

local PATCH_CONFIG = {
    -- Quel mod gère l'affichage des buffs/procs de skills ?
    -- true  = WFHud (Exorciste HUD) — liste en bas à droite avec icônes custom
    -- false = EHI — liste colorée avec plus d'infos sur la durée
    use_wfhud_buffs = true,

    -- Quel mod gère les barres de vie flottantes au-dessus des ennemis ?
    -- true  = WFHud (Exorciste HUD) — barres custom avec polices WFHud
    -- false = EHI — barres flottantes d'EHI
    use_wfhud_floating_health = true,

    -- Quel mod gère les popups de dégâts ?
    -- true  = WFHud (Exorciste HUD) — popups animés avec couleurs critiques
    -- false = EHI — hit markers d'EHI
    use_wfhud_damage_popups = true,
}

-- ============================================================
--  APPLICATION DU PATCH
-- ============================================================

-- On attend que les deux mods soient chargés
local function apply_patch()
    -- Vérification que les deux mods sont présents
    if not WFHud then
        log("[EHI-WFHud Patch] ERREUR : Exorciste HUD (WFHud) n'est pas chargé !")
        return
    end

    -- Vérification qu'EHI est présent (EHI utilise le namespace "ExtraHeistInfo" ou "EHI")
    local ehi_present = EHI ~= nil or ExtraHeistInfo ~= nil
    if not ehi_present then
        log("[EHI-WFHud Patch] INFO : EHI n'est pas chargé, le patch n'est pas nécessaire.")
        return
    end

    log("[EHI-WFHud Patch] Les deux mods sont détectés. Application du patch...")

    -- ---------------------------------------------------------
    -- 1. GESTION DES BUFFS
    -- ---------------------------------------------------------
    if PATCH_CONFIG.use_wfhud_buffs then
        -- Désactiver les buffs d'EHI si WFHud les gère
        if EHI and EHI.settings then
            -- EHI stocke ses settings dans EHI.settings
            if EHI.settings.show_buffs ~= nil then
                EHI.settings.show_buffs = false
                log("[EHI-WFHud Patch] Buffs EHI désactivés → utilisation des buffs WFHud")
            end
            if EHI.settings.show_skill_procs ~= nil then
                EHI.settings.show_skill_procs = false
            end
        end
    else
        -- Désactiver les buffs de WFHud si EHI les gère
        if WFHud and WFHud.settings then
            WFHud.settings.buff_list = false
            log("[EHI-WFHud Patch] Buffs WFHud désactivés → utilisation des buffs EHI")
        end
    end

    -- ---------------------------------------------------------
    -- 2. GESTION DES BARRES DE VIE FLOTTANTES
    -- ---------------------------------------------------------
    if PATCH_CONFIG.use_wfhud_floating_health then
        -- Désactiver les barres de vie d'EHI
        if EHI and EHI.settings then
            if EHI.settings.floating_health_bars ~= nil then
                EHI.settings.floating_health_bars = false
                log("[EHI-WFHud Patch] Barres de vie flottantes EHI désactivées → utilisation de WFHud")
            end
            if EHI.settings.show_health_bars ~= nil then
                EHI.settings.show_health_bars = false
            end
        end
    else
        -- Désactiver les barres de vie de WFHud
        if WFHud and WFHud.settings then
            WFHud.settings.health_labels = false
            log("[EHI-WFHud Patch] Barres de vie WFHud désactivées → utilisation des barres EHI")
        end
    end

    -- ---------------------------------------------------------
    -- 3. GESTION DES POPUPS DE DÉGÂTS / HIT MARKERS
    -- ---------------------------------------------------------
    if PATCH_CONFIG.use_wfhud_damage_popups then
        -- Désactiver les hit markers d'EHI
        if EHI and EHI.settings then
            if EHI.settings.damage_markers ~= nil then
                EHI.settings.damage_markers = false
                log("[EHI-WFHud Patch] Hit markers EHI désactivés → utilisation des popups WFHud")
            end
            if EHI.settings.show_damage ~= nil then
                EHI.settings.show_damage = false
            end
        end
    else
        -- Désactiver les popups de WFHud
        if WFHud and WFHud.settings then
            WFHud.settings.damage_popups = false
            log("[EHI-WFHud Patch] Popups de dégâts WFHud désactivés → utilisation d'EHI")
        end
    end

    log("[EHI-WFHud Patch] Patch appliqué avec succès !")
end

-- Hook sur l'init du HUDManager pour appliquer le patch après le chargement des deux mods
Hooks:PostHook(HUDManager, "init", "apply_ehi_wfhud_patch", function(self)
    -- Petit délai pour s'assurer que tout est initialisé
    local ok, err = pcall(apply_patch)
    if not ok then
        log("[EHI-WFHud Patch] ERREUR lors de l'application du patch : " .. tostring(err))
    end
end)

log("[EHI-WFHud Patch] Patch chargé. Il s'appliquera à l'initialisation du HUD.")
