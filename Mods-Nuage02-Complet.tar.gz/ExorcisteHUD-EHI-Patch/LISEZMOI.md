# Exorciste HUD + Extra Heist Info — Guide de fusion

## Ce que contient ce dossier

Un **patch de compatibilité** qui fait fonctionner ensemble :
- **Exorciste HUD** (WFHud) par Nuage 02 — HUD complet de remplacement
- **Extra Heist Info** (EHI) par Nuage 02 — Trackers d'informations de braquage

---

## Pourquoi un patch ?

Les deux mods ont des fonctionnalités qui se chevauchent :

| Fonctionnalité | Exorciste HUD | Extra Heist Info |
|---|---|---|
| Barres de vie flottantes | ✅ HUDFloatingUnitLabel | ✅ Option séparée |
| Liste de buffs / procs de skills | ✅ HUDBuffList | ✅ Section buffs colorés |
| Popups de dégâts / hit markers | ✅ HUDDamagePop | ✅ Option séparée |
| Trackers de minuteurs (van, C4, thermite...) | ❌ Absent | ✅ Fonctionnalité principale |
| XP détaillé en fin de mission | ❌ Absent | ✅ Fonctionnalité principale |
| Achievements et objectifs spéciaux | ❌ Absent | ✅ Fonctionnalité principale |
| Chances d'événements (gaz, cuisson...) | ❌ Absent | ✅ Fonctionnalité principale |

**EHI apporte ce qu'Exorciste HUD n'a pas** (trackers, XP, achievements).  
**Le patch évite les doublons** sur les fonctionnalités communes.

---

## Installation

### Prérequis
- SuperBLT installé
- Exorciste HUD installé dans `/mods/`
- Extra Heist Info installé dans `/mods/`

### Étapes
1. Copie le dossier `ExorcisteHUD-EHI-Patch` dans ton dossier `/mods/` de PAYDAY 2
2. La structure doit ressembler à :
   ```
   PAYDAY 2/
   └── mods/
       ├── Exorciste HUD/          ← ton mod existant
       ├── Extra Heist Info/        ← téléchargé depuis modworkshop.net/mod/31915
       └── ExorcisteHUD-EHI-Patch/ ← ce dossier
           ├── mod.txt
           ├── patch.lua
           └── LISEZMOI.md
   ```
3. Lance PAYDAY 2

---

## Configuration du patch

Ouvre `patch.lua` et modifie la section `PATCH_CONFIG` selon tes préférences :

```lua
local PATCH_CONFIG = {
    use_wfhud_buffs = true,           -- true = buffs d'Exorciste HUD, false = buffs d'EHI
    use_wfhud_floating_health = true,  -- true = barres de vie d'Exorciste HUD, false = barres d'EHI
    use_wfhud_damage_popups = true,    -- true = popups d'Exorciste HUD, false = hit markers d'EHI
}
```

**Recommandation** : Garde tout à `true` — Exorciste HUD est un HUD complet plus cohérent visuellement. EHI t'apportera ses trackers de braquage et ses infos d'achievements en plus.

---

## Ce que tu auras in-game

Avec les deux mods + le patch installés :

### De Exorciste HUD (inchangé)
- ✅ Panneaux joueurs redessinés (avatars, déployables, morts)
- ✅ Barres de santé et armure custom
- ✅ Liste de buffs avec icônes custom
- ✅ Popups de dégâts animés (critiques colorés)
- ✅ Barres de vie flottantes au-dessus des ennemis
- ✅ Chat custom avec timestamps
- ✅ Barre de vie des boss
- ✅ Liste de ramassage (munitions, argent, objets)
- ✅ Affichage d'interaction amélioré

### De Extra Heist Info (nouvelles fonctions)
- ✅ **Trackers de minuteurs** : sait combien de temps avant que le van/hélico/bateau arrive
- ✅ **Tracker C4 / Thermite** : progression en temps réel
- ✅ **XP détaillé** : aperçu de l'XP gagné pendant le braquage
- ✅ **Achievements** : progression vers les succès spéciaux (ex: The Secret)
- ✅ **Chances d'événements** : probabilité de gaz lacrymogène, cuisson, etc.
- ✅ **Compatibilité Ultra-Wide**

### Désactivés (doublons)
- ❌ Barres de vie flottantes d'EHI (remplacées par WFHud)
- ❌ Liste de buffs d'EHI (remplacée par WFHud)
- ❌ Hit markers d'EHI (remplacés par WFHud)

---

## Vérification dans les logs

Dans SuperBLT, cherche ces lignes dans le fichier `log.txt` :
```
[EHI-WFHud Patch] Les deux mods sont détectés. Application du patch...
[EHI-WFHud Patch] Patch appliqué avec succès !
```

Si tu vois une erreur, c'est que l'un des deux mods n'est pas correctement installé.

---

## Remarques importantes

- **EHI est positionnable** via ses options in-game (touche `F8` ou menu BLT). Ajuste la position X/Y pour qu'il ne chevauche pas les éléments d'Exorciste HUD.
- **EHI supporte les écrans ultra-larges** — utile si tu joues sur un moniteur large.
- **EHI est toujours précis côté hôte** ; côté client, il peut y avoir 1-3 secondes de décalage pour les minuteurs.
- Les deux mods ont une priorité définie dans `mod.txt`. Exorciste HUD a `"priority": -100`, ce patch a `"priority": -99` (s'applique après WFHud).

---

## Problèmes connus

| Problème | Solution |
|---|---|
| EHI ne s'affiche pas | Appuie sur `0` deux fois pour forcer le rafraîchissement |
| "Tweakdata Fixed" installé | Incompatible avec EHI — désinstalle-le |
| Les buffs apparaissent en double | Assure-toi que `use_wfhud_buffs = true` dans le patch |
| Position d'EHI chevauche le HUD | Règle X/Y dans les options d'EHI (touche F8) |

---

*Patch créé pour la fusion de Exorciste HUD v1.6.8 et Extra Heist Info (ModWorkshop #31915)*
